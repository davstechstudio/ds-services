SKILLCONNECT GH — full-stack bundle (Node host)
================================================
1. Upload this whole folder to your Node host.
2. cd server && npm install --omit=dev
3. Start:  npm start   (or: node src/index.js)
4. The console prints a SETUP URL + one-time token.
5. Open http://<your-host>/setup.html in a browser,
   paste the token, press "Run Install / Upgrade".
6. Open /index.html — done. Admin PIN default 4321
   (change it immediately in the admin console).

UPGRADES: upload the new full-stack bundle over the old one
(keep server/.env!), restart, open /setup.html, press Run.
Only missing tables/columns/rows are added; data is never
deleted or overwritten.
