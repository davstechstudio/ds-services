/* ============================================================
   SKILLCONNECT GH — MySQL schema (Phase 1: backend migration)
   ------------------------------------------------------------
   Mirrors the sandbox store (localStorage key `sc_db_v1`) table
   for table and field for field. Nothing in the business logic
   changes; only where the bytes live. Design rules:

   - NO hardcoded business config: every constant that lived in
     data-store.js (commission %, reg fee, OTP TTL, session TTL,
     category definitions, urgency SLAs, list caps) moves into
     the `settings` / `categories` / `urgency_levels` tables so
     every section stays admin-changeable.
   - Money stays GH₵ decimals (DECIMAL(12,2)); rounding rules
     (Math.round semantics) stay in the API layer exactly as in
     the sandbox to avoid behavior drift.
   - Timestamps remain JS epoch MILLISECONDS (BIGINT) wherever
     the sandbox used Date.now() — pages format them today with
     new Date(at); keeping ms avoids display logic changes.
     Only booking.event_date is a real DATE (sandbox stores an
     ISO yyyy-mm-dd string).
   - Human-readable business refs (SC-BK-284001, SC-Q-51001…)
     are preserved: the `counters` table + prefix map replaces
     the sandbox `counters` object, incremented server-side
     inside the same transaction as the INSERT.
   - Engine InnoDB, charset utf8mb4 (₵, —, Twi text, emoji).
   ============================================================ */

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

/* ------------------------------------------------------------
   1. CONFIG (was: JS constants — now runtime-changeable)
   ------------------------------------------------------------ */

-- Key/value store for every tunable that was a const in code.
-- Consumers read through the API; admins edit via console later.
CREATE TABLE IF NOT EXISTS settings (
    setting_key   VARCHAR(64)  NOT NULL,
    setting_value JSON         NOT NULL,
    updated_at    BIGINT       NOT NULL,
    PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Initial values = the exact constants the sandbox shipped with
-- (keys are read by the API; values may change at any time):
--   commission_rate        0.10            (COMMISSION_RATE)
--   default_reg_fee        50              (REG_FEE fallback)
--   otp_ttl_minutes        10              (PRO_OTP_TTL_MS)
--   session_ttl_hours      8               (sc-session.js TTL)
--   default_pro_password   'skillconnect'  (bootstrap only; forced change on first login)
--   default_admin_password '4321'          (bootstrap only; see admin_auth)
--   currency               'GHS'           (display strings stay 'GH₵ ' + n)
--   notifications_cap      400             (notify() list cap)
--   support_cap            200             (supportMessages list cap)
--   max_matches            3               (createBooking matchedProIds slice)
--   site_url               'https://skillconnectgh.com'
--   sandbox_mode           true            (simulated quotes/chat/OTP echo; flip at go-live)

-- Service categories (was CAT_LABELS / CATEGORY_INFO / PRO_ICONS consts).
-- code values are referenced by bookings.cat, pros.cat, applications.cat.
CREATE TABLE IF NOT EXISTS categories (
    code       VARCHAR(20)  NOT NULL,          -- mc | artist | photographer | videographer | dj | caterer | decorator | handy
    label      VARCHAR(80)  NOT NULL,          -- 'Event MC / Host'
    icon       VARCHAR(40)  NOT NULL,          -- 'fa-microphone-lines'
    range_min  INT          NOT NULL DEFAULT 0,
    range_max  INT          NOT NULL DEFAULT 0,
    advice     TEXT         NULL,              -- customer guidance shown at booking
    sort       INT          NOT NULL DEFAULT 0,
    active     TINYINT(1)   NOT NULL DEFAULT 1, -- retire a category without deleting history
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed data uses INSERT IGNORE throughout: on a FRESH database the rows
-- land exactly as before; on an EXISTING database a re-import (upgrade)
-- fills any missing config rows WITHOUT overwriting the settings admins
-- changed, or duplicating catalog rows. Runtime data (pros, bookings,
-- counters, admin_auth) is seeded by the API's ensureSeeded(), not here.
INSERT IGNORE INTO categories (code, label, icon, range_min, range_max, advice, sort) VALUES
('mc',           'Event MC / Host',              'fa-microphone-lines',     800, 2500,  'Share your program schedule and names of key people (chief, groom, bride, dignitaries) with the MC in advance. Confirm if you need bilingual hosting (Twi, Ewe, Ga, English).', 1),
('artist',       'Music Artist / Live Band',     'fa-guitar',              2500,15000,  'Confirm stage size, power supply and performance duration. Provide a playlist or song list, and check if the artist needs backing tracks or live instruments.', 2),
('photographer', 'Photographer',                 'fa-camera-retro',         600, 3000,  'Agree on the shot list and how many edited photos you will receive and when. Confirm whether you want hard copies or digital albums.', 3),
('videographer', 'Videographer / Editor',        'fa-video',               1000, 5000,  'Decide between full-length coverage or a highlight reel. Ask about drone coverage if the venue allows it, and confirm delivery timeline for the final edit.', 4),
('dj',           'DJ / Sound & Lighting',        'fa-compact-disc',         800, 4000,  'State the audience size so the pro brings a big enough sound system and speakers. Confirm power backup (generator) for outdoor events.', 5),
('caterer',      'Caterer / Baker',              'fa-utensils',            1500,10000,  'Give the exact guest count and menu preference. Ask for a tasting where possible and confirm serving staff are included in the quote.', 6),
('decorator',    'Decorator / Event Planner',    'fa-wand-magic-sparkles', 1500, 8000,  'Share your theme colors and a reference photo. Confirm setup and teardown times so the venue access is arranged.', 7),
('handy',        'Handy Skill Worker',           'fa-screwdriver-wrench',    150, 1200,  'Describe the fault clearly and send a photo if you can. Prepare access to the area (keys, gate pass) so the job starts immediately on arrival.', 8);

-- Urgency levels (was URGENCY_INFO const) — booking.urgency FK target.
CREATE TABLE IF NOT EXISTS urgency_levels (
    code      VARCHAR(12) NOT NULL,             -- planned | soon | urgent
    label     VARCHAR(40) NOT NULL,             -- 'Planned'
    sla_hours DECIMAL(4,1) NOT NULL,            -- 24 / 6 / 0.5
    note      VARCHAR(255) NOT NULL,
    sort      INT NOT NULL DEFAULT 0,
    active    TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO urgency_levels (code, label, sla_hours, note, sort) VALUES
('planned', 'Planned',              24.0, 'You''ll receive up to 3 quotes within 24 hours.', 1),
('soon',    'Within 48 hours',       6.0, 'Pros will respond within 6 hours — watch your WhatsApp.', 2),
('urgent',  'Emergency / Today',     0.5, 'This goes to standby pros on emergency dispatch — expect a call within 30 minutes.', 3);

/* ------------------------------------------------------------
   2. CMS + ADMIN CREDENTIALS  (was db.cms singleton)
   ------------------------------------------------------------ */

CREATE TABLE IF NOT EXISTS cms (
    id            TINYINT      NOT NULL DEFAULT 1,   -- singleton row
    hero_title    VARCHAR(160) NOT NULL,
    hero_sub      TEXT         NOT NULL,
    announce_on   TINYINT(1)   NOT NULL DEFAULT 1,
    -- multi-line: one announcement per line == one auto-playing slide
    announce_text TEXT         NOT NULL,
    reg_fee       DECIMAL(10,2) NOT NULL DEFAULT 50,
    updated_at    BIGINT       NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Salted SHA-256 admin credential (was cms.adminAuth). Hex hashes,
-- same algo string as sandbox ('sha256'); server-side hashing only.
CREATE TABLE IF NOT EXISTS admin_auth (
    id         TINYINT     NOT NULL DEFAULT 1,
    salt       CHAR(32)    NULL,                 -- NULL until first bootstrap
    hash       CHAR(64)    NULL,
    algo       VARCHAR(16) NOT NULL DEFAULT 'sha256',
    updated_at BIGINT      NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT fk_admin_auth_cms FOREIGN KEY (id) REFERENCES cms (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO cms (id, hero_title, hero_sub, announce_on, announce_text, reg_fee, updated_at) VALUES
(1, 'GHANA''S #1 BOOKING PLATFORM FOR SKILLED SERVICE PROS!',
    'Discover, compare and instantly book verified Event MCs, Performing Artists, Photographers, Videographers, DJs, Caterers and Handy Skill Workers — near you, within budget, in minutes.',
    1,
    'Pay only AFTER the job is done — no upfront deposits.\nNew professionals: one-time GH₵ 50 registration fee.\nVerified pros, nationwide coverage — book in minutes.',
    50, 0);

/* ------------------------------------------------------------
   3. PROFESSIONALS  (was db.pros[])
   ------------------------------------------------------------ */

CREATE TABLE IF NOT EXISTS pros (
    id              VARCHAR(12)  NOT NULL,       -- 'P1001' (business id preserved, not AUTO_INCREMENT)
    name            VARCHAR(80)  NOT NULL,
    short_name      VARCHAR(40)  NOT NULL,
    cat             VARCHAR(20)  NOT NULL,
    role            VARCHAR(60)  NOT NULL,       -- display title, e.g. 'Event MC'
    city            VARCHAR(60)  NOT NULL,
    rating          DECIMAL(2,1) NOT NULL DEFAULT 0,
    rating_count    INT          NOT NULL DEFAULT 0,
    bookings_count  INT          NOT NULL DEFAULT 0,  -- display stat (sandbox: bookings)
    price           INT          NOT NULL DEFAULT 0,  -- from-price
    unit            VARCHAR(10)  NOT NULL,       -- event | show | day | visit
    note            VARCHAR(255) NULL,
    phone           VARCHAR(20)  NOT NULL,
    verified        TINYINT(1)   NOT NULL DEFAULT 0,
    emergency       TINYINT(1)   NOT NULL DEFAULT 0,
    response        VARCHAR(10)  NOT NULL,       -- 1hr | 3hr | sameday | 24hr
    contact_channels VARCHAR(16) NOT NULL DEFAULT 'both',  -- sms | whatsapp | both (how the pro accepts contact)
    years           VARCHAR(10)  NOT NULL,       -- 3-5 | 6-10 | 10+
    languages       JSON         NULL,           -- ['English','Twi']
    description     TEXT         NULL,           -- sandbox: desc
    earnings        DECIMAL(12,2) NOT NULL DEFAULT 0,   -- lifetime post-commission
    commission_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
    balance         DECIMAL(12,2) NOT NULL DEFAULT 0,   -- withdrawable wallet
    blocked         JSON         NULL,           -- ['2026-10-01', …] unavailable dates
    portfolio       JSON         NULL,           -- [{url, caption}] when uploaded; else synthesized
    joined_at       BIGINT       NOT NULL,
    source          VARCHAR(20)  NOT NULL DEFAULT 'seed',  -- seed | register-page | admin | registration
    app_id          VARCHAR(16)  NULL,           -- application that created this pro
    reg_fee_paid    TINYINT(1)   NOT NULL DEFAULT 0,
    reg_fee_at      BIGINT       NULL,
    -- identity documents + re-verification (Ghana Card, 5-year cycle)
    id_type         VARCHAR(40)  NULL,
    id_number       VARCHAR(40)  NULL,
    tin             VARCHAR(40)  NULL,
    id_docs_received TINYINT(1)  NOT NULL DEFAULT 0,
    id_front_name   VARCHAR(120) NULL,
    id_back_name    VARCHAR(120) NULL,
    id_front_data   MEDIUMTEXT   NULL,           -- compressed base64 (object storage in Phase 4)
    id_back_data    MEDIUMTEXT   NULL,
    id_verified_at  BIGINT       NULL,
    id_reverify     VARCHAR(10)  NULL,           -- '' | flagged | pending
    id_submitted_at BIGINT       NULL,
    id_gate_until   BIGINT       NULL,           -- admin ID-gate override: pros stay listed until this ms timestamp
    id_gate_notified VARCHAR(16) NULL,           -- last enforcement stage the pro was notified about (softdelist/fullydelisted)
    has_real_portfolio TINYINT(1) NOT NULL DEFAULT 0,
    -- auth block (was pro.auth): salted SHA-256, lazy-created at first login
    auth_salt       CHAR(32)     NULL,
    auth_hash       CHAR(64)     NULL,
    auth_algo       VARCHAR(16)  NULL,
    auth_updated_at BIGINT       NOT NULL DEFAULT 0,  -- session credential version (pv)
    PRIMARY KEY (id),
    UNIQUE KEY uq_pros_phone (phone),
    KEY idx_pros_cat (cat, verified),
    CONSTRAINT fk_pros_cat FOREIGN KEY (cat) REFERENCES categories (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pro OTP codes (was pro.auth.otp): 6-digit, TTL from settings, single-use
-- (row deleted on successful login). Same salt as the pro's password hash.
CREATE TABLE IF NOT EXISTS pro_otp (
    pro_id     VARCHAR(12) NOT NULL,
    hash       CHAR(64)    NOT NULL,
    expires_at BIGINT      NOT NULL,
    created_at BIGINT      NOT NULL,
    PRIMARY KEY (pro_id),
    CONSTRAINT fk_pro_otp_pro FOREIGN KEY (pro_id) REFERENCES pros (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ------------------------------------------------------------
   4. APPLICATIONS  (was db.applications[] — register.html intake)
   ------------------------------------------------------------ */

CREATE TABLE IF NOT EXISTS applications (
    id            VARCHAR(16)  NOT NULL,        -- 'SC-APP-301'
    name          VARCHAR(80)  NOT NULL,
    phone         VARCHAR(20)  NOT NULL,
    whatsapp      VARCHAR(20)  NULL,
    email         VARCHAR(120) NULL,
    city          VARCHAR(60)  NOT NULL,
    cat           VARCHAR(20)  NOT NULL,
    years         VARCHAR(10)  NULL,
    spec          VARCHAR(120) NULL,
    description   TEXT         NULL,            -- sandbox: desc
    languages     JSON         NULL,
    portfolio_url VARCHAR(255) NULL,
    social        VARCHAR(255) NULL,
    samples       JSON         NULL,
    id_type       VARCHAR(40)  NULL,
    id_number     VARCHAR(40)  NULL,
    tin           VARCHAR(40)  NULL,
    id_front_name VARCHAR(120) NULL,
    id_back_name  VARCHAR(120) NULL,
    id_front_data MEDIUMTEXT   NULL,            -- compressed base64 (moved to object storage in Phase 4)
    id_back_data  MEDIUMTEXT   NULL,
    rate          INT          NULL,
    unit          VARCHAR(10)  NULL,
    emergency     TINYINT(1)   NULL,
    response      VARCHAR(10)  NULL,
    momo          VARCHAR(20)  NULL,
    days          JSON         NULL,            -- available weekdays
    status        ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
    source        VARCHAR(20)  NOT NULL DEFAULT 'register-page',
    admin_note    VARCHAR(255) NULL,
    edited_fields JSON         NULL,            -- audit trail of admin corrections (sandbox editedFields)
    edited_at     BIGINT       NULL,
    submitted_at  BIGINT       NOT NULL,
    reviewed_at   BIGINT       NULL,
    -- fee can be paid BEFORE verification (sandbox mutated the application
    -- object in that case) — mirrored here so payRegFee keeps both branches
    reg_fee_paid  TINYINT(1)   NOT NULL DEFAULT 0,
    reg_fee_at    BIGINT       NULL,
    PRIMARY KEY (id),
    KEY idx_app_status (status, submitted_at),
    CONSTRAINT fk_app_cat FOREIGN KEY (cat) REFERENCES categories (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ------------------------------------------------------------
   5. BOOKINGS + CHILDREN  (was db.bookings[])
   ------------------------------------------------------------ */

CREATE TABLE IF NOT EXISTS bookings (
    id              VARCHAR(16)  NOT NULL,       -- 'SC-BK-284001'
    customer_name   VARCHAR(80)  NOT NULL,
    customer_phone  VARCHAR(20)  NOT NULL,
    cat             VARCHAR(20)  NOT NULL,
    event_date      DATE         NULL,           -- sandbox: date (ISO string) or ''
    location        VARCHAR(160) NOT NULL,
    budget          DECIMAL(10,2) NULL,
    urgency         VARCHAR(12)  NOT NULL DEFAULT 'planned',
    details         TEXT         NULL,
    status          ENUM('matching','quoted','booked','in_progress','completed','disputed','cancelled')
                                 NOT NULL DEFAULT 'matching',
    matched_pro_ids JSON         NULL,           -- ['P1001','P1002'] (max settings.max_matches)
    chosen_pro_id   VARCHAR(12)  NULL,
    amount          DECIMAL(10,2) NOT NULL DEFAULT 0,  -- agreed amount (set at acceptQuote)
    commission      DECIMAL(10,2) NULL,           -- set at release
    sla_hours       DECIMAL(4,1)  NULL,
    created_at      BIGINT       NOT NULL,
    reviewed        TINYINT(1)   NOT NULL DEFAULT 0,
    rematch_exclude VARCHAR(12)  NULL,           -- disputed pro excluded from rematch
    rematch_pick    TINYINT(1)   NULL,           -- sandbox: boolean 'waiting for customer pick'
    pro_paid        TINYINT(1)   NOT NULL DEFAULT 0,
    pro_paid_at     BIGINT       NULL,
    pro_paid_method VARCHAR(20)  NULL,
    cancelled_at    BIGINT       NULL,
    paid_at         BIGINT       NULL,           -- sandbox: set when escrow released
    PRIMARY KEY (id),
    KEY idx_bk_phone (customer_phone),
    KEY idx_bk_status (status),
    KEY idx_bk_pro (chosen_pro_id),
    KEY idx_bk_created (created_at),
    CONSTRAINT fk_bk_cat FOREIGN KEY (cat) REFERENCES categories (code),
    CONSTRAINT fk_bk_urgency FOREIGN KEY (urgency) REFERENCES urgency_levels (code),
    CONSTRAINT fk_bk_pro FOREIGN KEY (chosen_pro_id) REFERENCES pros (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Status timeline (was booking.events[]): chronological, seq 0..n.
CREATE TABLE IF NOT EXISTS booking_events (
    booking_id VARCHAR(16) NOT NULL,
    seq        INT         NOT NULL,
    at         BIGINT      NOT NULL,
    text       VARCHAR(500) NOT NULL,
    PRIMARY KEY (booking_id, seq),
    CONSTRAINT fk_ev_booking FOREIGN KEY (booking_id) REFERENCES bookings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Escrow (was booking.escrow{} inline object). One row per funded booking;
-- extracted as its own table so the payment phase (real gateways) plugs in
-- WITHOUT altering the booking table or the state machine.
CREATE TABLE IF NOT EXISTS escrow (
    booking_id  VARCHAR(16)  NOT NULL,
    pro_id      VARCHAR(12)  NULL,               -- sandbox: escrow.proId set on reassignment
    method      VARCHAR(20)  NOT NULL DEFAULT 'momo',  -- momo | paystack | telecel | cash
    paid_at     BIGINT       NOT NULL,
    amount      DECIMAL(10,2) NOT NULL,
    released    TINYINT(1)   NOT NULL DEFAULT 0,
    released_at BIGINT       NULL,
    txn_ref     VARCHAR(64)  NOT NULL,        -- 'ESC-XXXXXX' sandbox, 'PMT-…' paystack, MTN UUID; reassignment appends '/R<n>'
    PRIMARY KEY (booking_id),
    UNIQUE KEY uq_escrow_ref (txn_ref),
    KEY idx_escrow_pro (pro_id),
    CONSTRAINT fk_escrow_booking FOREIGN KEY (booking_id) REFERENCES bookings (id) ON DELETE CASCADE,
    CONSTRAINT fk_escrow_pro FOREIGN KEY (pro_id) REFERENCES pros (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quotes (
    id           VARCHAR(16)  NOT NULL,        -- 'SC-Q-51001'
    booking_id   VARCHAR(16)  NOT NULL,
    pro_id       VARCHAR(12)  NOT NULL,
    price        DECIMAL(10,2) NOT NULL,
    eta_hours    INT          NOT NULL DEFAULT 24,
    message      TEXT         NOT NULL,
    status       ENUM('sent','accepted','declined','expired') NOT NULL DEFAULT 'sent',
    created_at   BIGINT       NOT NULL,
    eta_at       BIGINT       NOT NULL,
    responded_at BIGINT       NULL,
    PRIMARY KEY (id),
    KEY idx_q_booking (booking_id),
    KEY idx_q_pro (pro_id, status),
    CONSTRAINT fk_q_booking FOREIGN KEY (booking_id) REFERENCES bookings (id) ON DELETE CASCADE,
    CONSTRAINT fk_q_pro FOREIGN KEY (pro_id) REFERENCES pros (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reviews (
    id         VARCHAR(32) NOT NULL,             -- 'SC-RV-7001' (seed history: 'SC-RV-SEED-P1001-0')
    booking_id VARCHAR(16) NULL,                 -- NULL for seeded pre-history reviews (no real booking);
                                                  -- UNIQUE still enforces one review per real booking
    pro_id     VARCHAR(12) NOT NULL,
    by_name    VARCHAR(80) NOT NULL,             -- sandbox: by
    rating     TINYINT     NOT NULL,             -- 1..5 (clamped in API as today)
    text       TEXT        NULL,
    at         BIGINT      NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_review_booking (booking_id),   -- sandbox: one review per booking
    KEY idx_review_pro (pro_id),
    CONSTRAINT fk_review_booking FOREIGN KEY (booking_id) REFERENCES bookings (id),
    CONSTRAINT fk_review_pro FOREIGN KEY (pro_id) REFERENCES pros (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS disputes (
    id          VARCHAR(16) NOT NULL,            -- 'SC-DS-41'
    booking_id  VARCHAR(16) NOT NULL,
    reason      VARCHAR(40) NOT NULL,            -- short label (sandbox dispute.reason)
    details     TEXT        NULL,                -- free text (sandbox dispute.details)
    status      ENUM('open','resolved_refund','resolved_rematch','resolved_release') NOT NULL DEFAULT 'open',
    note        TEXT        NULL,
    opened_at   BIGINT      NOT NULL,
    resolved_at BIGINT      NULL,
    PRIMARY KEY (id),
    KEY idx_dispute_status (status),
    CONSTRAINT fk_dispute_booking FOREIGN KEY (booking_id) REFERENCES bookings (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ------------------------------------------------------------
   6. MONEY LEDGER  (was db.transactions[] — append-only)
   ------------------------------------------------------------ */

CREATE TABLE IF NOT EXISTS transactions (
    id         VARCHAR(16)  NOT NULL,           -- 'SC-500001' (txn prefix falls back to 'SC-')
    type       ENUM('service_payment','commission','payout','registration_fee','refund') NOT NULL,
    booking_id VARCHAR(16)  NULL,
    pro_id     VARCHAR(12)  NULL,
    amount     DECIMAL(12,2) NOT NULL,
    method     VARCHAR(20)  NOT NULL DEFAULT 'momo',
    note       VARCHAR(255) NULL,
    status     ENUM('success','pending','failed') NOT NULL DEFAULT 'success',
    at         BIGINT       NOT NULL,
    PRIMARY KEY (id),
    KEY idx_txn_type (type, at),
    KEY idx_txn_booking (booking_id),
    KEY idx_txn_pro (pro_id),
    CONSTRAINT fk_txn_booking FOREIGN KEY (booking_id) REFERENCES bookings (id),
    CONSTRAINT fk_txn_pro FOREIGN KEY (pro_id) REFERENCES pros (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pro withdrawal requests (sandbox declares db.payoutRequests[] and the
-- admin console counts pending rows, but no writer exists yet — schema
-- matches the declared shape so dashboard requestPayout() can persist
-- here post-migration without another schema change).
CREATE TABLE IF NOT EXISTS payout_requests (
    id           VARCHAR(16) NOT NULL,           -- 'SC-PO-101'
    pro_id       VARCHAR(12) NOT NULL,
    amount       DECIMAL(12,2) NOT NULL,
    method       VARCHAR(20) NOT NULL DEFAULT 'momo',
    status       ENUM('pending','approved','paid','rejected','cancelled') NOT NULL DEFAULT 'pending',
    batch_id     VARCHAR(16) NULL,               -- set when grouped into a payout batch
    requested_at BIGINT      NOT NULL,
    processed_at BIGINT      NULL,
    processed_by VARCHAR(40) NULL,
    PRIMARY KEY (id),
    KEY idx_payout_status (status, requested_at),
    KEY idx_payout_batch (batch_id),
    CONSTRAINT fk_payout_pro FOREIGN KEY (pro_id) REFERENCES pros (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin-approved groups of withdrawal requests. createPayoutBatch fills it
-- (status 'processing'); processPayoutBatch is the single money move that
-- completes it (status 'completed'). Money NEVER moves at request time.
CREATE TABLE IF NOT EXISTS payout_batches (
    id           VARCHAR(16) NOT NULL,           -- 'SC-PB-1'
    item_count   INT          NOT NULL,
    total        DECIMAL(12,2) NOT NULL,
    status       ENUM('processing','completed') NOT NULL DEFAULT 'processing',
    note         VARCHAR(255) NULL,
    processed_by VARCHAR(40)  NULL,
    processed_at BIGINT       NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Gateway payment attempts (additive, empty at go-live of Phase 1; the
-- payment phase populates it. Booking/escrow logic never depends on it —
-- it is the reconciliation + idempotency layer for real gateways).
CREATE TABLE IF NOT EXISTS payment_intents (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    purpose     ENUM('escrow','reg_fee') NOT NULL,
    booking_id  VARCHAR(16)  NULL,
    app_ref     VARCHAR(16)  NULL,             -- reg_fee intents: application id (booking_id is FK-bound to bookings)
    gateway     VARCHAR(20)  NULL,             -- paystack | hubtel | mtn_momo …
    gateway_ref VARCHAR(64)  NULL,             -- provider charge/transaction id
    amount      DECIMAL(10,2) NOT NULL,
    status      ENUM('initiated','pending','success','failed') NOT NULL DEFAULT 'initiated',
    raw         JSON         NULL,             -- last webhook payload (audit)
    created_at  BIGINT       NOT NULL,
    updated_at  BIGINT       NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_intent_ref (gateway, gateway_ref),
    KEY idx_intent_booking (booking_id),
    KEY idx_intent_app (app_ref),
    CONSTRAINT fk_intent_booking FOREIGN KEY (booking_id) REFERENCES bookings (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ------------------------------------------------------------
   7. COMMS  (chat, notifications, support)
   ------------------------------------------------------------ */

-- Was db.chat{ bookingId: [{from, text, at}] }.
CREATE TABLE IF NOT EXISTS chat_messages (
    booking_id VARCHAR(16)  NOT NULL,
    seq        INT          NOT NULL,          -- per-booking ordering
    sender     ENUM('customer','pro','system') NOT NULL,
    text       VARCHAR(1000) NOT NULL,
    at         BIGINT       NOT NULL,
    PRIMARY KEY (booking_id, seq),
    CONSTRAINT fk_chat_booking FOREIGN KEY (booking_id) REFERENCES bookings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Was db.notifications[] (id 'N'+ms+rand, audience/refTo/type, cap 400).
CREATE TABLE IF NOT EXISTS notifications (
    id       VARCHAR(30) NOT NULL,
    audience ENUM('customer','pro','admin') NOT NULL,
    ref_to   VARCHAR(20) NOT NULL DEFAULT '',  -- booking/app id, pro id, '*' or ''
    type     VARCHAR(20) NOT NULL,
    text     VARCHAR(400) NOT NULL,
    at       BIGINT      NOT NULL,
    `read`   TINYINT(1)  NOT NULL DEFAULT 0,   -- 'read' is a reserved word: backticks required
    PRIMARY KEY (id),
    KEY idx_notif_aud (audience, ref_to, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- NOTE: ref_to is intentionally polymorphic (bookings, applications, disputes,
-- pro ids or '*') exactly as the sandbox used it — NO foreign key, only an
-- index. A pro-targeted FK would reject application/booking refs.

-- Learning-to-rank training capture: one row per automated matching
-- decision (createBooking / budget re-match / dispute rematch). The
-- FULL candidate pool is snapshotted with per-candidate match-time
-- features; `shown_ids` marks who was actually invited (and their
-- position); `outcome` joins the reward signal (quotes, accept,
-- completion, review rating, cancellation) later per booking.
-- Training tables are intentionally NOT FK-bound to bookings: the
-- data must outlive booking rows (and cleanup jobs) for retraining.
CREATE TABLE IF NOT EXISTS match_events (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    booking_id  VARCHAR(16)  NOT NULL,
    cat         VARCHAR(20)  NOT NULL,
    location    VARCHAR(160) NOT NULL,
    base_km     INT          NULL,            -- resolved km-from-Accra (NULL = unknown location)
    urgency     VARCHAR(12)  NOT NULL,
    budget      DECIMAL(10,2) NULL,
    event_date  DATE         NULL,
    engine      VARCHAR(32)  NOT NULL,        -- 'nearfirst-v1' (bump on engine/feature changes)
    candidates  JSON         NOT NULL,        -- full pool: [{proId,km,tier,respRank,rating,…}]
    shown_ids   JSON         NOT NULL,        -- [{proId,position}] — exposure label
    outcome     JSON         NOT NULL,        -- reward signal, filled in later
    created_at  BIGINT       NOT NULL,
    PRIMARY KEY (id),
    KEY idx_me_booking (booking_id),
    KEY idx_me_engine (engine, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Was db.supportMessages[] (ref 'MSG-XXXXX' random, status open/resolved).
CREATE TABLE IF NOT EXISTS support_messages (
    id          VARCHAR(16) NOT NULL,          -- 'SC-MSG-90001'
    ref         VARCHAR(10) NOT NULL,          -- 'MSG-XXXXX'
    name        VARCHAR(80) NOT NULL,
    phone       VARCHAR(20) NOT NULL,
    topic       ENUM('booking','payment','pro','complaint','suggestion','other') NOT NULL DEFAULT 'other',
    booking_ref VARCHAR(20) NULL,
    message     TEXT        NOT NULL,
    at          BIGINT      NOT NULL,
    status      ENUM('open','resolved') NOT NULL DEFAULT 'open',
    handled_at  BIGINT      NULL,
    handled_by  VARCHAR(40) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_support_ref (ref),
    KEY idx_support_status (status, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ------------------------------------------------------------
   8. ID COUNTERS + SESSIONS
   ------------------------------------------------------------ */

-- Was db.counters{} — nextId(kind) increments inside the API's
-- INSERT transaction (SELECT … FOR UPDATE) and applies the same
-- prefix map: booking SC-BK-, quote SC-Q-, msg SC-MSG-, app SC-APP-,
-- dispute SC-DS-, review SC-RV-, payout SC-PO-; txn falls back to SC-.
CREATE TABLE IF NOT EXISTS counters (
    kind  VARCHAR(12) NOT NULL,
    value BIGINT      NOT NULL,
    PRIMARY KEY (kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO counters (kind, value) VALUES
('booking', 284000), ('quote', 51000), ('msg', 90000), ('app', 300),
('dispute', 40), ('review', 7000), ('txn', 500000), ('payout', 100), ('pbatch', 0);

-- Server-side sessions (replaces localStorage sc_session_v2). Same model:
-- role-parameterized capability bound to the credential version (pv) that
-- was current at login — password changes invalidate existing rows.
-- TTL comes from settings.session_ttl_hours; sliding refresh updates
-- last_seen_at. Client keeps zero session state (httpOnly cookie carries
-- the token; localStorage mirror is optional read-through only).
CREATE TABLE IF NOT EXISTS sessions (
    token        CHAR(64)    NOT NULL,          -- random 32 bytes hex
    role         ENUM('admin','pro') NOT NULL,
    pro_id       VARCHAR(12) NULL,
    pv           BIGINT      NOT NULL DEFAULT 0,
    created_at   BIGINT      NOT NULL,
    last_seen_at BIGINT      NOT NULL,
    PRIMARY KEY (token),
    KEY idx_sess_pro (pro_id),
    CONSTRAINT fk_sess_pro FOREIGN KEY (pro_id) REFERENCES pros (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

/* ============================================================
   Seeding notes
   - categories / urgency_levels / cms / counters: seeded above
     (system config — exactly the sandbox defaults).
   - admin_auth: intentionally NULL — the API bootstraps it from
     settings.default_admin_password on first login (same as the
     sandbox ensureAdminAuth lazy-creation).
   - pros / bookings / transactions / … : entity data is NOT seeded
     here. The one-time importer (docs/backend-migration.md, Phase 5)
     loads a JSON export of a device's sc_db_v1 into these tables,
     so real sandbox data transfers byte-for-byte.
   ============================================================ */
