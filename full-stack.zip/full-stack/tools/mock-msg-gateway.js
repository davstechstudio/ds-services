#!/usr/bin/env node
/* ============================================================
   tools/mock-msg-gateway.js — minimal SMS/WhatsApp gateway stub
   for the smoke tests (the messaging twin of tools/mtn-mock.js).

   Implements the single endpoint the server's webhook adapter
   (server/src/notify-channels.js) POSTs:

     POST /send   { channel, to, text, type, proId, brand }
       → 200 { ok: true, channel, to, acceptedId }

   Behaviour rules (by destination MSISDN) mirror the payment
   mock's spirit:
     '233200000001' → 500 { error: 'carrier rejected' }  (failure path)
     anything else  → accepted

   GET /_sends?key=mock-msg-key → JSON list of received sends
   POST /_clear?key=mock-msg-key → wipe the log
   TEST-ONLY — never point production at this.
   ============================================================ */

'use strict';

const http = require('http');
const KEY = 'mock-msg-key';
const sends = [];
let seq = 0;

function createMsgMock(port) {
    const server = http.createServer(async (req, res) => {
        const u = new URL(req.url, 'http://localhost');
        const p = u.pathname;
        const readBody = () => new Promise(r => {
            let b = '';
            req.on('data', c => b += c);
            req.on('end', () => { try { r(b ? JSON.parse(b) : {}); } catch (e) { r({}); } });
        });

        if (p === '/send' && req.method === 'POST') {
            const body = await readBody();
            if (!body.channel || !body.to || !body.text) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ ok: false, error: 'channel, to and text are required' }));
            }
            if (body.to === '233200000001') {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ ok: false, error: 'carrier rejected' }));
            }
            const acceptedId = 'MSG-' + (++seq);
            sends.push({ acceptedId, at: Date.now(), channel: body.channel, to: body.to, type: body.type || '', proId: body.proId || null, text: body.text });
            if (sends.length > 200) sends.shift();
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ ok: true, channel: body.channel, to: body.to, acceptedId }));
        }

        if (p === '/_sends' && req.method === 'GET') {
            if (u.searchParams.get('key') !== KEY) { res.writeHead(403); return res.end('forbidden'); }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ ok: true, sends: sends.slice() }));
        }

        if (p === '/_clear' && req.method === 'POST') {
            if (u.searchParams.get('key') !== KEY) { res.writeHead(403); return res.end('forbidden'); }
            sends.length = 0;
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ ok: true }));
        }

        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'not found' }));
    });
    server.listen(port, () => console.log('[msg-mock] listening on http://localhost:' + port));
    return server;
}

if (require.main === module) {
    const port = Number(process.env.MSG_MOCK_PORT || 8398);
    createMsgMock(port);
}

module.exports = { createMsgMock };
