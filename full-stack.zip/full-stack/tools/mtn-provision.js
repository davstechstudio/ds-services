#!/usr/bin/env node
/* ============================================================
   tools/mtn-provision.js — one-time MTN MoMo provisioning.

   The MoMo developer portal gives you a SUBSCRIPTION key (Primary/
   Secondary pair on your product subscription). The Collections API
   additionally needs an API USER (a UUID we generate once) and that
   user's API KEY — both provisioned here against MTN's sandbox:

     1. POST /v1_0/apiuser            X-Reference-Id: <uuid we mint>
        body { providerCallbackHost }                 → 201 Created
     2. POST /v1_0/apiuser/<uuid>/apikey              → 201 { apiKey }
        (both calls need Ocp-Apim-Subscription-Key)
     Gateway quirks (verified live 2026-09): spelling is apiuser — no
     hyphen (older docs say api-user and 404); the apikey path must
     NOT have a trailing slash (with it the gateway 404s); a body
     (even empty) is required or the front door answers HTTP 411.

   Usage:
     node tools/mtn-provision.js <SUBSCRIPTION_KEY> [--host example.com]
   Env overrides: SC_MTN_BASE_URL, SC_MTN_TARGET_ENV (default sandbox).

   Prints ready-to-paste SC_MTN_* lines. The API user UUID is stored in
   SC_MTN_API_USER and must be reused forever after (it identifies the
   provisioned user) — rerunning mints a DIFFERENT user.
   ============================================================ */

'use strict';

const crypto = require('crypto');

const SUB_KEY = process.argv[2] || process.env.SC_MTN_SUBSCRIPTION_KEY || '';
const hostIdx = process.argv.indexOf('--host');
const CALLBACK_HOST = hostIdx > -1 ? process.argv[hostIdx + 1] : 'skillconnectgh.com';
const BASE = process.env.SC_MTN_BASE_URL || 'https://sandbox.momodeveloper.mtn.com';
const TARGET = process.env.SC_MTN_TARGET_ENV || 'sandbox';

if (!SUB_KEY) {
    console.error('Usage: node tools/mtn-provision.js <SUBSCRIPTION_KEY> [--host yourdomain.com]');
    process.exit(1);
}

(async () => {
    const apiUser = crypto.randomUUID();
    console.log('Provisioning MTN API user on', BASE, '(target env:', TARGET + ')');

    let r = await fetch(BASE + '/v1_0/apiuser', {
        method: 'POST',
        headers: {
            'Ocp-Apim-Subscription-Key': SUB_KEY,
            'X-Reference-Id': apiUser,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ providerCallbackHost: CALLBACK_HOST })
    });
    if (r.status !== 201) {
        const t = await r.text().catch(() => '');
        console.error('api-user creation failed: HTTP', r.status, t.slice(0, 300));
        process.exit(1);
    }
    console.log('api-user created:', apiUser);

    r = await fetch(BASE + '/v1_0/apiuser/' + apiUser + '/apikey', {
        method: 'POST',
        headers: { 'Ocp-Apim-Subscription-Key': SUB_KEY },
        body: ''   /* bodyless POST gets HTTP 411 from the front door */
    });
    const j = await r.json().catch(() => ({}));
    if (r.status !== 201 || !j.apiKey) {
        console.error('apikey creation failed: HTTP', r.status, JSON.stringify(j).slice(0, 300));
        process.exit(1);
    }

    console.log('\n--- add to server/.env (git-ignored) ---');
    console.log('SC_MTN_BASE_URL=' + BASE);
    console.log('SC_MTN_TARGET_ENV=' + TARGET);
    console.log('SC_MTN_SUBSCRIPTION_KEY=' + SUB_KEY);
    console.log('SC_MTN_API_USER=' + apiUser);
    console.log('SC_MTN_API_KEY=' + j.apiKey);
    console.log('-----------------------------------------');
})().catch(e => { console.error('PROVISION FAILED:', e.message); process.exit(1); });
