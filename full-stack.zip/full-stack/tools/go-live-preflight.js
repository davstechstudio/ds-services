#!/usr/bin/env node
/* ============================================================
   tools/go-live-preflight.js — read-only launch checklist.

   Checks every go-live blocker and prints a GO / NO-GO verdict:
     - infra        reset/sandbox locks, secure cookies, DB up
     - schema       scrypt auth columns widened
     - credentials  admin & pro default passwords changed
     - payments     Paystack webhook secret configured
     - security     admin API + /api/reset refuse anonymous calls,
                    /api/health responds
   Run ON the deployment: node tools/go-live-preflight.js [baseUrl]
   Exits 0 = GO, 1 = NO-GO.
   ============================================================ */

'use strict';

const path = require('path');
const ROOT = path.join(__dirname, '..');

function readEnvFile(p) {
    try {
        const out = {};
        require('fs').readFileSync(p, 'utf8').split(/\r?\n/).forEach(line => {
            const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
            if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
        });
        return out;
    } catch (e) { return {}; }
}
const envFile = readEnvFile(path.join(ROOT, 'server', '.env'));
const env = k => process.env['SC_' + k] !== undefined ? process.env['SC_' + k] : envFile['SC_' + k];

const results = [];
function check(area, name, ok, detail) {
    results.push({ area, name, ok: !!ok, detail: detail === undefined ? '' : String(detail) });
}

(async () => {
    /* ---------- infra locks ---------- */
    const ALLOW_RESET = (env('ALLOW_RESET') || 'false') === 'true';
    check('infra', '/api/reset locked (SC_ALLOW_RESET)', !ALLOW_RESET, ALLOW_RESET ? 'ENABLED — dev only!' : 'locked');
    const HOOKS = (env('ALLOW_SANDBOX_HOOKS') || 'false') === 'true';
    check('infra', 'sandbox hooks locked (SC_ALLOW_SANDBOX_HOOKS)', !HOOKS, HOOKS ? 'ENABLED — dev only!' : 'locked');
    const INSECURE = (env('INSECURE_COOKIES') || 'false') === 'true';
    check('infra', 'Secure cookies (SC_INSECURE_COOKIES)', !INSECURE, INSECURE ? 'insecure cookies ON' : 'Secure flag on');

    /* ---------- database + credentials + schema ---------- */
    let dbUp = false, adminDefault = null, proDefault = null;
    try {
        const config = require(path.join(ROOT, 'server', 'src', 'config'));
        config.infra.DB_HOST = env('DB_HOST') || '127.0.0.1';
        config.infra.DB_PORT = Number(env('DB_PORT') || 3306);
        config.infra.DB_USER = env('DB_USER') || 'skillconnect';
        config.infra.DB_PASS = env('DB_PASS') || '';
        config.infra.DB_NAME = env('DB_NAME') || 'skillconnect';
        const db = require(path.join(ROOT, 'server', 'src', 'db'));
        await db.init();
        dbUp = true;
        check('infra', 'database reachable', true);
        const api = require(path.join(ROOT, 'server', 'src', 'sc-api'));
        adminDefault = await api.adminUsesDefaultPassword();
        proDefault = await api.proUsesDefaultPassword('P1001');
        const [cols] = await db.q(
            "SELECT CHARACTER_MAXIMUM_LENGTH AS n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'pros' AND COLUMN_NAME = 'auth_hash'",
            [config.infra.DB_NAME]);
        check('schema', 'auth columns widened for scrypt', !!cols[0] && Number(cols[0].n) >= 255, cols[0] ? 'auth_hash len=' + cols[0].n : 'missing');
    } catch (e) {
        check('infra', 'database reachable', false, e.code || e.message);
    }
    check('credentials', 'admin default password changed', adminDefault === false, adminDefault === null ? 'unknown' : (adminDefault ? 'STILL default' : 'custom set'));
    check('credentials', 'pro default password changed (P1001)', proDefault === false, proDefault === null ? 'unknown' : (proDefault ? 'STILL default' : 'custom set'));

    /* ---------- payments ---------- */
    const secret = env('PAYSTACK_SECRET') || '';
    check('payments', 'Paystack webhook secret configured', !!secret && secret !== 'whsec_smoketest', secret ? 'set' : 'missing');

    /* ---------- security (live HTTP) ---------- */
    const BASE = process.argv[2] || 'http://127.0.0.1:8200';
    const post = (p, body) => fetch(BASE + '/api/' + p, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {})
    }).then(r => r.json()).catch(() => null);

    const stats = await post('adminStats', {});
    check('security', 'admin API refuses anonymous calls', !!stats && stats.ok === false, stats && stats.error);
    const resetProbe = await post('reset', {});
    check('security', '/api/reset refuses anonymous calls', !!resetProbe && resetProbe.ok === false, resetProbe && resetProbe.error);
    const health = await post('health', {});
    check('security', '/api/health responds', !!health, health && health.status);

    /* ---------- verdict ---------- */
    const failed = results.filter(r => !r.ok);
    let area = '';
    results.forEach(r => {
        if (r.area !== area) { area = r.area; console.log('\n[' + area + ']'); }
        console.log('  ' + (r.ok ? 'PASS' : 'FAIL') + '  ' + r.name + (r.detail ? '  — ' + r.detail : ''));
    });
    console.log('\n=== ' + (failed.length ? 'NO-GO: ' + failed.length + ' blocker(s)' : 'GO — launch checklist satisfied') + ' ===');
    process.exit(failed.length ? 1 : 0);
})();
