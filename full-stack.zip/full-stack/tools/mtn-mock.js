#!/usr/bin/env node
/* ============================================================
   tools/mtn-mock.js — minimal MTN MoMo Collections stub for the
   smoke tests. Implements just enough of the Collection API:
     POST /collection/token/
     POST /collection/v1_0/requesttopay        (202, X-Reference-Id)
     GET  /collection/v1_0/requesttopay/:id    (PENDING → SUCCESSFUL/FAILED)

   Simulation rules (by payer MSISDN):
     ends 006 → PENDING on the first poll, SUCCESSFUL from the second on
     ends 9999 → FAILED immediately
     anything else → stays PENDING forever
   TEST-ONLY — never point production at this.
   ============================================================ */

'use strict';

const http = require('http');

const collections = new Map();   /* referenceId → { status, externalId, amount, currency, payer } */
const TOKEN = 'mock-mtn-token';

function createMtnMock(port) {
    const server = http.createServer(async (req, res) => {
        const u = new URL(req.url, 'http://localhost');
        const p = u.pathname;
        const readBody = () => new Promise(r => {
            let b = '';
            req.on('data', c => b += c);
            req.on('end', () => { try { r(b ? JSON.parse(b) : {}); } catch (e) { r({}); } });
        });

        if (p === '/collection/token/' && req.method === 'POST') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ access_token: TOKEN, token_type: 'Bearer', expires_in: 3600 }));
        }

        if (p === '/collection/v1_0/requesttopay' && req.method === 'POST') {
            const body = await readBody();
            const ref = req.headers['x-reference-id'];
            if (!ref) { res.writeHead(400, { 'Content-Type': 'application/json' }); return res.end('{"message":"missing X-Reference-Id"}'); }
            if (!body.payer || !body.payer.partyId) { res.writeHead(400, { 'Content-Type': 'application/json' }); return res.end('{"message":"payer.partyId required"}'); }
            collections.set(ref, {
                status: 'PENDING', externalId: body.externalId,
                amount: body.amount, currency: body.currency, payer: String(body.payer.partyId)
            });
            res.writeHead(202);
            return res.end();
        }

        const m = p.match(/^\/collection\/v1_0\/requesttopay\/([0-9a-fA-F-]+)$/);
        if (m && req.method === 'GET') {
            const rec = collections.get(m[1]);
            if (!rec) { res.writeHead(404, { 'Content-Type': 'application/json' }); return res.end('{"message":"target resource not found"}'); }
            rec.polls = (rec.polls || 0) + 1;
            if (rec.status === 'PENDING' && rec.payer.endsWith('9999')) rec.status = 'FAILED';
            else if (rec.status === 'PENDING' && rec.payer.endsWith('006') && rec.polls >= 2) rec.status = 'SUCCESSFUL';
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({
                status: rec.status, externalId: rec.externalId,
                amount: rec.amount, currency: rec.currency,
                payer: { partyIdType: 'MSISDN', partyId: rec.payer }
            }));
        }

        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end('{"message":"unknown route"}');
    });
    return new Promise(resolve => server.listen(port, '127.0.0.1', () => resolve(server)));
}

module.exports = { createMtnMock };

if (require.main === module) {
    const port = Number(process.argv[2]) || 8399;
    createMtnMock(port).then(() => console.log('[mtn-mock] listening on 127.0.0.1:' + port));
}
