#!/usr/bin/env node
/* ============================================================
   tools/load-test.js — concurrency verification for the SC API.

   Proves simultaneous mixed usage (customers + workers + admins +
   snapshot hydrations) against ONE live instance:
     - no crashes / 5xx storms / deadlocks
     - money integrity: pro balance = pre-load balance + Σ service
       payments − Σ commissions (every cedi accounted for)
     - uniqueness: no duplicate booking refs under parallel creation
     - latency percentiles per role

   Usage: node tools/load-test.js [baseUrl]   (default :8226)
   NOTE: resets the database through /api/reset (sandbox_mode) —
   never point this at production data.
   ============================================================ */

'use strict';

const BASE = process.argv[2] || 'http://localhost:8226';
const CUSTOMERS = Number(process.env.LT_CUSTOMERS || 12);
const QUOTES_PER = 3;                 /* simulated auto-quotes per booking */
const ADMINS = 4;
const HYDRATORS = 6;                  /* concurrent sync-bridge page loads */

let passed = 0, failed = 0;
function check(name, cond, extra) {
    if (cond) { passed++; console.log('  PASS', name); }
    else { failed++; console.log('  FAIL', name, extra !== undefined ? JSON.stringify(extra).slice(0, 300) : ''); }
}

async function call(fn, args) {
    const res = await fetch(BASE + '/api/' + fn, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ args: args || [] }),
        signal: AbortSignal.timeout(30000)   /* fail fast instead of hanging the run */
    });
    const j = await res.json();
    return { status: res.status, body: j && j.ok !== undefined && 'result' in j ? j.result : j };
}

/* Dedicated routes (payments/*) take a plain JSON body. */
async function callRaw(path, body) {
    const res = await fetch(BASE + '/api/' + path, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body || {})
    });
    return { status: res.status, body: await res.json() };
}

/* Timed call: returns [ms, {status, body}]. */
async function timed(fn, args) {
    const t0 = Date.now();
    const r = await call(fn, args);
    return [Date.now() - t0, r];
}

function pct(sorted, p) {
    if (!sorted.length) return 0;
    const i = Math.min(sorted.length - 1, Math.floor(p / 100 * sorted.length));
    return sorted[i];
}
function stats(arr) {
    const s = arr.slice().sort((a, b) => a - b);
    return { n: s.length, p50: pct(s, 50), p95: pct(s, 95), max: s[s.length - 1] || 0 };
}

(async () => {
    console.log('Load test against', BASE);
    console.log('[0] reset + pre-load money snapshot');
    const rs = await call('reset');
    check('reset ok', rs.body && rs.body.ok, rs.body);
    /* The gateway setting survives /api/reset by design — force simulated
       mode for the sandbox money loop, restoring the previous value after. */
    const gwBefore = (await callRaw('payments/gateway', { adminSession: '1' })).body.gateway;
    await callRaw('payments/gateway', { adminSession: '1', gateway: '' });

    const pros = (await call('getPros')).body;
    const PROS = pros.filter(p => p.id >= 'P1001' && p.id <= 'P1012');
    const beforeBalances = {};
    for (const p of PROS) beforeBalances[p.id] = Number((await call('getPro', [p.id])).body.balance);

    /* ---------- Phase A: parallel booking storm (uniqueness + 5xx) ---------- */
    console.log('[A] ' + CUSTOMERS + ' customers create bookings simultaneously');
    const jobs = [];
    for (let i = 0; i < CUSTOMERS; i++) {
        jobs.push((async () => {
            const [ms, r] = await timed('createBooking', [{
                name: 'Load Cust ' + i, phone: '02477700' + String(10 + i).slice(-2),
                cat: ['mc', 'handy', 'photographer', 'dj'][i % 4], location: i % 2 ? 'Accra' : 'Tema',
                /* budget ≥ the category's cheapest pro price (mc 500, handy 150,
                   photographer 600, dj 900): the budget ceiling would otherwise
                   legitimately match nothing for under-budget requests. */
                budget: [500, 150, 600, 900][i % 4] + i, urgency: i % 3 ? 'planned' : 'urgent'
            }]);
            return { ms, r };
        })());
    }
    const A = await Promise.all(jobs);
    /* createBooking resolves to the booking object itself (no {ok} wrapper):
       success = HTTP 200 + an id + no {ok:false} error object. */
    const okCreate = x => x.r.status === 200 && x.r.body && x.r.body.id && x.r.body.ok !== false;
    const aOk = A.filter(okCreate);
    const aRefs = aOk.map(x => x.r.body.id);
    check('all bookings created without error', aOk.length === CUSTOMERS, A.filter(x => !okCreate(x)).map(x => x.r.body));
    check('zero 5xx during booking storm', A.every(x => x.r.status < 500), A.map(x => x.r.status));
    check('booking refs unique under parallelism', aRefs.length === CUSTOMERS && new Set(aRefs).size === aRefs.length, aRefs);
    check('refs follow the counter sequence', aRefs.every(id => /^SC-BK-\d+$/.test(id)), aRefs);

    /* ---------- Phase B: quote + escrow + release per booking, all in parallel ---------- */
    console.log('[B] concurrent accept → escrow(simulated) → release across all bookings');
    const B = await Promise.all(aRefs.map(async ref => {
        const statuses = [];
        const [ms, q] = await timed('getQuotesFor', [ref]); statuses.push(q.status);
        if (!q.body || !q.body.length) return { ref, ms, ok: false, err: 'no quotes', statuses };
        const acc = await timed('acceptQuote', [q.body[0].id]); statuses.push(acc[1].status);
        /* acceptQuote resolves to the quote object with status 'accepted' (no {ok} wrapper). */
        if (!acc[1].body || acc[1].body.status !== 'accepted') return { ref, ms: ms + acc[0], ok: false, err: acc[1].body, statuses };
        const pay = await timed('payIntoEscrow', [ref, 'momo', '0247770001']); statuses.push(pay[1].status);
        if (!pay[1].body || !pay[1].body.ok) return { ref, ms: ms + acc[0] + pay[0], ok: false, err: pay[1].body, statuses };
        const rel = await timed('releaseEscrow', [ref]); statuses.push(rel[1].status);
        return { ref, ms: ms + acc[0] + pay[0] + rel[0], ok: !!(rel[1].body && rel[1].body.ok), err: rel[1].body && rel[1].body.error, statuses, amount: rel[1].body && rel[1].body.booking && rel[1].body.booking.amount, commission: rel[1].body && rel[1].body.commission };
    }));
    const bOk = B.filter(x => x.ok);
    check('full money loop completed for every booking', aRefs.length === CUSTOMERS && bOk.length === CUSTOMERS, B.filter(x => !x.ok).map(x => [x.ref, x.err]));
    check('zero 5xx in money loop', B.every(x => x.statuses.every(s => s < 500)), B.flatMap(x => x.statuses).filter(s => s >= 500));

    /* ---------- Phase C: admins hammering reads + snapshot hydrations ---------- */
    console.log('[C] ' + ADMINS + ' admin readers × 15 rounds + ' + HYDRATORS + ' simultaneous page hydrations');
    const adminJobs = [];
    for (let a = 0; a < ADMINS; a++) {
        adminJobs.push((async () => {
            const lat = [];
            let errs = 0;
            for (let i = 0; i < 15; i++) {
                const [ms, r] = await timed(['adminStats', 'allBookings', 'getTransactions', 'getApplications'][i % 4]);
                lat.push(ms);
                if (r.status !== 200) errs++;
            }
            return { lat, errs };
        })());
    }
    const hydraJobs = [];
    for (let h = 0; h < HYDRATORS; h++) {
        hydraJobs.push(fetch(BASE + '/api/snapshot').then(r => r.json()).then(j => ({ ok: j.ok && j.db && j.db.pros.length === 12 })).catch(() => ({ ok: false })));
    }
    const C = await Promise.all(adminJobs);
    const H = await Promise.all(hydraJobs);
    check('admin read bursts: zero non-200s', C.every(c => c.errs === 0), C.map(c => c.errs));
    check('all parallel snapshot hydrations complete', H.every(h => h.ok), H.filter(h => !h.ok).length);

    /* ---------- Phase D: workers acting simultaneously ---------- */
    console.log('[D] 12 workers act simultaneously (availability toggle + booking view)');
    const D = await Promise.all(PROS.map(async (p, i) => {
        const t1 = await timed('toggleProDate', [p.id, '2026-12-0' + ((i % 8) + 1)]);
        const t2 = await timed('proBookings', [p.id]);
        return { id: p.id, ok: (t1[1].body || {}).ok !== false && t2[1].status === 200, ms: t1[0] + t2[0] };
    }));
    check('worker actions: all succeeded', D.every(d => d.ok), D.filter(d => !d.ok));

    /* ---------- Money integrity reconciliation ---------- */
    console.log('[E] money integrity: every cedi accounted for');
    const txns = (await call('getTransactions')).body;
    const sp = txns.filter(t => t.type === 'service_payment');
    const comm = txns.filter(t => t.type === 'commission');
    check('every completed booking ledgered exactly once', sp.length === bOk.length && comm.length === bOk.length && bOk.length === CUSTOMERS, [sp.length, comm.length, bOk.length]);
    const perPro = {};
    for (const t of sp) perPro[t.proId] = (perPro[t.proId] || 0) + Number(t.amount);
    for (const t of comm) perPro[t.proId] = (perPro[t.proId] || 0) - Number(t.amount);
    let drift = [];
    for (const p of PROS) {
        const expect = beforeBalances[p.id] + (perPro[p.id] || 0);
        const actual = Number((await call('getPro', [p.id])).body.balance);
        if (Math.abs(expect - actual) > 0.005) drift.push([p.id, expect, actual]);
    }
    check('pro balances = seed + Σ(service_payment − commission), zero drift', drift.length === 0, drift);
    const totalSP = sp.reduce((s, t) => s + Number(t.amount), 0);
    const totalComm = comm.reduce((s, t) => s + Number(t.amount), 0);
    check('Σ service payments matches Σ booking amounts', Math.abs(totalSP - bOk.reduce((s, x) => s + x.amount, 0)) < 0.01, [totalSP, bOk.reduce((s, x) => s + x.amount, 0)]);
    check('commission = round(10%) on every row', comm.every(t => {
        const b = B.find(x => x.ref === t.bookingId);
        return b && Math.abs(Number(t.amount) - Math.round(b.amount * 0.10)) < 0.01;
    }), null);

    /* ---------- Latency report ---------- */
    const aLat = stats(A.map(x => x.ms));
    const bLat = stats(B.map(x => x.ms));
    const cLat = stats(C.flatMap(c => c.lat));
    const dLat = stats(D.map(d => d.ms));
    console.log('\nLatency (ms)  p50 / p95 / max');
    console.log('  booking create     ', aLat.p50, '/', aLat.p95, '/', aLat.max);
    console.log('  accept+escrow+release', bLat.p50, '/', bLat.p95, '/', bLat.max);
    console.log('  admin reads        ', cLat.p50, '/', cLat.p95, '/', cLat.max);
    console.log('  worker actions     ', dLat.p50, '/', dLat.p95, '/', dLat.max);
    console.log('  ledger rows:', txns.length, '· service_payments:', sp.length, '· commissions:', comm.length);

    /* leave the instance exactly as we found it */
    await callRaw('payments/gateway', { adminSession: '1', gateway: gwBefore });

    console.log('\n=== ' + passed + ' passed, ' + failed + ' failed ===');
    process.exit(failed ? 1 : 0);
})().catch(e => { console.error('LOAD TEST CRASHED:', e && e.stack || e); process.exit(1); });
