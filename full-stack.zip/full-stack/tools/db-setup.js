#!/usr/bin/env node
/* ============================================================
   tools/db-setup.js — one-shot database bootstrap
   Creates the database + app user (idempotent) and imports
   db/schema.sql. Uses an ADMIN connection (e.g. XAMPP root),
   NOT the app credentials:

     SC_DB_HOST=127.0.0.1 SC_DB_PORT=3306 \
     SC_DB_ADMIN_USER=root SC_DB_ADMIN_PASS= \
     SC_DB_NAME=skillconnect SC_DB_USER=skillconnect SC_DB_PASS=secret \
     node tools/db-setup.js

   Safe to re-run: CREATE DATABASE IF NOT EXISTS, CREATE USER IF
   NOT EXISTS, schema import runs once (stops if tables exist).
   ============================================================ */

'use strict';

const fs = require('fs');
const path = require('path');
/* mysql2 lives in server/node_modules; resolve from there when the script
   runs outside the server package (repo-root / CI / target server). */
let mysql;
try { mysql = require('mysql2/promise'); }
catch (e) { mysql = require(path.join(__dirname, '..', 'server', 'node_modules', 'mysql2', 'promise')); }

const HOST = process.env.SC_DB_HOST || '127.0.0.1';
const PORT = Number(process.env.SC_DB_PORT || 3306);
const ADMIN_USER = process.env.SC_DB_ADMIN_USER || 'root';
const ADMIN_PASS = process.env.SC_DB_ADMIN_PASS || '';
const DB_NAME = process.env.SC_DB_NAME || 'skillconnect';
const APP_USER = process.env.SC_DB_USER || 'skillconnect';
const APP_PASS = process.env.SC_DB_PASS || '';

(async () => {
    const admin = await mysql.createConnection({ host: HOST, port: PORT, user: ADMIN_USER, password: ADMIN_PASS, multipleStatements: true });
    await admin.query('CREATE DATABASE IF NOT EXISTS `' + DB_NAME + '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    for (const host of ['localhost', HOST, '%']) {
        try { await admin.query('CREATE USER IF NOT EXISTS `' + APP_USER + '`@`' + host + '` IDENTIFIED BY ?', [APP_PASS]); } catch (e) { /* already exists with another host spec */ }
        try { await admin.query('GRANT ALL PRIVILEGES ON `' + DB_NAME + '`.* TO `' + APP_USER + '`@`' + host + '`'); } catch (e) { /* grant may fail for % when host-specific exists */ }
    }
    await admin.query('FLUSH PRIVILEGES');
    await admin.query('USE `' + DB_NAME + '`');

    const [existing] = await admin.query('SHOW TABLES');
    if (existing.length) {
        console.log('Database "' + DB_NAME + '" already has ' + existing.length + ' tables — skipping schema import.');
    } else {
        const sql = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
        await admin.query(sql);
        const [tables] = await admin.query('SHOW TABLES');
        console.log('Schema imported — ' + tables.length + ' tables created in "' + DB_NAME + '".');
    }
    await admin.end();

    /* verify the app credentials actually connect */
    const app = await mysql.createConnection({ host: HOST, port: PORT, user: APP_USER, password: APP_PASS, database: DB_NAME });
    const [ok] = await app.query('SELECT COUNT(*) AS c FROM settings');
    await app.end();
    console.log('App user "' + APP_USER + '" connects OK (' + ok[0].c + ' settings rows). Start the API: cd server && npm start');
    process.exit(0);
})().catch(e => {
    console.error('DB setup failed:', e.message);
    process.exit(1);
});
