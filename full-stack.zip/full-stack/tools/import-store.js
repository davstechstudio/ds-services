#!/usr/bin/env node
/* ============================================================
   tools/import-store.js — one-time sandbox → MySQL importer
   (docs/backend-migration.md Phase 5 cutover step)

   1. Export the browser store: open any page with the sandbox
      loaded, run in DevTools console:
          copy(localStorage.getItem('sc_db_v1'))
      and paste the clipboard into a file, e.g. sc-db-export.json.
   2. Import the schema on the target server:
          mysql -u USER -p DBNAME < db/schema.sql
   3. Run (from the repo root or server/):
          node tools/import-store.js [path/to/sc-db-export.json]

   Behavior: single transaction (all-or-nothing), preserves every
   business id (P1001, SC-BK-284001, …) byte-for-byte, imports the
   sandbox's salted SHA-256 credential hashes as-is (logins keep
   working), keeps seeded reviews as booking_id NULL history rows,
   and prints a drift report of every skipped/mutated item.
   ============================================================ */

'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../server/src/config');
const db = require('../server/src/db');

function round2(n) { return Math.round(Number(n) * 100) / 100; }
function j(v) { return JSON.stringify(v === undefined ? null : v); }
function nOrNull(v) { return (v === undefined || v === null || v === '') ? null : Number(v); }
function sOrNull(v) { return (v === undefined || v === null) ? null : String(v); }

(async () => {
    const file = process.argv[2] || 'sc-db-export.json';
    const full = path.resolve(process.cwd(), file);
    if (!fs.existsSync(full)) {
        console.error('Export file not found: ' + full);
        console.error('Create it from the browser console on any sandbox page: copy(localStorage.getItem("sc_db_v1"))');
        process.exit(1);
    }
    let data;
    try { data = JSON.parse(fs.readFileSync(full, 'utf8')); }
    catch (e) { console.error('Not valid JSON:', e.message); process.exit(1); }
    if (!data.pros || !data.counters) {
        console.error('Not a sc_db_v1 export (missing pros/counters).');
        process.exit(1);
    }

    await db.init();
    const notes = [];
    const counts = {};

    try {
        await db.tx(async (conn) => {
            /* ---- settings defaults: fill ONLY missing keys (INSERT IGNORE) ---- */
            const defaults = [
                ['commission_rate', 0.10], ['default_reg_fee', 50], ['otp_ttl_minutes', 10],
                ['session_ttl_hours', 8], ['default_pro_password', 'skillconnect'],
                ['default_admin_password', '4321'], ['currency', 'GHS'],
                ['notifications_cap', 400], ['support_cap', 200], ['max_matches', 3],
                ['site_url', 'https://skillconnectgh.com'], ['sandbox_mode', true],
                ['id_valid_years', 5], ['id_warn_days', 60], ['portfolio_url_max_len', 300000]
            ];
            for (const [k, v] of defaults) {
                await conn.query('INSERT IGNORE INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?)',
                    [k, JSON.stringify(v), Date.now()]);
            }
            counts.settings = defaults.length;

            /* ---- CMS singleton ---- */
            if (data.cms) {
                await conn.query(
                    'UPDATE cms SET hero_title = ?, hero_sub = ?, announce_on = ?, announce_text = ?, reg_fee = ?, updated_at = ? WHERE id = 1',
                    [String(data.cms.heroTitle || '').slice(0, 160), sOrNull(data.cms.heroSub) || '',
                     data.cms.announceOn ? 1 : 0, sOrNull(data.cms.announceText) || '',
                     nOrNull(data.cms.regFee) || 50, Number(data.cms.updatedAt) || Date.now()]);
            }
            /* ---- admin credential: import hash pair so the real password survives ---- */
            if (data.cms && data.cms.adminAuth && data.cms.adminAuth.hash) {
                await conn.query('UPDATE admin_auth SET salt = ?, hash = ?, algo = ?, updated_at = ? WHERE id = 1',
                    [data.cms.adminAuth.salt, data.cms.adminAuth.hash, data.cms.adminAuth.algo || 'sha256', Number(data.cms.adminAuth.updatedAt) || 0]);
            }

            /* ---- pros ---- */
            counts.pros = 0;
            for (const p of (data.pros || [])) {
                const auth = p.auth || {};
                await conn.query(
                    `INSERT INTO pros (id, name, short_name, cat, role, city, rating, rating_count, bookings_count,
                        price, unit, note, phone, verified, emergency, response, years, languages, description,
                        earnings, commission_paid, balance, blocked, portfolio, joined_at, source, app_id,
                        reg_fee_paid, reg_fee_at,
                        id_type, id_number, tin, id_docs_received, id_front_name, id_back_name,
                        id_front_data, id_back_data, id_verified_at, id_reverify, id_submitted_at,
                        has_real_portfolio, auth_salt, auth_hash, auth_algo, auth_updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [p.id, p.name, p.short || (p.name || '').split(' ')[0] || p.id, p.cat, p.role || p.cat, p.city,
                     Number(p.rating) || 0, p.ratingCount || 0, p.bookings || 0,
                     Number(p.price) || 0, p.unit || 'visit', sOrNull(p.note), p.phone,
                     p.verified ? 1 : 0, p.emergency ? 1 : 0, p.response || 'sameday', p.years || '0-2',
                     j(p.languages || []), sOrNull(p.desc),
                     round2(p.earnings || 0), round2(p.commissionPaid || 0), round2(p.balance || 0),
                     j(p.blocked || []), Array.isArray(p.portfolio) ? j(p.portfolio) : null,
                     Number(p.joinedAt) || Date.now(), p.source || 'seed', sOrNull(p.appId),
                     p.regFeePaid ? 1 : 0, nOrNull(p.regFeeAt),
                     sOrNull(p.idType), sOrNull(p.idNumber), sOrNull(p.tin),
                     p.idDocsReceived ? 1 : 0, sOrNull(p.idFrontName), sOrNull(p.idBackName),
                     sOrNull(p.idFrontData), sOrNull(p.idBackData), nOrNull(p.idVerifiedAt),
                     sOrNull(p.idReverify) || null, nOrNull(p.idSubmittedAt),
                     p.hasRealPortfolio ? 1 : 0,
                     sOrNull(auth.salt), sOrNull(auth.hash), sOrNull(auth.algo), Number(auth.updatedAt) || 0]);
                counts.pros++;
            }

            /* ---- applications ---- */
            counts.applications = 0;
            for (const a of (data.applications || [])) {
                await conn.query(
                    `INSERT INTO applications (id, name, phone, whatsapp, email, city, cat, years, spec, description,
                        languages, portfolio_url, social, samples, id_type, id_number, tin,
                        id_front_name, id_back_name, id_front_data, id_back_data,
                        rate, unit, emergency, response, momo, days,
                        status, source, admin_note, edited_fields, edited_at, submitted_at, reviewed_at,
                        reg_fee_paid, reg_fee_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [a.id, a.name, a.phone, sOrNull(a.whatsapp), sOrNull(a.email), a.city, a.cat,
                     sOrNull(a.years), sOrNull(a.spec), sOrNull(a.desc),
                     j(a.languages || []), sOrNull(a.portfolioUrl), sOrNull(a.social), j(a.samples || []),
                     sOrNull(a.idType), sOrNull(a.idNumber), sOrNull(a.tin),
                     sOrNull(a.idFrontName), sOrNull(a.idBackName), sOrNull(a.idFrontData), sOrNull(a.idBackData),
                     nOrNull(a.rate), sOrNull(a.unit),
                     a.emergency === 'yes' ? 1 : (a.emergency === 'no' ? 0 : null),
                     sOrNull(a.response), sOrNull(a.momo), j(a.days || []),
                     a.status || 'pending', a.source || 'register-page', sOrNull(a.reviewNote),
                     a.editedFields ? j(a.editedFields) : null, nOrNull(a.editedAt),
                     Number(a.submittedAt) || Date.now(), nOrNull(a.reviewedAt),
                     a.regFeePaid ? 1 : 0, nOrNull(a.regFeeAt)]);
                counts.applications++;
            }

            /* ---- bookings (+ events + escrow) ---- */
            counts.bookings = 0; counts.booking_events = 0; counts.escrow = 0;
            for (const b of (data.bookings || [])) {
                await conn.query(
                    `INSERT INTO bookings (id, customer_name, customer_phone, cat, event_date, location, budget,
                        urgency, details, status, matched_pro_ids, chosen_pro_id, amount, commission, sla_hours,
                        created_at, reviewed, rematch_exclude, rematch_pick, pro_paid, pro_paid_at, pro_paid_method,
                        paid_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [b.id, b.name, b.phone, b.cat, b.date || null, b.location,
                     nOrNull(b.budget), b.urgency || 'planned', sOrNull(b.details), b.status || 'matching',
                     j(b.matchedProIds || []), sOrNull(b.chosenProId), Number(b.amount) || 0,
                     nOrNull(b.commission), nOrNull(b.slaHours),
                     Number(b.createdAt) || Date.now(), b.reviewed ? 1 : 0,
                     sOrNull(b.rematchExclude),
                     b.rematchPick === undefined || b.rematchPick === null ? null : (b.rematchPick ? 1 : 0),
                     b.proPaid ? 1 : 0, nOrNull(b.proPaidAt), sOrNull(b.proPaidMethod),
                     nOrNull(b.paidAt)]);
                counts.bookings++;
                for (let i = 0; i < (b.events || []).length; i++) {
                    const e = b.events[i];
                    counts.booking_events++;
                    await conn.query('INSERT INTO booking_events (booking_id, seq, at, text) VALUES (?, ?, ?, ?)',
                        [b.id, i, Number(e.at) || 0, String(e.text || '').slice(0, 500)]);
                }
                if (b.escrow) {
                    await conn.query(
                        'INSERT INTO escrow (booking_id, pro_id, method, paid_at, amount, released, released_at, txn_ref) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        [b.id, sOrNull(b.escrow.proId), b.escrow.method || 'momo', Number(b.escrow.paidAt) || 0,
                         Number(b.escrow.amount) || 0, b.escrow.released ? 1 : 0, nOrNull(b.escrow.releasedAt),
                         String(b.escrow.txnRef || ('ESC-IMPORT' + b.id)).slice(0, 24)]);
                    counts.escrow++;
                }
            }

            /* ---- quotes ---- */
            counts.quotes = 0;
            for (const q of (data.quotes || [])) {
                await conn.query(
                    'INSERT INTO quotes (id, booking_id, pro_id, price, eta_hours, message, status, created_at, eta_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [q.id, q.bookingId, q.proId, Number(q.price) || 0, q.etaHours || 24,
                     q.message || '', q.status || 'sent', Number(q.createdAt) || 0, Number(q.etaAt) || 0]);
                counts.quotes++;
            }

            /* ---- reviews (seeded pre-history rows: booking_id NULL) ---- */
            counts.reviews = 0;
            for (const r of (data.reviews || [])) {
                let bookingId = r.bookingId || null;
                if (bookingId && !/^SC-BK-\d+$/.test(bookingId)) {
                    notes.push({ item: 'review ' + r.id, reason: 'booking ref "' + bookingId + '" is sandbox seed history → stored with booking_id NULL' });
                    bookingId = null;
                }
                await conn.query(
                    'INSERT INTO reviews (id, booking_id, pro_id, by_name, rating, text, at) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [r.id, bookingId, r.proId, r.by || 'Verified Customer', r.rating || 5, r.text || '', Number(r.at) || 0]);
                counts.reviews++;
            }

            /* ---- disputes ---- */
            counts.disputes = 0;
            for (const d0 of (data.disputes || [])) {
                await conn.query(
                    'INSERT INTO disputes (id, booking_id, reason, details, status, note, opened_at, resolved_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [d0.id, d0.bookingId, d0.reason || 'other', sOrNull(d0.details), d0.status || 'open',
                     sOrNull(d0.note), Number(d0.openedAt) || 0, nOrNull(d0.resolvedAt)]);
                counts.disputes++;
            }

            /* ---- transactions ledger ---- */
            counts.transactions = 0;
            for (const t of (data.transactions || [])) {
                await conn.query(
                    'INSERT INTO transactions (id, type, booking_id, pro_id, amount, method, note, status, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [t.id, t.type, sOrNull(t.bookingId), sOrNull(t.proId), Number(t.amount) || 0,
                     t.method || 'momo', sOrNull(t.note), t.status || 'success', Number(t.at) || 0]);
                counts.transactions++;
            }

            /* ---- payout requests (declared but unwritten in the sandbox; import if present) ---- */
            counts.payout_requests = 0;
            for (const r of (data.payoutRequests || [])) {
                await conn.query(
                    'INSERT INTO payout_requests (id, pro_id, amount, method, status, requested_at, processed_at, processed_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [r.id, r.proId, Number(r.amount) || 0, r.method || 'momo', r.status || 'pending',
                     Number(r.requestedAt) || 0, nOrNull(r.processedAt), sOrNull(r.processedBy)]);
                counts.payout_requests++;
            }

            /* ---- chat (object keyed by bookingId) ---- */
            counts.chat_messages = 0;
            for (const [bookingId, msgs] of Object.entries(data.chat || {})) {
                for (let i = 0; i < (msgs || []).length; i++) {
                    const m = msgs[i];
                    await conn.query('INSERT INTO chat_messages (booking_id, seq, sender, text, at) VALUES (?, ?, ?, ?, ?)',
                        [bookingId, i, m.from || 'system', String(m.text || '').slice(0, 1000), Number(m.at) || 0]);
                    counts.chat_messages++;
                }
            }

            /* ---- notifications (ref_to polymorphic — no FK) ---- */
            counts.notifications = 0;
            for (const nt of (data.notifications || [])) {
                await conn.query(
                    'INSERT INTO notifications (id, audience, ref_to, type, text, at, `read`) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [String(nt.id).slice(0, 30), nt.audience, nt.refTo || '', nt.type || 'booking',
                     String(nt.text || '').slice(0, 400), Number(nt.at) || 0, nt.read ? 1 : 0]);
                counts.notifications++;
            }

            /* ---- support messages ---- */
            counts.support_messages = 0;
            for (const m of (data.supportMessages || [])) {
                await conn.query(
                    'INSERT INTO support_messages (id, ref, name, phone, topic, booking_ref, message, at, status, handled_at, handled_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [m.id, m.ref, m.name, m.phone, m.topic || 'other', sOrNull(m.bookingRef), m.message,
                     Number(m.at) || 0, m.status || 'open', nOrNull(m.handledAt), sOrNull(m.handledBy)]);
                counts.support_messages++;
            }

            /* ---- counters: imported verbatim (sandbox stores the LAST USED value) ---- */
            counts.counters = 0;
            for (const [kind, value] of Object.entries(data.counters)) {
                await conn.query('INSERT INTO counters (kind, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)',
                    [kind, Number(value) || 0]);
                counts.counters++;
            }
        });

        console.log('\n=== IMPORT COMPLETE ===');
        for (const [k, v] of Object.entries(counts)) console.log('  ' + k.padEnd(18) + v);
        if (notes.length) {
            console.log('\n=== DRIFT REPORT (' + notes.length + ') ===');
            notes.forEach(nt => console.log('  ~ ' + nt.item + ': ' + nt.reason));
        } else {
            console.log('\nDRIFT REPORT: none — export mapped cleanly.');
        }
        config.invalidate();
        console.log('\nNext: start the API (cd server && npm start) and smoke-test a page with ?api=1.');
        process.exit(0);
    } catch (e) {
        console.error('\nIMPORT FAILED — transaction rolled back, no partial data:', e.message);
        console.error(e.stack ? e.stack.split('\n').slice(0, 4).join('\n') : '');
        process.exit(1);
    }
})();
