#!/usr/bin/env node
/* ============================================================
   tools/make-icons.js — generate the PWA icon set from scratch
   (no image deps). Draws the SkillConnect brand mark: yellow
   rounded square, dark location-crosshairs badge with a "handshake"
   dot, matching the site's logo colors (#FFCC00 / #111).

   Output: icons/icon-192.png, icons/icon-512.png,
           icons/icon-maskable-512.png, icons/apple-touch-icon.png (180)
   Run:    node tools/make-icons.js
   ============================================================ */

'use strict';

/* ---------- minimal PNG encoder (zlib store + CRC) ---------- */
const zlib = require('zlib');
const fs = require('fs');
const path = require('path');

function crc32(buf) {
    let table = crc32.table;
    if (!table) {
        table = crc32.table = new Int32Array(256);
        for (let n = 0; n < 256; n++) {
            let c = n;
            for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
            table[n] = c;
        }
    }
    let c = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) c = table[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
}

function chunk(type, data) {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, crc]);
}

/* rows: Buffer array of RGBA rows → PNG buffer */
function encodePng(width, height, rows) {
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
    ihdr[8] = 8; ihdr[9] = 6;   // 8-bit RGBA
    const raw = Buffer.concat(rows.map(r => Buffer.concat([Buffer.from([0]), r])));
    return Buffer.concat([
        Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
        chunk('IHDR', ihdr),
        chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
        chunk('IEND', Buffer.alloc(0))
    ]);
}

/* ---------- brand drawing (RGBA canvas helpers) ---------- */
const BRAND = { yellow: [255, 204, 0, 255], dark: [17, 17, 17, 255], white: [255, 255, 255, 255] };

function canvas(size) { return { size, px: new Uint8ClampedArray(size * size * 4) }; }

function setPx(c, x, y, rgba, a) {
    if (x < 0 || y < 0 || x >= c.size || y >= c.size) return;
    const alpha = a === undefined ? 1 : a;
    if (alpha >= 1) {
        const i = (y * c.size + x) * 4;
        c.px[i] = rgba[0]; c.px[i + 1] = rgba[1]; c.px[i + 2] = rgba[2]; c.px[i + 3] = rgba[3];
    } else if (alpha > 0) {
        const i = (y * c.size + x) * 4;
        const na = rgba[3] * alpha, oa = c.px[i + 3];
        const outA = na + oa * (1 - na / 255);
        if (outA > 0) {
            c.px[i] = (rgba[0] * na + c.px[i] * oa * (1 - na / 255)) / outA;
            c.px[i + 1] = (rgba[1] * na + c.px[i + 1] * oa * (1 - na / 255)) / outA;
            c.px[i + 2] = (rgba[2] * na + c.px[i + 2] * oa * (1 - na / 255)) / outA;
        }
        c.px[i + 3] = outA;
    }
}

function fillCircle(c, cx, cy, r, rgba) {
    for (let y = Math.floor(cy - r) - 1; y <= cy + r + 1; y++)
        for (let x = Math.floor(cx - r) - 1; x <= cx + r + 1; x++) {
            const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
            if (d <= r) setPx(c, x, y, rgba);
            else if (d <= r + 1) setPx(c, x, y, rgba, r + 1 - d);   // soft edge
        }
}

function ringCircle(c, cx, cy, r, w, rgba) {
    for (let y = Math.floor(cy - r - w); y <= cy + r + w + 1; y++)
        for (let x = Math.floor(cx - r - w); x <= cx + r + w + 1; x++) {
            const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
            if (d >= r - w / 2 && d <= r + w / 2) setPx(c, x, y, rgba);
        }
}

function fillRect(c, x0, y0, x1, y1, rgba) {
    for (let y = Math.round(y0); y <= Math.round(y1); y++)
        for (let x = Math.round(x0); x <= Math.round(x1); x++) setPx(c, x, y, rgba);
}

/* rounded-square background, radius = 22% of size (maskable keeps 80% safe zone) */
function roundedBg(c, rgba, radiusPct) {
    const r = c.size * (radiusPct || 0.22);
    for (let y = 0; y < c.size; y++)
        for (let x = 0; x < c.size; x++) {
            const qx = Math.max(r - (x + 0.5), (x + 0.5) - (c.size - r), 0);
            const qy = Math.max(r - (y + 0.5), (y + 0.5) - (c.size - r), 0);
            const d = Math.hypot(qx, qy);
            if (d <= r) setPx(c, x, y, rgba);
        }
}

/* The mark: dark rounded square + yellow crosshairs ring + center dot.
   Deliberately bold and simple so it reads at 48px. */
function drawIcon(size, opts) {
    const c = canvas(size);
    const bg = (opts && opts.maskable) ? BRAND.yellow : BRAND.yellow;
    roundedBg(c, bg, opts && opts.maskable ? 0 : 0.22);
    const darkPad = opts && opts.maskable ? 0.30 : 0.14;   // maskable: keep mark inside 80% safe zone
    const d0 = size * darkPad, d1 = size * (1 - darkPad);
    fillRect(c, d0, d0, d1, d1, BRAND.dark);
    // rounded corners on the dark square: punch with bg-colored corner circles
    const cr = size * 0.10;
    const corners = [[d0, d0], [d1, d0], [d0, d1], [d1, d1]];
    corners.forEach(([cx, cy]) => {
        for (let y = Math.floor(cy - cr) - 1; y <= cy + cr + 1; y++)
            for (let x = Math.floor(cx - cr) - 1; x <= cx + cr + 1; x++) {
                const inX = (cx === d0) ? x + 0.5 < cx : x + 0.5 > cx;
                const inY = (cy === d0) ? y + 0.5 < cy : y + 0.5 > cy;
                if (inX && inY && Math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= cr) setPx(c, x, y, bg);
            }
    });

    const cx = size / 2, cy = size / 2;
    const ringR = size * 0.26, ringW = size * 0.075;
    ringCircle(c, cx, cy, ringR, ringW, BRAND.yellow);
    // crosshair ticks (N/E/S/W) reaching outward
    const tickL = size * 0.10, tickW = size * 0.045;
    fillRect(c, cx - tickW / 2, cy - ringR - tickL, cx + tickW / 2, cy - ringR + tickW / 2, BRAND.yellow);
    fillRect(c, cx - tickW / 2, cy + ringR - tickW / 2, cx + tickW / 2, cy + ringR + tickL, BRAND.yellow);
    fillRect(c, cx - ringR - tickL, cy - tickW / 2, cx - ringR + tickW / 2, cy + tickW / 2, BRAND.yellow);
    fillRect(c, cx + ringR - tickW / 2, cy - tickW / 2, cx + ringR + tickL, cy + tickW / 2, BRAND.yellow);
    // center dot (the "you are here" pin point)
    fillCircle(c, cx, cy, size * 0.085, BRAND.yellow);
    return c;
}

function save(c, file) {
    const rows = [];
    for (let y = 0; y < c.size; y++) rows.push(Buffer.from(c.px.buffer, y * c.size * 4, c.size * 4));
    const out = path.join(__dirname, '..', 'icons', file);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, encodePng(c.size, c.size, rows));
    console.log('[icons] wrote', out, Math.round(fs.statSync(out).size / 1024) + ' KB');
}

save(drawIcon(192, {}), 'icon-192.png');
save(drawIcon(512, {}), 'icon-512.png');
save(drawIcon(512, { maskable: true }), 'icon-maskable-512.png');
save(drawIcon(180, {}), 'apple-touch-icon.png');
console.log('[icons] done');
