#!/usr/bin/env node
/* Contrast auditor: computes WCAG 2.1 contrast ratios for the text/background
 * combinations used by the SkillConnect design system, in BOTH themes.
 * Fail threshold: 4.5:1 (all audited text is small/bold UI text, not "large").
 *
 * Run: node tools/contrast-audit.js
 */
'use strict';

/* ---------- colour math ---------- */
function parseColor(str) {
  str = str.trim();
  if (str.startsWith('#')) {
    const h = str.slice(1);
    if (h.length === 3) return [0, 1, 2].map(i => parseInt(h[i] + h[i], 16));
    return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16));
  }
  const m = str.match(/rgba?\(([^)]+)\)/);
  if (m) {
    const parts = m[1].split(',').map(s => parseFloat(s.trim()));
    return { rgb: parts.slice(0, 3), alpha: parts.length > 3 ? parts[3] : 1 };
  }
  throw new Error('Cannot parse colour: ' + str);
}
function isRGBA(c) { return typeof c === 'object' && Array.isArray(c.rgb); }

function linearize(channel) {
  const c = channel / 255;
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}
function luminance(rgb) {
  return 0.2126 * linearize(rgb[0]) + 0.7152 * linearize(rgb[1]) + 0.0722 * linearize(rgb[2]);
}
/* composite a (possibly translucent) fg colour over an opaque bg colour */
function composite(fg, bg) {
  const f = parseColor(fg);
  if (!isRGBA(f)) return f;
  const a = f.alpha, base = parseColor(bg);
  return f.rgb.map((ch, i) => Math.round(ch * a + base[i] * (1 - a)));
}
function ratio(fgStr, bgStr) {
  const bg = parseColor(bgStr);
  const fg = composite(fgStr, bgStr);
  const L1 = luminance(fg), L2 = luminance(bg);
  return (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
}
const fmt = n => n.toFixed(2);

/* ---------- theme tables (mirrors styles.css) ---------- */
/* Surfaces: which backdrop each kind of text sits on. */
const DARK = {
  page: '#111111', card: '#252525', inset: '#1a1a1a', well: '#000000',
  accentText: '#FFCC00',
  textMuted: '#CCCCCC', textFaint: '#909090', availOkText: '#d6fbe2',
  warnAmberText: '#f5e6a8', successSurfaceText: '#b8f0cd', dangerSurfaceText: '#ffb3ab',
  warnBadgeText: '#fde68a', dangerBadgeText: '#fecaca', onAccent: '#04310f',
  successGreen: '#25D366', dangerRed: '#ff5a47',
};
const LIGHT = {
  page: '#f4f6f2', card: '#ffffff', inset: '#f0f2ec', well: '#f0f2ec',
  accentText: '#816200',
  textMuted: '#4c594a', textFaint: '#5c6655',
  warnAmberText: '#6b5200', successSurfaceText: '#0c6b39', dangerSurfaceText: '#8f281c',
  /* badge text vars NO LONGER flip dark — badge fills are fixed dark in both
     themes, so badge text stays light in both (post-fix values). */
  warnBadgeText: '#ffe9ad', dangerBadgeText: '#ffd4cd', availOkText: '#d6fbe2', onAccent: '#ffffff',
  successGreen: '#0c7a40', dangerRed: '#b73225',
};

/* Fixed (non-flipping) badge fills from styles.css */
const FILLS = {
  availAvailable: '#187040',
  availBooked: '#7f1d1d',
  availOnRequest: '#78350f',
};
/* Fill over a light card (worst case in light theme) and over dark card */
/* Fills are now SOLID, so they composite to themselves in both themes. */
const FILL_COMPOSITE_LIGHT = {
  availAvailable: FILLS.availAvailable,
  availBooked: FILLS.availBooked,
  availOnRequest: FILLS.availOnRequest,
};
const FILL_COMPOSITE_DARK = FILL_COMPOSITE_LIGHT;
/* ---------- audit pairs ---------- */
const rows = [];
function add(theme, label, fg, bg, note) {
  rows.push({ theme, label, fg, bg, ratio: ratio(fg, bg), note: note || '' });
}

for (const [name, T] of [['dark', DARK], ['light', LIGHT]]) {
  const F = name === 'light' ? FILL_COMPOSITE_LIGHT : FILL_COMPOSITE_DARK;

  /* body & secondary text */
  add(name, 'heading/body text on card', name === 'dark' ? '#ffffff' : '#1c2b22', T.card);
  add(name, 'muted text on card', T.textMuted, T.card);
  add(name, 'faint text on card', T.textFaint, T.card);
  add(name, 'faint text on page', T.textFaint, T.page);
  add(name, 'muted text on well (bg-strong)', T.textMuted, T.well);

  /* yellow accent as text */
  add(name, 'accent-yellow text on card', T.accentText, T.card);
  add(name, 'accent-yellow on warn-amber pill (pill.pending)', T.accentText, name === 'dark' ? '#2a2416' : '#fdf3d7');
  add(name, 'accent-yellow on bg-strong (stat values)', T.accentText, T.well);

  /* semantic pills (status-pill + .pill families) */
  add(name, 'pill.verified green-on-green-surface', T.successGreen, name === 'dark' ? '#12251a' : '#e2f5e9');
  add(name, 'pill.rejected red-on-red-surface', T.dangerRed, name === 'dark' ? '#2a1a1a' : '#fbe5e2');
  add(name, 'date-status.ok text', T.successSurfaceText, name === 'dark' ? '#12251a' : '#e2f5e9');
  add(name, 'date-status.err text', T.dangerSurfaceText, name === 'dark' ? '#2a1a1a' : '#fbe5e2');
  add(name, 'date-status.warn text', T.warnAmberText, name === 'dark' ? '#2a2416' : '#fdf3d7');

  /* availability badges — FIXED dark fills in both themes */
  add(name, 'avail AVAILABLE text', T.availOkText, F.availAvailable, 'fixed fill');
  add(name, 'avail BOOKED text', T.dangerBadgeText, F.availBooked, 'fixed fill');
  add(name, 'avail ON REQUEST text', T.warnBadgeText, F.availOnRequest, 'fixed fill');

  /* buttons */
  add(name, 'yellow button (ink on #FFCC00)', '#111111', '#FFCC00');
  add(name, 'green CTA (on-accent)', T.onAccent, T.successGreen);
}

/* ---------- report ---------- */
const FAIL = 4.5;
let failures = 0;
console.log('WCAG contrast audit (threshold 4.5:1 for small UI text)\n');
for (const name of ['dark', 'light']) {
  console.log('== ' + name.toUpperCase() + ' theme ==');
  for (const r of rows.filter(r => r.theme === name)) {
    const ok = r.ratio >= FAIL;
    if (!ok) failures++;
    console.log(
      (ok ? '  PASS ' : '  FAIL ') + fmt(r.ratio).padStart(5) + ':1  ' + r.label +
      (r.note ? '  [' + r.note + ']' : '')
    );
  }
  console.log('');
}
console.log(failures === 0 ? 'All pairs pass 4.5:1 ✔' : failures + ' pair(s) FAIL 4.5:1 ✘');
process.exit(failures === 0 ? 0 : 1);
