#!/usr/bin/env node
/* ============================================================
   tools/build-deploy.js — build ready-to-upload deployment copies
   into deploy/. Run from the repo root:  node tools/build-deploy.js

   deploy/
     infinityfree-frontend/   ← FTP EVERYTHING inside this folder
                                into public_html/ on InfinityFree
                                (or any static host). All pages +
                                shared JS/CSS/icons. Works standalone:
                                without the API every page still
                                renders with the 12 seeded demo pros
                                (browser sandbox store); admin edits
                                stay local to that browser.
     full-stack/              ← upload to a Node host (Railway,
                                Render, VPS, Pterodactyl…): the same
                                pages PLUS the server/ API, db/schema,
                                installer. One folder, everything.

   The copies are rebuilt from scratch every run (deploy/ is wiped),
   so it can never drift from the live repo. Never edit files inside
   deploy/ — edit the repo and re-run.
   ============================================================ */

'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DEPLOY = path.join(ROOT, 'deploy');

const HTML_PAGES = fs.readdirSync(ROOT).filter(f => f.endsWith('.html'));
const SHARED_ASSETS = [
    'styles.css', 'data-store.js', 'sc-cities.js', 'sc-pay.js', 'pro-cards.js',
    'pro-profile.js', 'header.js', 'site-partials.js', 'nav.js', 'ui.js',
    'manifest.webmanifest', 'sw.js', 'server.log'
].filter(f => fs.existsSync(path.join(ROOT, f)));

function rimraf(dir) {
    if (!fs.existsSync(dir)) return;
    for (const f of fs.readdirSync(dir)) {
        const p = path.join(dir, f);
        if (fs.statSync(p).isDirectory()) rimraf(p); else fs.unlinkSync(p);
    }
    fs.rmdirSync(dir);
}

function copy(src, destDir) {
    fs.mkdirSync(destDir, { recursive: true });
    fs.copyFileSync(path.join(ROOT, src), path.join(destDir, src));
}

function copyDir(srcDir, destDir) {
    fs.mkdirSync(destDir, { recursive: true });
    for (const f of fs.readdirSync(srcDir)) {
        const s = path.join(srcDir, f), d = path.join(destDir, f);
        if (fs.statSync(s).isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d);
    }
}

/* ---------- build ---------- */
rimraf(DEPLOY);

/* 1. Static frontend bundle (InfinityFree / any static host) */
const feDir = path.join(DEPLOY, 'infinityfree-frontend');
for (const f of HTML_PAGES) {
    if (f === 'setup.html') continue;   /* server-only wizard: talks to the Node API —
                                           meaningless (and broken) on a static host */
    copy(f, feDir);
}
for (const f of SHARED_ASSETS) copy(f, feDir);
if (fs.existsSync(path.join(ROOT, 'icons'))) copyDir('icons', path.join(feDir, 'icons'));
fs.writeFileSync(path.join(feDir, 'README-UPLOAD.txt'),
`SKILLCONNECT GH — static frontend bundle
=========================================
Upload EVERYTHING in this folder into public_html/ (the root, not
the folder itself) via InfinityFree's online file manager or FTP.

What works out of the box: every page, 12 seeded demo pros, demo
bookings — powered by each visitor's own browser storage.

NO setup.html here: that page configures the Node.js API server
and cannot run on static hosting (and is not needed — the site
self-seeds in sandbox mode). It ships in the full-stack bundle.

What needs the API (see the full-stack bundle): a SHARED database,
real sign-ups visible to everyone, MoMo payments, SMS/WhatsApp
alerts. Until then, admin edits stay local to the admin's browser.
`);

/* 2. Full-stack bundle (Node host) */
const fsDir = path.join(DEPLOY, 'full-stack');
for (const f of HTML_PAGES) copy(f, fsDir);
for (const f of SHARED_ASSETS) copy(f, fsDir);
if (fs.existsSync(path.join(ROOT, 'icons'))) copyDir('icons', path.join(fsDir, 'icons'));
if (fs.existsSync(path.join(ROOT, 'db'))) copyDir('db', path.join(fsDir, 'db'));
if (fs.existsSync(path.join(ROOT, 'tools'))) copyDir('tools', path.join(fsDir, 'tools'));
copyDir('server/src', path.join(fsDir, 'server/src'));
fs.copyFileSync(path.join(ROOT, 'server', 'package.json'), path.join(fsDir, 'server', 'package.json'));
fs.copyFileSync(path.join(ROOT, 'server', 'package-lock.json'), path.join(fsDir, 'server', 'package-lock.json'));
if (fs.existsSync(path.join(ROOT, 'server', 'ecosystem.config.cjs'))) {
    fs.copyFileSync(path.join(ROOT, 'server', 'ecosystem.config.cjs'), path.join(fsDir, 'server', 'ecosystem.config.cjs'));
}
fs.writeFileSync(path.join(fsDir, 'README-START-HERE.txt'),
`SKILLCONNECT GH — full-stack bundle (Node host)
================================================
1. Upload this whole folder to your Node host.
2. cd server && npm install --omit=dev
3. Start:  npm start   (or: node src/index.js)
4. The console prints a SETUP URL + one-time token.
5. Open http://<your-host>/setup.html in a browser,
   paste the token, press "Run Install / Upgrade".
6. Open /index.html — done. Admin PIN default 4321
   (change it immediately in the admin console).

UPGRADES: upload the new full-stack bundle over the old one
(keep server/.env!), restart, open /setup.html, press Run.
Only missing tables/columns/rows are added; data is never
deleted or overwritten.
`);

/* summary */
function sizeOf(dir) {
    let n = 0, bytes = 0;
    (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else { n++; bytes += fs.statSync(p).size; } } })(dir);
    return { files: n, kb: Math.round(bytes / 1024) };
}
const fe = sizeOf(feDir), st = sizeOf(fsDir);
console.log('deploy/infinityfree-frontend  ' + fe.files + ' files  (' + fe.kb + ' KB)  → FTP contents into public_html/');
console.log('deploy/full-stack             ' + st.files + ' files  (' + st.kb + ' KB)  → upload to a Node host, then /setup.html');
console.log('Done. Do NOT edit files inside deploy/ — edit the repo and re-run node tools/build-deploy.js');
