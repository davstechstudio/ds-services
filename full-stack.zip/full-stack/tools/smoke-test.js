#!/usr/bin/env node
/* ============================================================
   tools/smoke-test.js — end-to-end verification of the SC API
   Prereqs (target server):
     1. mysql -u USER -p -e "CREATE DATABASE skillconnect" (+ user grants)
     2. mysql -u USER -p skillconnect < db/schema.sql
     3. cd server && SC_DB_USER=… SC_DB_PASS=… npm start
   Run:  node tools/smoke-test.js [baseUrl]   (default :8200)
   Exercises: matching, refs/counters, escrow→commission→ledger,
   reviews, disputes/rematch, cancel/rebook, OTP login, stats,
   snapshot reassembly, sandbox reset. RESETS the database —
   never point this at production data.
   ============================================================ */

'use strict';
const BASE = process.argv[2] || 'http://localhost:8200';
const MSG_MOCK = process.env.MSG_MOCK_URL || 'http://localhost:8398';   /* tools/mock-msg-gateway.js */

/* Go-live auth: the suite holds an admin session (cookie jar) for the
   admin console calls, a pro session for pro-owned calls, and still
   verifies that anonymous calls to protected functions are rejected. */
const cookieJar = {};
function cookieHeader() { return Object.entries(cookieJar).map(([k, v]) => k + '=' + v).join('; '); }
function stashCookies(res) {
    const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    (Array.isArray(sc) ? sc : [sc].filter(Boolean)).forEach(c => {
        const pair = String(c).split(';')[0];
        const i = pair.indexOf('=');
        if (i > 0) cookieJar[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
    });
}
async function login(role, body) {
    const res = await fetch(BASE + '/api/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ role }, body || {}))
    });
    stashCookies(res);
    return res.json();
}
function logout() {
    /* Clear the jar SYNCHRONOUSLY, then fire the server-side destroy with
       the captured header — callers that don't await logout() must never
       send the old session on the next call. */
    const hdr = cookieHeader();
    Object.keys(cookieJar).forEach(k => delete cookieJar[k]);
    return fetch(BASE + '/api/logout', { method: 'POST', headers: { 'Cookie': hdr } }).then(r => r.json());
}

let passed = 0, failed = 0;
function check(name, cond, extra) {
    if (cond) { passed++; console.log('  PASS', name); }
    else { failed++; console.log('  FAIL', name, extra !== undefined ? JSON.stringify(extra).slice(0, 200) : ''); }
}

/* (gate stage is asserted via real server matching below — no replica needed) */

async function call(fn, args, method) {
    const res = await fetch(BASE + '/api/' + fn, {
        method: method || 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, cookieHeader() ? { 'Cookie': cookieHeader() } : {}),
        body: method ? undefined : JSON.stringify({ args: args || [] })
    });
    stashCookies(res);
    const j = await res.json();
    return j && j.ok !== undefined && 'result' in j ? j.result : j;
}

/* Dedicated routes (payments/*) take a plain JSON body, not positional args. */
async function callRaw(path, body) {
    const res = await fetch(BASE + '/api/' + path, {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, cookieHeader() ? { 'Cookie': cookieHeader() } : {}),
        body: JSON.stringify(body || {})
    });
    stashCookies(res);
    return { status: res.status, body: await res.json() };
}

/* Signed gateway webhook — same HMAC-SHA512(raw body, secret) scheme the
   server verifies. WH_SECRET must match the SC_PAYSTACK_SECRET the server
   was started with (payment tests run with the secret set, gateway still
   simulated via settings.payment_gateway = ''). */
const crypto = require('crypto');
const WH_SECRET = 'whsec_smoketest';
function signedWebhook(ref) {
    const payload = { event: 'charge.success', data: { reference: ref, amount: 0, status: 'success' } };
    const raw = Buffer.from(JSON.stringify(payload));
    const sig = crypto.createHmac('sha512', WH_SECRET).update(raw).digest('hex');
    return fetch(BASE + '/api/payments/webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Paystack-Signature': sig },
        body: raw
    }).then(r => r.json());
}

(async () => {
    console.log('Smoke test against', BASE);

    console.log('[0] reset to pristine sandbox baseline');
    const rs0 = await call('reset');
    check('reset ok (SC_ALLOW_RESET=true in test env)', rs0 && rs0.ok, rs0);
    const gwReset = await callRaw('payments/gateway', { adminSession: '1', gateway: '' });
    check('gateway reset to simulated (sandbox tests)', gwReset.body.ok === true && gwReset.body.gateway === '', gwReset.body);
    const al0 = await login('admin', { password: '4321' });
    check('admin session established early (go-live guard)', al0 && al0.ok === true && !!cookieJar.sc_session, al0);

    console.log('[1] settings & catalog');
    const s = await call('settings', null, 'GET');
    check('settings endpoint ok', s && s.ok && s.catalog);
    check('8 categories', s.catalog && Object.keys(s.catalog.CAT_LABELS).length === 8, s.catalog && Object.keys(s.catalog.CAT_LABELS || {}));

    console.log('[2] seed data');
    const pros = await call('getPros');
    check('12 seed pros', Array.isArray(pros) && pros.length === 12, pros && pros.length);
    const p1001 = pros.find(p => p.id === 'P1001');
    check('P1001 shape', p1001 && p1001.name.includes('Kwesi') && p1001.city === 'Accra' && p1001.cat === 'mc', p1001);

    console.log('[3] createBooking — matching engine, counters, simulated quotes');
    const b1 = await call('createBooking', [{ name: 'Test Customer', phone: '0244999001', cat: 'mc', location: 'Accra', budget: 1200, urgency: 'planned', details: 'Wedding MC' }]);
    const B1 = b1 && b1.id;
    check('booking ref SC-BK-284001', B1 === 'SC-BK-284001', B1);
    check('status quoted (sandbox quotes)', b1 && b1.status === 'quoted', b1 && b1.status);
    check('events trail populated', b1 && Array.isArray(b1.events) && b1.events.length >= 2, b1 && b1.events && b1.events.length);
    const q1 = await call('getQuotesFor', [B1]);
    check('quotes generated for matched pros', q1.length >= 1 && q1.every(q => /^SC-Q-\d+$/.test(q.id)), q1.map(q => q.id));

    console.log('[3b] budget ceiling, direct pro request, no-match alternative');
    const b7 = await call('createBooking', [{ name: 'Budget Cust', phone: '0244999007', cat: 'mc', location: 'Accra', budget: 400, urgency: 'planned' }]);
    check('over-budget request matches nothing (hard ceiling)', b7 && b7.matchedProIds.length === 0, b7 && b7.matchedProIds);
    check('no quotes generated for over-budget request', (await call('getQuotesFor', [b7.id])).length === 0);
    check('no-match event calmly offers manual search + keeps ref', /search manually|manual search/i.test(b7.events[b7.events.length - 1].text) && b7.events[b7.events.length - 1].text.includes(b7.id), b7.events[b7.events.length - 1].text);
    const b8 = await call('createBooking', [{ name: 'Direct Cust', phone: '0244999008', cat: 'mc', location: 'Accra', budget: 900, urgency: 'planned', proId: 'P1001' }]);
    check('direct pro request lands on the requested pro only', b8 && b8.matchedProIds.length === 1 && b8.matchedProIds[0] === 'P1001', b8 && b8.matchedProIds);
    const q8 = await call('getQuotesFor', [b8.id]);
    check('direct pro quote reflects the pro\'s real rate', q8.length === 1 && q8[0].price >= 700 && q8[0].price <= 900, q8.map(q => q.price));
    const b9 = await call('createBooking', [{ name: 'Within Cust', phone: '0244999009', cat: 'mc', location: 'Accra', budget: 1200, urgency: 'planned' }]);
    const q9 = await call('getQuotesFor', [b9.id]);
    check('general booking quotes stay within budget', q9.length >= 1 && q9.every(q => q.price <= 1200), q9.map(q => q.price));

    console.log('[3c] budget raise → fresh match run');
    const rb1 = await call('updateBookingBudget', [b7.id, 400]);
    check('lowering/equal budget refused', rb1 && rb1.ok === false && /(higher|above)/i.test(rb1.error), rb1 && rb1.error);
    const rb2 = await call('updateBookingBudget', [b7.id, 900]);
    check('budget raise accepted', rb2 && rb2.ok === true, rb2 && rb2.error);
    check('raise widens the match (mc pros ≤ 900 invited)', rb2 && rb2.booking.matchedProIds.length >= 1 && rb2.booking.matchedProIds.every(id => ['P1001', 'P1009'].includes(id)), rb2 && rb2.booking.matchedProIds);

    console.log('[1b] near-first distance matching');
    const nf1 = await call('createBooking', [{ name: 'Near Cust', phone: '0244999031', cat: 'handy', location: 'Osu, Accra', budget: 300, urgency: 'planned' }]);
    check('near-first ranks closest hub first (Osu: Accra 0km before Tema 27km)', nf1 && nf1.matchedProIds[0] === 'P1004' && nf1.matchedProIds.includes('P1011'), nf1 && nf1.matchedProIds);
    const nf2 = await call('createBooking', [{ name: 'Far Cust', phone: '0244999032', cat: 'handy', location: 'Kumasi Adum', budget: 300, urgency: 'planned' }]);
    check('widening picks the CLOSER far pro (Tema 226km before Accra 253km)', nf2 && nf2.matchedProIds[0] === 'P1011' && nf2.matchedProIds.includes('P1004'), nf2 && nf2.matchedProIds);
    const nf2ev = await call('getBooking', [nf2.id]);
    check('far match carries the transparency note', nf2ev && nf2ev.events.some(e => e.text.includes('no closer pro was available')), nf2ev && nf2ev.events.map(e => e.text));
    const nf3 = await call('createBooking', [{ name: 'Alias Cust', phone: '0244999033', cat: 'handy', location: 'Tema Community 5', budget: 300, urgency: 'planned' }]);
    check('neighbourhood alias resolves (Tema Comm. 5 → Tema pro first)', nf3 && nf3.matchedProIds[0] === 'P1011', nf3 && nf3.matchedProIds);
    const nf4 = await call('createBooking', [{ name: 'Unknown Cust', phone: '0244999034', cat: 'handy', location: 'Somewhere along the coast', budget: 300, urgency: 'planned' }]);
    check('unrecognised location still matches (never a hard wall)', nf4 && nf4.matchedProIds.length >= 1, nf4 && nf4.matchedProIds);
    check('new quotes generated for invited pros ≤ new budget', (await call('getQuotesFor', [b7.id])).every(q => q.price <= 900), (await call('getQuotesFor', [b7.id])).map(q => q.price));
    check('timeline records the raise', rb2.booking.events.some(ev => /Budget raised/i.test(ev.text)), rb2.booking.events.map(ev => ev.text).join(' | '));
    const rb3 = await call('updateBookingBudget', ['SC-BK-NOPE', 900]);
    check('unknown booking refused', rb3 && rb3.ok === false, rb3);

    console.log('[4] acceptQuote → escrow → release (commission from settings)');
    const booking1 = await call('getBooking', [B1]);
    const pro1 = booking1.chosenProId || booking1.matchedProIds[0];
    const acc = await call('acceptQuote', [q1[0].id]);
    check('quote accepted', acc && acc.status === 'accepted', acc);
    const pay = await call('payIntoEscrow', [B1, 'momo', '0244999001']);
    check('escrow funded with ESC- ref', pay && pay.ok && /^ESC-[A-Z0-9]{6}$/.test(pay.txnRef), pay);
    const before = (await call('getPro', [pro1])).balance;
    const rel = await call('releaseEscrow', [B1]);
    check('escrow released', rel && rel.ok && rel.booking.status === 'completed', rel);
    const amount = rel.booking.amount;
    check('commission = round(10% × amount)', rel && rel.commission === Math.round(amount * 0.10), rel && [amount, rel.commission]);
    const after = (await call('getPro', [pro1])).balance;
    check('pro wallet credited net of commission', Math.abs(Number(after) - (Number(before) + amount - Math.round(amount * 0.10))) < 0.01, [before, after]);
    const txns = await call('getTransactions');
    check('ledger has service_payment + commission', txns.some(t => t.type === 'service_payment') && txns.some(t => t.type === 'commission'), txns.map(t => t.type));

    console.log('[5] reviews');
    const rev = await call('addReview', [B1, 5, 'Excellent MC']);
    check('review accepted', rev && rev.ok && rev.review.id.startsWith('SC-RV-'), rev);
    const revDup = await call('addReview', [B1, 4, 'again']);
    check('duplicate review blocked', revDup && !revDup.ok && /Already reviewed/.test(revDup.error), revDup);

    console.log('[6] urgent matching, cancellation, rebook');
    const b2 = await call('createBooking', [{ name: 'Urgent Cust', phone: '0244999002', cat: 'handy', location: 'Accra', budget: 400, urgency: 'urgent' }]);
    check('urgent booking matched', b2 && b2.matchedProIds.length >= 1, b2 && b2.matchedProIds);
    const can = await call('cancelBooking', [b2.id, 'Found someone locally']);
    check('cancel declines pending quotes', can && can.ok && can.declinedQuotes === (await call('getBooking', [b2.id])).matchedProIds.length, can);
    const reb = await call('rebookFrom', [b2.id]);
    check('rebook clones into fresh ref', reb && reb.ok && reb.booking.id !== b2.id && /^SC-BK-\d+$/.test(reb.booking.id), reb && reb.booking && reb.booking.id);
    const cs = await call('cancellationSummary');
    check('cancellation summary records reason', cs.length >= 1 && cs[0].reason === 'Found someone locally', cs[0]);

    console.log('[7] dispute → rematch → release');
    /* handy: keeps the rematch pool independent of the ID-gate seeds
       (P1003 photographer is delisted from new matches; P1001 is the
       disputed pro and excluded from his own rematch). */
    const b3 = await call('createBooking', [{ name: 'Dispute Cust', phone: '0244999003', cat: 'handy', location: 'Accra', budget: 1500, urgency: 'planned' }]);
    const bq = await call('getQuotesFor', [b3.id]);
    await call('acceptQuote', [bq[0].id]);
    await call('payIntoEscrow', [b3.id, 'momo']);
    const dp = await call('openDispute', [b3.id, 'quality', 'Sound system underpowered']);
    check('dispute opened SC-DS-41', dp && dp.ok && dp.dispute.id === 'SC-DS-41', dp);
    const rm = await call('resolveDispute', ['SC-DS-41', 'resolved_rematch', 'Replacement arranged']);
    check('rematch keeps escrow held, invites replacements', rm && rm.status === 'resolved_rematch', rm);
    const b3b = await call('getBooking', [b3.id]);
    check('booking waits for customer pick', b3b.rematchPick === true && b3b.status === 'quoted', b3b.status);
    const opts = await call('customerRematchOptions', [b3.id]);
    check('rematch options exclude disputed pro', opts.length >= 1 && !opts.some(o => o.id === b3b.rematchExclude), opts.map(o => o.id));
    const pick = await call('customerRematchPick', [b3.id, opts[0].id]);
    check('pick transfers escrow → in_progress', pick && pick.ok && pick.booking.status === 'in_progress', pick);
    const rel2 = await call('releaseEscrow', [b3.id]);
    check('release after rematch completes', rel2 && rel2.ok && rel2.booking.status === 'completed', rel2 && rel2.error);

    console.log('[7a] staged ID-renewal enforcement (gate)');
    const bg = await call('createBooking', [{ name: 'Gate Cust', phone: '0244999020', cat: 'photographer', location: 'Kumasi', budget: 9000, urgency: 'planned' }]);
    check('delisted pro excluded from matching (P1003, 1900d)', bg && bg.matchedProIds.length === 0, bg && bg.matchedProIds);
    const bgGrace = await call('createBooking', [{ name: 'Grace Cust', phone: '0244999021', cat: 'artist', location: 'Tema', budget: 9000, urgency: 'planned' }]);
    check('grace-stage pro still matched (P1002, expired but inside 14d grace)', bgGrace && bgGrace.matchedProIds.includes('P1002'), bgGrace && bgGrace.matchedProIds);
    const queue = await call('adminNoMatchQueue');
    const gateEntry = queue.find(q => q.booking.id === bg.id);
    check('no-match queue pool carries gate stage labels', gateEntry && gateEntry.pool.length >= 1 && gateEntry.pool.some(p => p.gate === 'delisted'), gateEntry && gateEntry.pool.map(p => p.id + ':' + p.gate));

    console.log('[7b] payment intents (simulated gateway): initiate → webhook confirm → idempotency');
    const b4 = await call('createBooking', [{ name: 'Pay Cust', phone: '0244999004', cat: 'handy', location: 'Tema', budget: 300, urgency: 'planned' }]);
    const q4 = await call('getQuotesFor', [b4.id]);
    await call('acceptQuote', [q4[0].id]);
    const b4f = await call('getBooking', [b4.id]);   /* amount is fixed at quote-accept */
    const ini = await callRaw('payments/initiate', { purpose: 'escrow', refId: b4.id, method: 'momo' });
    check('escrow intent initiated (simulated, PMT- ref)', ini.body.ok && /^PMT-[A-Z0-9]{6}-[A-Z0-9]{4}$/.test(ini.body.intentRef) && ini.body.simulated === true, ini.body);
    check('intent amount from booking row', ini.body.amount === Number(b4f.amount), [ini.body.amount, b4f.amount]);
    const stat0 = await callRaw('payments/status', { ref: ini.body.intentRef });
    check('intent status = initiated', stat0.body.ok && stat0.body.intent.status === 'initiated', stat0.body);
    const whBad = await fetch(BASE + '/api/payments/webhook', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Paystack-Signature': 'deadbeef' }, body: '{}'
    });
    check('webhook rejects bad signature (401)', whBad.status === 401, whBad.status);
    const wj = await signedWebhook(ini.body.intentRef);
    check('signed webhook confirms → escrow funded', wj && wj.ok === true && wj.booking.status === 'in_progress' && wj.txnRef === ini.body.intentRef, wj);
    const b4b = await call('getBooking', [b4.id]);
    check('escrow txn_ref carries the gateway reference', b4b.escrow && b4b.escrow.txnRef === ini.body.intentRef, b4b.escrow);
    const st2 = await callRaw('payments/status', { ref: ini.body.intentRef });
    check('intent status = success', st2.body.intent.status === 'success', st2.body);
    const wj2 = await signedWebhook(ini.body.intentRef);
    check('webhook replay idempotent (alreadyDone)', wj2 && wj2.ok === true && wj2.alreadyDone === true, wj2);
    const ini3 = await callRaw('payments/initiate', { purpose: 'escrow', refId: b4.id });
    check('initiate refuses funded/in-progress booking', ini3.body.ok === false && !!(ini3.body.error || '').match(/awaiting payment|already funded/), ini3.body);
    const ini4 = await callRaw('payments/initiate', { purpose: 'junk', refId: 'X' });
    check('unknown purpose rejected', ini4.body.ok === false, ini4.body);

    console.log('[7c] reg-fee intent: initiate → pull-verify confirm');
    const app = await call('addApplication', [{ name: 'Pay Pro', phone: '0244999005', city: 'Accra', cat: 'handy' }]);
    check('application created SC-APP-301', app && app.id === 'SC-APP-301', app && app.id);
    const ini5 = await callRaw('payments/initiate', { purpose: 'reg_fee', refId: app.id, method: 'momo' });
    check('reg-fee intent created at getRegFee()', ini5.body.ok && ini5.body.amount === 50, ini5.body);
    const ver = await callRaw('payments/verify', { ref: ini5.body.intentRef });
    check('verifyAndConfirm marks fee paid + ledgered', ver.body.ok === true && !!ver.body.txnId, ver.body);
    const apps2 = await call('getApplications');
    const a2 = apps2.find(a => a.id === app.id);
    check('application regFeePaid flag set', a2 && a2.regFeePaid === true, a2 && a2.regFeePaid);
    const txns2 = await call('getTransactions');
    check('registration_fee ledger row present', txns2.some(t => t.type === 'registration_fee'), txns2.map(t => t.type));

    console.log('[7d] gateway toggle (admin-gated) + MTN MoMo direct flow (mocked gateway)');
    logout();   /* probe the admin gate WITHOUT a session in the jar */
    const gwAnon = await callRaw('payments/gateway', { gateway: 'paystack' });
    check('gateway switch requires admin', gwAnon.body.ok === false && /Admin sign-in/.test(gwAnon.body.error || ''), gwAnon.body);
    await login('admin', { password: '4321' });
    const gw0 = await callRaw('payments/gateway', { adminSession: '1' });
    check('gateway info readable (sandbox test hook)', gw0.body.ok === true && typeof gw0.body.gateway === 'string', gw0.body);
    const prevGateway = gw0.body.gateway;
    const sw = await callRaw('payments/gateway', { adminSession: '1', gateway: 'mtn_momo' });
    check('switch to mtn_momo accepted (mock creds configured)', sw.body.ok === true && sw.body.gateway === 'mtn_momo', sw.body);
    const b5 = await call('createBooking', [{ name: 'MTN Cust', phone: '0244999006', cat: 'handy', location: 'Accra', budget: 200, urgency: 'planned' }]);
    const q5 = await call('getQuotesFor', [b5.id]);
    await call('acceptQuote', [q5[0].id]);
    const m1 = await callRaw('payments/initiate', { purpose: 'escrow', refId: b5.id, method: 'momo' });
    check('MTN initiate ok → pending approval', m1.body.ok === true && m1.body.pending === true && m1.body.gateway === 'mtn_momo', m1.body);
    const v0 = await callRaw('payments/verify', { ref: m1.body.intentRef });
    check('verify before customer approval stays pending', v0.body.ok === false && v0.body.pending === true, v0.body);
    const v1 = await callRaw('payments/verify', { ref: m1.body.intentRef });
    check('verify after approval funds escrow', v1.body.ok === true && v1.body.how === 'verify' && v1.body.booking.status === 'in_progress', v1.body);
    const b5s = await call('getBooking', [b5.id]);
    check('escrow carries the PMT intent reference', !!(b5s.escrow && b5s.escrow.txnRef === m1.body.intentRef), b5s.escrow && b5s.escrow.txnRef);
    const v3 = await callRaw('payments/verify', { ref: m1.body.intentRef });
    check('post-confirm replay still resolves MTN ref (audit merged)', v3.body.ok === true && v3.body.alreadyDone === true, v3.body);
    const b6 = await call('createBooking', [{ name: 'MTN Fail', phone: '0244999999', cat: 'handy', location: 'Accra', budget: 250, urgency: 'planned' }]);
    const q6 = await call('getQuotesFor', [b6.id]);
    await call('acceptQuote', [q6[0].id]);
    const m2 = await callRaw('payments/initiate', { purpose: 'escrow', refId: b6.id });
    const v2 = await callRaw('payments/verify', { ref: m2.body.intentRef });
    check('declined MoMo → intent failed', v2.body.ok === false && /failed/i.test(v2.body.error || ''), v2.body);
    const b6s = await call('getBooking', [b6.id]);
    check('failed collection leaves booking awaiting payment', b6s.status === 'booked' && !b6s.escrow, [b6s.status, b6s.escrow]);
    const sw2 = await callRaw('payments/gateway', { adminSession: '1', gateway: prevGateway });
    check('switch back to previous gateway', sw2.body.ok === true && sw2.body.gateway === prevGateway, sw2.body);

    console.log('[7f] platform settings (admin-editable tunables)');
    const psBase = await call('settings', null, 'GET');
    const prev = { grace: psBase.settings.id_grace_days, years: psBase.settings.id_valid_years, warn: psBase.settings.id_warn_days, comm: psBase.settings.commission_rate };
    const anonPs = await fetch(BASE + '/api/adminSetSetting', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ entries: [{ key: 'commission_rate', value: 0.15 }] }) });
    check('platform settings need an admin session', anonPs.status === 401 || (await anonPs.json()).ok === false, anonPs.status);
    const badBatch = await callRaw('adminSetSetting', { entries: [{ key: 'commission_rate', value: 0.2 }, { key: 'commission_rate', value: 900 }] });
    check('bad value rejects the whole batch', badBatch.body.ok === false && /Commission/.test(badBatch.body.error || ''), badBatch.body);
    const batch = await callRaw('adminSetSetting', { entries: [
        { key: 'commission_rate', value: 0.15 },
        { key: 'id_grace_days', value: 2 },
        { key: 'id_valid_years', value: 3 },
        { key: 'id_warn_days', value: 30 }
    ] });
    check('platform settings batch saves', batch.body.ok === true && batch.body.results.length === 4, batch.body);
    const psNow = await call('settings', null, 'GET');
    check('settings values live (grace 2, years 3, warn 30, commission 15%)', psNow.settings.id_grace_days === 2 && psNow.settings.id_valid_years === 3 && psNow.settings.id_warn_days === 30 && Math.abs(psNow.settings.commission_rate - 0.15) < 1e-9, psNow.settings);
    const snapPs = await call('snapshot', null, 'GET');
    check('snapshot carries settings for the pages', snapPs && snapPs.db && snapPs.db.settings && snapPs.db.settings.id_grace_days === 2, snapPs && snapPs.db && snapPs.db.settings);
    const b14 = await call('createBooking', [{ name: 'Comm Cust', phone: '0244999014', cat: 'handy', location: 'Accra', budget: 300, urgency: 'planned' }]);
    const q14 = await call('getQuotesFor', [b14.id]);
    await call('acceptQuote', [q14[0].id]);
    await call('payIntoEscrow', [b14.id, 'momo']);
    const rel14 = await call('releaseEscrow', [b14.id]);
    check('release at the NEW commission rate (15%)', rel14 && rel14.ok && rel14.booking.commission === Math.round(rel14.booking.amount * 0.15), rel14 && [rel14.booking.amount, rel14.booking.commission]);
    /* Window change must bite immediately: P1002 is ~3 days past validity,
       so a 2-day grace delists her from NEW matching — proven server-side. */
    const bg2 = await call('createBooking', [{ name: 'Gate Win Cust', phone: '0244999015', cat: 'artist', location: 'Tema', budget: 9000, urgency: 'planned' }]);
    check('shortened grace window delists immediately (P1002 out of new matches)', bg2 && bg2.matchedProIds.length === 0, bg2 && bg2.matchedProIds);
    check('restore: platform settings back to seed values', (await callRaw('adminSetSetting', { entries: [
        { key: 'commission_rate', value: prev.comm }, { key: 'id_grace_days', value: prev.grace },
        { key: 'id_valid_years', value: prev.years }, { key: 'id_warn_days', value: prev.warn }
    ] })).body.ok === true);
    const bg3 = await call('createBooking', [{ name: 'Gate Back Cust', phone: '0244999016', cat: 'artist', location: 'Tema', budget: 9000, urgency: 'planned' }]);
    check('restore: P1002 back inside grace after original windows return', bg3 && bg3.matchedProIds.includes('P1002'), bg3 && bg3.matchedProIds);

    console.log('[7h] AI booking assistant (NL → structured booking)');
    const ai1 = await callRaw('aiParseBooking', { text: 'Need an MC for my wedding this Saturday in Takoradi, about 200 guests, budget around 2500. I am Ama Serwaa, 024 421 1595' });
    const A1 = ai1.body.parsed || {};
    check('assistant parses full request (cat/date/loc/budget/phone/name)', ai1.body.ok === true && A1.cat === 'mc' && !!A1.date && A1.location === 'Takoradi' && A1.budget === '2500' && A1.phone === '0244211595' && A1.name === 'Ama Serwaa' && A1.confidence === 1, ai1.body);
    const ai2 = await callRaw('aiParseBooking', { text: 'Emergency! Plumber needed in East Legon today, no light and water everywhere. My name is Kofi, 0244001234' });
    const A2 = ai2.body.parsed || {};
    const todayLocal = new Date();
    const todayIsoLocal = todayLocal.getFullYear() + '-' + String(todayLocal.getMonth() + 1).padStart(2, '0') + '-' + String(todayLocal.getDate()).padStart(2, '0');
    check('assistant flags urgency from emergency phrasing', ai2.body.ok === true && A2.urgency === 'urgent' && A2.date === todayIsoLocal, ai2.body);
    const ai3 = await callRaw('aiParseBooking', { text: 'hello there' });
    check('assistant refuses text with no request in it', ai3.body.ok === false, ai3.body);
    const aiRate = await fetch(BASE + '/api/aiParseBooking', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'x'.repeat(900) }) });
    check('assistant caps oversized input', aiRate.ok === true && (await aiRate.json()).ok === false);
    /* Full loop: parsed text → createBooking → near-first matching engine */
    const bAI = await call('createBooking', [{ name: A1.name, phone: A1.phone, cat: A1.cat, date: A1.date, location: A1.location, budget: A1.budget, urgency: A1.urgency, uInfo: { label: 'Planned', slaHours: 24 }, details: 'Assistant-parsed request', info: { name: 'Event MC / Host' } }]);
    check('parsed request books through the normal matching engine', bAI && bAI.id && Array.isArray(bAI.matchedProIds), bAI && bAI.matchedProIds);

    console.log('[7i] AI price guidance (live stats + budget outcome)');
 const ps = await call('priceStats');
    check('price stats computed per category', ps && ps.ok && ps.stats && ps.stats.mc && Array.isArray(ps.stats.mc.typical), ps && ps.stats && ps.stats.mc);
    check('stats blend observed pro rates', ps && ps.stats.mc.observed && ps.stats.mc.observed.pros >= 2, ps && ps.stats.mc.observed);
    const bo1 = await callRaw('budgetOutcome', { cat: 'mc', budget: 900 });
    check('guidance: healthy budget predicted', bo1.body.ok === true && ['strong', 'fair', 'thin'].includes(bo1.body.outcome.level), bo1.body);
    const bo2 = await callRaw('budgetOutcome', { cat: 'mc', budget: 100 });
    check('guidance: hopeless budget flagged BEFORE submit', bo2.body.ok === true && bo2.body.outcome.level === 'unlikely' && /Raise it|lowest available/.test(bo2.body.outcome.message), bo2.body);
    const bo3 = await callRaw('budgetOutcome', { cat: 'mc', budget: 0 });
    check('guidance: no budget = everything considered', bo3.body.ok === true && bo3.body.outcome.level === 'none', bo3.body);

    console.log('[7j] LTR match-event logging (training capture behind the matcher)');
    /* Fresh admin session: the export route is admin-gated. */
    await login('admin', { password: '4321' });
    /* MC booking in Accra: P1001 (Accra 800, near) and P1009 (Takoradi 500,
       far) both clear the 900 budget, so the event must carry the FULL
       candidate pool — not just the max_matches=3 invites. */
    const bLTR = await call('createBooking', [{ name: 'LTR Cust', phone: '0244999020', cat: 'mc', location: 'Accra', budget: 900, urgency: 'planned' }]);
    const expAnon = await fetch(BASE + '/api/matchEventsExport', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
    check('LTR export is admin-gated (anon rejected)', expAnon.status === 200 && (await expAnon.json()).ok === false, expAnon.status);
    const exp1 = await callRaw('matchEventsExport', {});
    check('LTR export reachable with an admin session', exp1.body.ok === true && Array.isArray(exp1.body.rows) && exp1.body.rows.length > 0, exp1.body && exp1.body.rows && exp1.body.rows.length);
    const ev1 = (exp1.body.rows || []).filter(r => r.bookingId === bLTR.id)[0];
    check('one event logged per automated match decision', !!ev1, bLTR.id);
    check('engine version stamped (nearfirst-v1)', ev1 && ev1.engine === 'nearfirst-v1', ev1 && ev1.engine);
    check('event snapshots the FULL candidate pool (budget passers)', ev1 && ev1.candidates.length >= 2 && ev1.candidates.some(c => c.proId === 'P1009'), ev1 && ev1.candidates.map(c => c.proId));
    check('per-candidate features captured (km/tier/response/rating/price/gate)', ev1 && ev1.candidates.length && ['km', 'tier', 'respRank', 'rating', 'ratingCount', 'bookings', 'price', 'emergency', 'gateStage'].every(k => k in ev1.candidates[0]), ev1 && ev1.candidates[0]);
    check('base km resolved from location text', ev1 && ev1.baseKm === 0, ev1 && ev1.baseKm);
    check('exposure: shown carries proId + position', ev1 && Array.isArray(ev1.shown) && ev1.shown.length === (bLTR.matchedProIds || []).length && ev1.shown.every((s, i) => s.position === i && (bLTR.matchedProIds || []).includes(s.proId)), ev1 && ev1.shown);
    /* Outcome wiring end-to-end on this booking. */
    const qLTR = await call('getQuotesFor', [bLTR.id]);
    check('outcome: sandbox quotes counted per candidate', await callRaw('matchEventsExport', {}).then(r => { const e = r.body.rows.filter(x => x.bookingId === bLTR.id)[0]; return e && e.outcome && e.outcome.quoteCount === qLTR.length; }), qLTR.length);
    await call('acceptQuote', [qLTR[0].id]);
    const exp2 = await callRaw('matchEventsExport', {});
    const ev2 = exp2.body.rows.filter(r => r.bookingId === bLTR.id)[0];
    check('outcome: accept records the winning pro', ev2 && ev2.outcome && ev2.outcome.acceptedProId === qLTR[0].proId, ev2 && ev2.outcome);
    await call('payIntoEscrow', [bLTR.id, 'momo']);
    await call('releaseEscrow', [bLTR.id]);
    const relLTR = await call('addReview', [bLTR.id, 5, 'LTR smoke review']);
    const exp3 = await callRaw('matchEventsExport', {});
    const ev3 = exp3.body.rows.filter(r => r.bookingId === bLTR.id)[0];
    check('outcome: escrow + completion + review rating recorded', ev3 && ev3.outcome && ev3.outcome.escrowPaid === true && ev3.outcome.completed === true && ev3.outcome.reviewRating === 5, ev3 && ev3.outcome);
    check('review really landed (positive control)', relLTR && relLTR.ok === true, relLTR);
    /* Budget raise ⇒ second event for the same booking. */
    const bLTR2 = await call('createBooking', [{ name: 'LTR Thin', phone: '0244999021', cat: 'mc', location: 'Accra', budget: 100, urgency: 'planned' }]);
    check('thin-budget booking starts with no invites', bLTR2 && (bLTR2.matchedProIds || []).length === 0, bLTR2 && bLTR2.matchedProIds);
    await call('updateBookingBudget', [bLTR2.id, 900]);
    const exp4 = await callRaw('matchEventsExport', {});
    const evs4 = exp4.body.rows.filter(r => r.bookingId === bLTR2.id);
    check('budget raise re-runs the matcher as its own logged event', evs4.length >= 1 && evs4[evs4.length - 1].budget === 900, evs4.map(e => e.budget));
    /* Cancellation outcome lands on the latest event. */
    await call('cancelBooking', [bLTR2.id, 'LTR test cancel']);
    const exp5 = await callRaw('matchEventsExport', {});
    const ev5 = exp5.body.rows.filter(r => r.bookingId === bLTR2.id)[0];
    check('outcome: cancellation recorded on the re-match event', ev5 && ev5.outcome && ev5.outcome.cancelled === true, ev5 && ev5.outcome);
    /* ID-gate stage rides as a candidate feature: P1002 is in the grace
       window (expired, days left) and must still be invited exactly as
       before — the log just makes the gate boundary learnable. */
    const bLTR3 = await call('createBooking', [{ name: 'LTR Tema', phone: '0244999022', cat: 'artist', location: 'Tema', budget: 9000, urgency: 'planned' }]);
    const exp6 = await callRaw('matchEventsExport', {});
    const ev6 = exp6.body.rows.filter(r => r.bookingId === bLTR3.id)[0];
    const p1002 = ev6 && ev6.candidates.find(c => c.proId === 'P1002');
    check('ID-gate stage exported as a feature (P1002 grace-stage, still invited)', p1002 && p1002.gateStage === 'expired' && p1002.graceDaysLeft > 0 && (bLTR3.matchedProIds || []).includes('P1002'), ev6 && ev6.candidates.map(c => c.proId + ':' + c.gateStage));
    /* NOTE: stay signed in as admin — later sections ([7e] queue, [9] stats)
       ride the standing session, same as before this section existed. */

    console.log('[7k] SMS/WhatsApp gateway (channel-preference delivery)');
    /* Pro notices ride notify() → notify-channels.js → the webhook gateway,
       honouring contact_channels. The mock gateway on :8398 is ground truth;
       channel_outbound is the server-side audit. */
    const clearMock = await fetch(MSG_MOCK + '/_clear?key=mock-msg-key', { method: 'POST' });
    check('mock gateway reachable', clearMock.ok === true, clearMock.status);
    logout();   /* the standing admin cookie would defeat an anon-probe */
    const coAnon = await callRaw('channelOutboundRecent', {});
    check('outbound audit read is admin-gated (anon rejected)', coAnon.status === 200 && coAnon.body.ok === false, coAnon.body);
    await login('admin', { password: '4321' });
    const coAdmin = await callRaw('channelOutboundRecent', { limit: 500 });
    check('outbound audit readable with an admin session', coAdmin.body.ok === true && Array.isArray(coAdmin.body.rows), coAdmin.body);
    /* Failure path setup: temporarily point an EXISTING seeded pro (P1006 —
       unique phone, untouched by other sections) at a number the mock
       REJECTS (233200000001 → HTTP 500), probe it, then restore. Creating a
       pro here would break the [9] adminStats pros===12 invariant.
       updateProProfile is PRO_OWNED → the flip runs under P1006's session. */
    await login('pro', { phone: '0240000015', secret: 'skillconnect' });
    check('P1006 phone flip to the rejected number', ((await call('updateProProfile', ['P1006', { phone: '0200000001' }])) || {}).phone === '0200000001');
    /* Full booking lifecycle → the pro notices (BOOKED / escrow funded /
       released) each dispatch over the chosen pro's preferred channels.
       HandyPro P1011 (Tema) wins near-first here; its seed preference comes
       from the same mix as the sandbox (expectations read live below). */
    const bMsg = await call('createBooking', [{ name: 'Gateway Cust', phone: '0244999050', cat: 'handy', location: 'Tema', budget: 900, urgency: 'planned' }]);
    const qMsg = await call('getQuotesFor', [bMsg.id]);
    await call('acceptQuote', [qMsg[0].id]);
    await call('payIntoEscrow', [bMsg.id, 'momo']);
    await call('releaseEscrow', [bMsg.id]);
    const msgBooking = await call('getBooking', [bMsg.id]);
    const chosenMsg = msgBooking.chosenProId;
    check('lifecycle chosen pro is P1011 (near-first from Tema)', chosenMsg === 'P1011', chosenMsg);
    /* Seed-mix aware expectations: the chosen pro's OWN preference defines
       the expected channel set (sms / whatsapp / both). */
    const chosenPref = ((await call('getPro', [chosenMsg])) || {}).contactChannels || 'both';
    const expectChans = chosenPref === 'both' ? ['sms', 'whatsapp'] : [chosenPref];
    const chosenMsisdn = String(((await call('getPro', [chosenMsg])) || {}).phone || '').replace(/\D/g, '').replace(/^0/, '233');
    await new Promise(r => setTimeout(r, 1500));   /* fire-and-forget leg gets a beat */
    const coHook = { adminSession: '1', limit: 500 };   /* sandbox hook: audit reads ride any session */
    const coLife = (await callRaw('channelOutboundRecent', coHook)).body.rows.filter(r => r.proId === chosenMsg && r.text.indexOf(bMsg.id) !== -1);
    check('pro notices audited for EXACTLY the pro\'s preferred channels (' + chosenPref + ')', coLife.length >= expectChans.length && expectChans.every(ch => coLife.some(r => r.channel === ch)) && coLife.every(r => expectChans.includes(r.channel)), coLife.map(r => r.channel + ':' + r.status));
    check('audited rows carry the pro msisdn (0-prefix → 233)', coLife.length > 0 && coLife.every(r => r.to === chosenMsisdn), coLife.map(r => r.proId + '/' + r.to + ' vs ' + chosenMsisdn));
    const mockSees = (await (await fetch(MSG_MOCK + '/_sends?key=mock-msg-key')).json()).sends.filter(s => s.proId === chosenMsg && s.text.indexOf(bMsg.id) !== -1);
    check('gateway actually received the lifecycle notices', mockSees.length >= expectChans.length && mockSees.every(s => expectChans.includes(s.channel)), mockSees.map(s => s.channel + ':' + s.acceptedId));
    check('accepted sends audit as sent', coLife.length > 0 && coLife.every(r => r.status === 'sent'), coLife.map(r => r.status + ':' + (r.detail || '')));
    /* Failure path: the rejected number lands as audited 'failed' rows.
       (notifyProByChannel itself is INTERNAL — dispatch goes through the
       admin test-send route, which shares deliverProNotice.) */
    const failPref = ((await call('getPro', ['P1006'])) || {}).contactChannels || 'both';
    const failLegs = failPref === 'both' ? 2 : 1;
    const nbFail = await callRaw('channelTestSend', { proId: 'P1006', adminSession: '1', text: 'Failure path probe' });
    check('gateway rejection surfaces (every leg failed)', nbFail.body.ok === false && nbFail.body.results.length === failLegs && nbFail.body.results.every(r => r.ok === false), nbFail.body);
    const auditFail = (await callRaw('channelOutboundRecent', { adminSession: '1', limit: 20 })).body.rows.filter(r => r.proId === 'P1006');
    check('failed sends audited with the carrier detail', auditFail.length >= failLegs && auditFail.some(r => r.status === 'failed' && /carrier rejected/.test(r.detail || '')), auditFail.map(r => r.status + ':' + (r.detail || '')));
    await call('updateProProfile', ['P1006', { phone: '0240000015' }]);   /* restore seed phone (still P1006's session) */
    /* Channel PREFERENCE honoured: flip P1011 (HandyPro, 'both') to sms-only
       under its own session, verify a single sms leg, then restore. */
    await login('pro', { phone: '0240000020', secret: 'skillconnect' });
    check('P1011 channel flip to sms-only', ((await call('updateProProfile', ['P1011', { contactChannels: 'sms' }])) || {}).contactChannels === 'sms');
    const nbSms = await callRaw('channelTestSend', { proId: 'P1011', adminSession: '1', text: 'Preference probe' });
    check('sms-only preference routes ONE leg (not both)', nbSms.body.ok === true && nbSms.body.results.length === 1 && nbSms.body.results[0].channel === 'sms', nbSms.body);
    await call('updateProProfile', ['P1011', { contactChannels: 'both' }]);
    const nbBoth = await callRaw('channelTestSend', { proId: 'P1011', adminSession: '1', text: 'Both-channels probe' });
    check("restored 'both' preference routes BOTH legs again", nbBoth.body.ok === true && nbBoth.body.results.length === 2 && nbBoth.body.results.every(r => r.ok === true), nbBoth.body);
    check('channel preference restored', ((await call('getPro', ['P1011'])).contactChannels) === 'both');
    logout();
    await login('admin', { password: '4321' });   /* standing admin session restored */

    console.log('[7l] notification preference center (mute low-priority, keep money alerts)');
    /* Authz: prefs are pro-owned — a pro cannot touch another pro's prefs and
       an anon caller cannot read them. */
    const anonPrefs = await call('notificationPrefsGet', ['P1011']);
    check('prefs read requires a session (anon rejected)', anonPrefs && anonPrefs.ok === false, anonPrefs);
    await login('pro', { phone: '0240000010', secret: 'skillconnect' });   /* P1001 */
    const otherPrefs = await call('notificationPrefsGet', ['P1011']);
    check('pro cannot read another pro\'s preferences', otherPrefs && otherPrefs.ok === false, otherPrefs);
    const otherSet = await call('notificationPrefsSet', ['P1011', ['review']]);
    check('pro cannot write another pro\'s preferences', otherSet && otherSet.ok === false, otherSet);
    /* Mute a mutable type under the pro's own session. */
    const setR = await call('notificationPrefsSet', ['P1001', ['booking', 'review']]);
    check('prefs saved (muted list echoed)', setR && setR.ok === true && setR.muted.length === 2 && setR.muted.includes('booking') && setR.muted.includes('review'), setR);
    const getR = await call('notificationPrefsGet', ['P1001']);
    check('prefs read back with the class catalogue', getR && getR.ok === true && getR.mutable.length === 3 && getR.critical.includes('escrow') && getR.critical.includes('payout'), getR);
    /* Attempting to mute a CRITICAL type is rejected, not silently stored. */
    const setCrit = await call('notificationPrefsSet', ['P1001', ['booking', 'escrow', 'job', 'payout']]);
    check('critical types refused with the muting request', setCrit && setCrit.ok === true && setCrit.muted.length === 1 && setCrit.muted.includes('booking') && (setCrit.rejected || []).length === 3, setCrit);
    /* Prefs save is REPLACE (PUT semantics — the UI posts full checkbox
       state), so re-assert the intended muted set before probing. */
    const setR2 = await call('notificationPrefsSet', ['P1001', ['booking', 'review']]);
    check('muted set re-asserted before the enforcement probes', setR2 && setR2.ok === true && setR2.muted.length === 2, setR2);
    /* Enforcement: muted types never land; critical types always do. */
    await call('notify', [null, 'pro', 'P1001', 'booking', 'MUTED probe — new-match invitation']);
    await call('notify', [null, 'pro', 'P1001', 'review', 'MUTED probe — new review']);
    await call('notify', [null, 'pro', 'P1001', 'escrow', 'CRITICAL probe — escrow funded']);
    await call('notify', [null, 'pro', 'P1001', 'payout', 'CRITICAL probe — payout approved']);
    await call('notify', [null, 'pro', 'P1001', 'id_gate', 'CRITICAL probe — ID enforcement']);
    const nFinal = (await call('notificationsFor', ['pro', 'P1001'])).filter(n => n.text.indexOf('probe —') !== -1);
    check('muted types (booking/review) never landed', !nFinal.some(n => /MUTED probe/.test(n.text)), nFinal.map(n => n.type + ':' + n.text.slice(0, 20)));
    check('critical types (escrow/payout/id_gate) all landed', ['escrow', 'payout', 'id_gate'].every(t => nFinal.some(n => n.type === t)), nFinal.map(n => n.type));
    /* Unmute → the type flows again. */
    await call('notificationPrefsSet', ['P1001', []]);
    await call('notify', [null, 'pro', 'P1001', 'booking', 'UNMUTED probe — invitation flows again']);
    const nAfter = (await call('notificationsFor', ['pro', 'P1001'])).filter(n => n.text.indexOf('UNMUTED probe') !== -1);
    check('unmuting restores the alert stream', nAfter.length === 1, nAfter);
    /* Restore pristine preference for the reset-parity check. */
    await call('notificationPrefsSet', ['P1001', []]);
    logout();
    await login('admin', { password: '4321' });

    console.log('[7g] web push (off-website notifications)');
    const pk = await call('pushPublicKey');
    check('push layer configured with a VAPID public key', pk && pk.ok && typeof pk.publicKey === 'string' && pk.publicKey.length > 80, pk);
    const pushBk = await call('createBooking', [{ name: 'Push Cust', phone: '0244999040', cat: 'dj', location: 'Accra', budget: 900, urgency: 'planned' }]);
    const fakeSub = { endpoint: 'https://push.test.example/send/' + Date.now(), keys: { p256dh: 'BPrJ3cDUMKBj5qDxYbFqFbW4FGvJ4PyIhCLTJUOperationFake', auth: 'fakeauthsecret' } };
    const subAnon = await fetch(BASE + '/api/pushSubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ subscription: fakeSub }) });
    check('push subscribe needs a booking ref or pro session', subAnon.ok === true && (await subAnon.json()).ok === false);
    const sub1 = await fetch(BASE + '/api/pushSubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ subscription: fakeSub, bookingRef: pushBk.id }) });
    check('customer subscription stored (booking-ref pinned)', sub1.ok === true && (await sub1.json()).ok === true, sub1.status);
    const sub2 = await fetch(BASE + '/api/pushSubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ subscription: fakeSub, bookingRef: pushBk.id }) });
    check('re-subscribing updates in place (no duplicate rows)', sub2.ok === true && (await sub2.json()).updated === true);
    const subBad = await fetch(BASE + '/api/pushSubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ subscription: fakeSub, bookingRef: 'SC-BK-000000' }) });
    check('subscribe refuses an unknown booking ref', (await subBad.json()).ok === false);
    const pt = await callRaw('pushTest', { bookingRef: pushBk.id, text: 'Smoke push test' });
    check('sandbox push test dispatches through the pipeline', pt.body.ok === true && pt.body.sent >= 0, pt.body);
    const unsub = await fetch(BASE + '/api/pushUnsubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: fakeSub.endpoint }) });
    check('unsubscribe removes the device', unsub.ok === true && (await unsub.json()).ok === true);

    console.log('[7e] admin manual-match queue');
    const b10 = await call('createBooking', [{ name: 'Queue Cust', phone: '0244999010', cat: 'mc', location: 'Accra', budget: 400, urgency: 'planned' }]);
    const q7 = await call('adminNoMatchQueue');
    const q7b = q7.find(x => x.booking.id === b10.id);
    check('over-budget booking appears in the queue', !!q7b, q7.map(x => x.booking.id));
    check('queue carries the category pool with prices', q7b && q7b.pool.length >= 1 && typeof q7b.pool[0].price === 'number', q7b && q7b.pool.map(p => p.id + ':' + p.price));
    const asg = await call('adminAssign', [b10.id, q7b.pool[0].id]);
    check('one-click assign succeeds', asg && asg.ok === true, asg);
    const q7after = await call('getQuotesFor', [b10.id]);
    check('assigned pro quoted at their listed rate', q7after.length === 1 && q7after[0].price === q7b.pool[0].price, q7after.map(q => q.price));
    check('assigned booking leaves the queue', (await call('adminNoMatchQueue')).every(x => x.booking.id !== b10.id));

    console.log('[8] pro OTP login (sandbox echo, single-use) + pro session');
    const otp = await call('requestProOtp', ['0240000010']);
    check('OTP issued with sandbox code', otp && otp.ok && /^\d{6}$/.test(otp.sandboxCode), otp);
    const lg = await call('proLogin', ['0240000010', otp.sandboxCode]);
    check('OTP login works', lg && lg.ok && lg.usedOtp === true, lg);
    const lg2 = await call('proLogin', ['0240000010', otp.sandboxCode]);
    check('OTP is single-use', lg2 && !lg2.ok, lg2);
    const lg3 = await call('proLogin', ['0240000010', 'skillconnect']);
    check('default password also works', lg3 && lg3.ok && !lg3.usedOtp, lg3);
    const pl = await login('pro', { phone: '0240000010', secret: 'skillconnect' });
    check('pro session established (cookie)', pl && pl.ok === true && !!cookieJar.sc_session, pl);

    console.log('[9] admin auth & stats + admin session');
    check('wrong admin password rejected', (await call('adminLogin', ['nope'])) === false);
    check('default admin password accepted', (await call('adminLogin', ['4321'])) === true);
    const al = await login('admin', { password: '4321' });
    check('admin session still valid', al && al.ok === true && !!cookieJar.sc_session, al);
    const st = await call('adminStats');
    check('stats aggregate', st && st.pros === 12 && st.bookings >= 3 && typeof st.gmv === 'number', st);

    console.log('[9b] go-live authorization guard');
    logout();
    const anonStats = await call('adminStats');
    check('anonymous adminStats rejected', anonStats && anonStats.ok === false, anonStats);
    check('anonymous allBookings rejected', (await call('allBookings')).ok === false);
    check('anonymous resolveDispute rejected', (await call('resolveDispute', ['SC-DS-41', 'resolved_rematch', 'x'])).ok === false);
    await login('admin', { password: '4321' });
    check('admin session restores admin calls', (await call('adminStats')).ok !== false);
    logout();
    await login('pro', { phone: '0240000010', secret: 'skillconnect' });   /* this pro IS P1001 */
    check('pro cannot call admin functions', (await call('adminStats')).ok === false);
    check('pro cannot manage another pro (payoutPro P1002)', (await call('payoutPro', ['P1002', 10])).ok === false);
    const selfPay = await call('payoutPro', ['P1010', 1]);
    check('pro reaches own wallet fn (business error, not authz)', selfPay && !/sign-in required/i.test(selfPay.error || ''), selfPay);
    logout();
    await login('admin', { password: '4321' });

    console.log('[10] customers, support, identity');
    const ch = await call('customerHistory', ['0244999001']);
    check('identity = last 9 digits', ch && ch.key === '244999001' && ch.bookings.length >= 1, ch && ch.key);
    const sm = await call('submitSupportMessage', ['Ama', '0244888777', 'payment', '', 'Where is my refund?']);
    check('support message stored + ref', sm && sm.ok && /^MSG-[A-Z0-9]{5}$/.test(sm.message.ref), sm && sm.message && sm.message.ref);

    console.log('[9c] payout workflow: request → approve → batch → pay (atomic debit)');
    logout();
    await login('pro', { phone: '0240000010', secret: 'skillconnect' });   /* P1001 */
    const p1before = (await call('getPro', ['P1001'])).balance;
    const prTooSmall = await call('requestPayout', ['P1001', 5]);
    check('payout below minimum rejected', prTooSmall && prTooSmall.ok === false && /Minimum/.test(prTooSmall.error), prTooSmall);
    const prOver = await call('requestPayout', ['P1001', 999999]);
    check('payout above balance rejected', prOver && prOver.ok === false && /balance/i.test(prOver.error), prOver);
    const pr1 = await call('requestPayout', ['P1001', 50]);
    check('payout request filed (SC-PO- ref, no debit)', pr1 && pr1.ok && /^SC-PO-\d+$/.test(pr1.requestId) && (await call('getPro', ['P1001'])).balance === p1before, pr1);
    const pr2 = await call('requestPayout', ['P1001', p1before]);
    check('pending requests RESERVE balance', pr2 && pr2.ok === false && /reserved|available/i.test(pr2.error), pr2);
    const prHist = await call('myPayouts', ['P1001']);
    check('myPayouts lists the pro\'s own requests', Array.isArray(prHist) && prHist.some(r => r.id === pr1.requestId), prHist && prHist.length);
    await login('admin', { password: '4321' });
    const q0 = await call('payoutQueue');
    check('admin payoutQueue sees the request', q0 && q0.pending.some(r => r.id === pr1.requestId), q0 && q0.pending.length);
    const cb = await call('createPayoutBatch', [[pr1.requestId], 'smoke batch']);
    check('batch created (SC-PB- ref, still no debit)', cb && cb.ok && /^SC-PB-\d+$/.test(cb.batchId) && (await call('getPro', ['P1001'])).balance === p1before, cb);
    const pb = await call('processPayoutBatch', [cb.batchId]);
    const p1after = (await call('getPro', ['P1001'])).balance;
    check('batch paid → wallet debited exactly once', pb && pb.ok && pb.total === 50 && p1after === Math.round((p1before - 50) * 100) / 100, [pb, p1before, p1after]);
    const txns3 = await call('getTransactions');
    check('payout ledger row written', txns3.some(t => t.type === 'payout' && String(t.note || '').includes(cb.batchId)), txns3.filter(t => t.type === 'payout').length);
    const pbAgain = await call('processPayoutBatch', [cb.batchId]);
    check('batch replay blocked (idempotent)', pbAgain && pbAgain.ok === false, pbAgain);
    check('no double debit on replay', (await call('getPro', ['P1001'])).balance === p1after);
    const anonQueue = await (async () => { logout(); const r = await call('payoutQueue'); await login('admin', { password: '4321' }); return r; })();
    check('anonymous payoutQueue rejected', anonQueue && anonQueue.ok === false, anonQueue);

    console.log('[11] snapshot reassembly (sync bridge)');
    const snap = await call('snapshot', null, 'GET');
    check('snapshot reassembles sc_db_v1 shape', snap && snap.db && snap.db.pros.length === 12 && snap.db.counters.booking >= 284003, snap && snap.db && snap.db.counters);
    const sb = snap.db.bookings.find(x => x.id === B1);
    check('events/escrow inlined on bookings', sb && sb.escrow && sb.escrow.released === true && sb.events.length >= 4, sb && sb.escrow);

    console.log('[13] shared city list (sc-cities.js → registration combobox)');
    /* Static-asset contract: the shared Ghana list must carry [name, km,
       region] for every entry, cover Ghana's 16 regions, and register.html
       must include the script AND wire the searchable combobox to it. The
       suite has no browser, so these assert the served bytes (catches a
       forgotten include, a cache-busted stale copy, or a truncated list). */
    const citiesJs = await (await fetch(BASE + '/sc-cities.js?v=2')).text();
    /* Parse the array the way the page does (same 3-field shape), counting
       complete [name, km, region] entries — line-oriented counting misses
       lines that hold several entries. */
    const cityEntries = [...citiesJs.matchAll(/\['([^']+)',\s*(\d+),\s*'([^']+)'\]/g)];
    const cityCount = cityEntries.length;
    const cityNames = cityEntries.map(m => m[1]);
    check('city list served and populated (≥80 cities)', cityCount >= 80, cityCount);
    check('every entry carries [name, km, region]', cityCount > 0 && cityNames.every(Boolean) && !cityNames.some(n => n === ''), cityCount);
    const dupCities = cityNames.filter((n, i, a) => a.indexOf(n) !== i);
    check('no duplicate city names', dupCities.length === 0, dupCities);
    const regionNames = [...new Set([...citiesJs.matchAll(/\d+,\s*'((?:Greater Accra|Central|Western North|Western|Ashanti|Eastern|Volta|Oti|Northern|North East|Savannah|Upper East|Upper West|Bono East|Bono|Ahafo))'/g)].map(m => m[1]))];
    check('regions cover all 16 of Ghana\'s regions', regionNames.length === 16, regionNames.length);
    const regPage = await (await fetch(BASE + '/register.html')).text();
    check('register.html includes sc-cities.js (v2)', regPage.includes('sc-cities.js?v=2'), regPage.match(/sc-cities\.js\?v=\d+/));
    check('register.html wires the searchable combobox (input + hidden source-of-truth select)',
        regPage.includes('id="regCityInput"') && regPage.includes('id="regCityPanel"') && regPage.includes('id="regCity" hidden'));
    check('combobox auto-suggest present (hint element + suggestion block)',
        regPage.includes('id="regCityHint"') && regPage.includes('autoSuggestBaseCity'));
    const dirPage = await (await fetch(BASE + '/directory.html')).text();
    check('directory filter still consumes the shared list (flat select, v2 script)',
        dirPage.includes('sc-cities.js?v=2') && dirPage.includes("getElementById('filterCity')"));

    console.log('[12] sandbox reset parity (reset wipes sessions — re-login after)');
    logout();
    const rs = await call('reset');
    check('reset ok', rs && rs.ok, rs);
    await login('admin', { password: '4321' });
    const prosAfter = await call('getPros');
    const bkAfter = await call('allBookings');
    check('back to pristine seed (12 pros, 0 bookings)', prosAfter.length === 12 && bkAfter.length === 0, [prosAfter.length, bkAfter.length]);

    console.log('\n=== ' + passed + ' passed, ' + failed + ' failed ===');
    process.exit(failed ? 1 : 0);
})().catch(e => { console.error('SMOKE TEST CRASHED:', e.message); process.exit(1); });
