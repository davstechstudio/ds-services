/* Grants notifications for http://127.0.0.1:8200 in the Freebuff preview
   browser's partition profile. Close the preview browser tabs first (the
   running Chromium rewrites Preferences on exit and would discard this). */
const fs = require('fs');
const path = require('path');

const base = process.env.APPDATA + '\\Freebuff\\Partitions';
for (const dir of fs.readdirSync(base)) {
    const pref = path.join(base, dir, 'Preferences');
    if (!fs.existsSync(pref)) continue;
    let j = {};
    try { j = JSON.parse(fs.readFileSync(pref, 'utf8')); } catch (e) { continue; }
    j.profile = j.profile || {};
    j.profile.content_settings = j.profile.content_settings || {};
    j.profile.content_settings.exceptions = j.profile.content_settings.exceptions || {};
    j.profile.content_settings.exceptions.notifications =
        j.profile.content_settings.exceptions.notifications || {};
    j.profile.content_settings.exceptions.notifications['http://127.0.0.1:8200,*'] = { setting: 1 };
    fs.writeFileSync(pref, JSON.stringify(j));
    console.log('granted:', dir);
}
