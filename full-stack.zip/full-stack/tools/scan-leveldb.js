const fs = require('fs');
const path = require('path');
const dir = 'C:\\Users\\dawcy\\AppData\\Roaming\\Freebuff\\Partitions\\freebuff-browser-243848c3284594a93f45-default\\Local Storage\\leveldb';
const files = fs.readdirSync(dir).map(f => path.join(dir, f));
for (const f of files) {
    try {
        const s = fs.readFileSync(f, 'utf8');
        if (s.includes('127.0.0.1:8200')) {
            let idx = s.indexOf('127.0.0.1:8200');
            let count = 0;
            while (idx !== -1 && count < 3) {
                const ctx = s.slice(Math.max(0, idx - 100), idx + 120).replace(/[^\x20-\x7E]/g, '.');
                console.log('FILE:', path.basename(f), 'CTX:', JSON.stringify(ctx));
                idx = s.indexOf('127.0.0.1:8200', idx + 1);
                count++;
            }
        }
    } catch (e) { /* skip binary read errors */ }
}
console.log('scan done');
