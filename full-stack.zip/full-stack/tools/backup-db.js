#!/usr/bin/env node
/* ============================================================
   tools/backup-db.js — nightly MySQL backup for SkillConnect.

   Dumps the full skillconnect schema (single transaction, so
   the escrow ledger stays consistent) to backups/YYYY-MM-DD/
   and prunes backups older than RETENTION_DAYS.

   Usage (cron / Task Scheduler):
     node tools/backup-db.js            # uses server/.env creds
   Env:
     SC_DB_HOST/PORT/USER/PASS/NAME     (falls back to .env)
     SC_BACKUP_DIR                      (default ./backups)
     SC_BACKUP_KEEP_DAYS                (default 14)

   Restore:
     gunzip < backups/2026-09-28/skillconnect-0330.sql.gz | mysql -u USER -p skillconnect
   ============================================================ */

'use strict';

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

/* Minimal .env reader (same keys the server uses) — avoids a dotenv dep. */
function readEnvFile(p) {
    try {
        const out = {};
        fs.readFileSync(p, 'utf8').split(/\r?\n/).forEach(line => {
            const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
            if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
        });
        return out;
    } catch (e) { return {}; }
}
const envFile = readEnvFile(path.join(__dirname, '..', 'server', '.env'));
const env = k => process.env['SC_' + k] || envFile['SC_' + k] || '';

const HOST = env('DB_HOST') || '127.0.0.1';
const PORT = env('DB_PORT') || '3306';
const USER = env('DB_USER') || 'skillconnect';
const PASS = env('DB_PASS') || '';
const NAME = env('DB_NAME') || 'skillconnect';
const KEEP_DAYS = Number(process.env.SC_BACKUP_KEEP_DAYS || 14);
const BACKUP_ROOT = path.resolve(process.env.SC_BACKUP_DIR || path.join(__dirname, '..', 'backups'));

const now = new Date();
const stamp = now.toISOString().slice(0, 10);
const dir = path.join(BACKUP_ROOT, stamp);
fs.mkdirSync(dir, { recursive: true });

const file = path.join(dir, 'skillconnect-' + String(now.getHours()).padStart(2, '0') + String(now.getMinutes()).padStart(2, '0') + '.sql.gz');

/* --single-transaction: consistent InnoDB snapshot without locking out
   the live site. --no-tablespaces avoids the PROCESS privilege on
   shared hosting. --routines/--triggers included for completeness. */
const args = [
    '--single-transaction',
    '--quick',
    '--no-tablespaces',
    '--routines',
    '--triggers',
    '--default-character-set=utf8mb4',
    '--host=' + HOST, '--port=' + PORT, '--user=' + USER,
    NAME
];

const dump = execFileSync('mysqldump', args, {
    env: Object.assign({}, process.env, { MYSQL_PWD: PASS }),
    maxBuffer: 512 * 1024 * 1024
});

/* gzip level 6 keeps a ~2 MB schema+seed around ~400 KB. */
const zlib = require('zlib');
fs.writeFileSync(file, zlib.gzipSync(dump, { level: 6 }));
console.log('[backup] wrote', file, '(' + Math.round(fs.statSync(file).size / 1024) + ' KB)');

/* Retention: prune day-directories older than KEEP_DAYS. */
const cutoff = Date.now() - KEEP_DAYS * 86400000;
let pruned = 0;
fs.readdirSync(BACKUP_ROOT).forEach(name => {
    const full = path.join(BACKUP_ROOT, name);
    const m = name.match(/^\d{4}-\d{2}-\d{2}$/);
    if (!m || !fs.statSync(full).isDirectory()) return;
    if (new Date(name + 'T00:00:00Z').getTime() < cutoff) {
        fs.rmSync(full, { recursive: true, force: true });
        pruned++;
    }
});
if (pruned) console.log('[backup] pruned', pruned, 'old backup day-directories');

/* Verify: last dump must contain at least one INSERT (empty dump = alarm). */
if (!dump.includes('INSERT INTO')) {
    console.error('[backup] WARNING: dump contains no INSERT statements — check the database!');
    process.exit(2);
}
console.log('[backup] done');
