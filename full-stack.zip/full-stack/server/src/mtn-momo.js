/* ============================================================
   mtn-momo.js — minimal MTN MoMo Collections client (direct API,
   no SDK dependency). https://momodeveloper.mtn.com

   Flow (Collection API):
     1. POST /collection/token/               OAuth2 client credentials
     2. POST /collection/v1_0/requesttopay    MTN mints the referenceId
        (X-Reference-Id header) — the customer approves on their handset
     3. GET  /collection/v1_0/requesttopay/:id → PENDING | SUCCESSFUL | FAILED

   We always send OUR payment_intents reference (PMT-…) as the externalId
   so reconciliation keys match across gateways; MTN's referenceId (UUID)
   is stored in the intent's raw audit. Status is PULLED (poll/verify) —
   same confirm path as every other adapter. Credentials come from
   config.infra (env SC_MTN_*), never from the settings table.
   ============================================================ */

'use strict';

const config = require('./config');

/* OAuth2 token cache — MTN tokens live ~1 hour; refresh 60s early. */
let token = null;
let tokenAt = 0;

async function getToken() {
    if (token && Date.now() - tokenAt < 55 * 60 * 1000) return token;
    const infra = config.infra;
    const auth = Buffer.from(infra.MTN_API_USER + ':' + infra.MTN_API_KEY).toString('base64');
    const r = await fetch(infra.MTN_BASE_URL + '/collection/token/', {
        method: 'POST',
        headers: { 'Authorization': 'Basic ' + auth, 'Ocp-Apim-Subscription-Key': infra.MTN_SUBSCRIPTION_KEY }
    });
    const j = await r.json();
    if (!r.ok || !j.access_token) throw new Error('MTN token failed: ' + (j.message || ('HTTP ' + r.status)));
    token = j.access_token;
    tokenAt = Date.now();
    return token;
}

function mtnHeaders() {
    return {
        'Authorization': 'Bearer ' + token,
        'Ocp-Apim-Subscription-Key': config.infra.MTN_SUBSCRIPTION_KEY,
        'X-Target-Environment': config.infra.MTN_TARGET_ENV
    };
}

/* Request a payment. Returns { ok, referenceId } — the customer then
   approves on their handset. Throws on transport/config errors. */
async function requestToPay(o) {
    await getToken();
    const referenceId = cryptoRandomUuid();
    const body = {
        amount: String(o.amount),
        currency: o.currency || 'GHS',
        externalId: o.reference,             /* our PMT-… reference */
        payer: { partyIdType: 'MSISDN', partyId: String(o.phone || '').replace(/\D/g, '') },
        payerMessage: o.payerMessage || 'SkillConnect payment',
        payeeNote: o.payeeNote || 'SkillConnect'
    };
    const r = await fetch(config.infra.MTN_BASE_URL + '/collection/v1_0/requesttopay', {
        method: 'POST',
        headers: Object.assign(mtnHeaders(), {
            'X-Reference-Id': referenceId   /* pull mode: no X-Callback-Url needed */
        }),
        body: JSON.stringify(body)
    });
    if (r.status !== 202) {
        let msg = 'HTTP ' + r.status;
        try { const j = await r.json(); msg = j.message || msg; } catch (e) { /* body optional */ }
        throw new Error('MTN requestToPay failed: ' + msg);
    }
    return { ok: true, referenceId };
}

/* Poll one request's status. Returns { ok, status, raw } with status in
   PENDING | SUCCESSFUL | FAILED (uppercase, as MTN reports). */
async function requestStatus(referenceId) {
    await getToken();
    const r = await fetch(config.infra.MTN_BASE_URL + '/collection/v1_0/requesttopay/' + encodeURIComponent(referenceId), {
        headers: mtnHeaders()
    });
    const j = await r.json();
    if (!r.ok) throw new Error('MTN status failed: ' + (j.message || ('HTTP ' + r.status)));
    return { ok: true, status: String(j.status || 'PENDING').toUpperCase(), raw: j };
}

function cryptoRandomUuid() {
    return require('crypto').randomUUID();
}

/* Adapter surface matching paystack.js as used by payments.js:
   - initialize: start the collection (customer gets a MoMo prompt)
   - verify:     map MTN status onto success / pending / failed */
module.exports = {
    configured: () => !!(config.infra.MTN_SUBSCRIPTION_KEY && config.infra.MTN_API_USER && config.infra.MTN_API_KEY),
    initialize: async (o) => {
        try {
            const r = await requestToPay({
                reference: o.reference,
                amount: o.amountMinor / 100,     /* MTN takes whole units */
                currency: o.currency,
                phone: o.phone,
                payerMessage: o.meta && o.meta.payerMessage,
                payeeNote: o.meta && o.meta.payeeNote
            });
            return { ok: true, simulated: false, referenceId: r.referenceId, poll: true };
        } catch (e) {
            return { ok: false, error: e.message };
        }
    },
    verify: async (secret_unused, referenceId) => {
        try {
            const s = await requestStatus(referenceId);
            return {
                ok: true,
                status: s.status === 'SUCCESSFUL' ? 'success' : (s.status === 'FAILED' ? 'failed' : 'pending'),
                gatewayRef: referenceId,
                raw: s.raw
            };
        } catch (e) {
            return { ok: false, error: e.message };
        }
    }
};
