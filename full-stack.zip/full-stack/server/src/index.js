/* ============================================================
   index.js — HTTP layer: routes (one per SC function), static
   file serving for the existing pages, and cookie sessions.

   Design contract (docs/backend-migration.md Phase 2/3):
   - POST /api/<fnName>  body = the function's arguments as a
     JSON array (positional) or object {args:[...]}; response is
     always JSON {ok:true, result} or {ok:false, error}.
   - GET  /api/settings  returns the settings table (catalog +
     tunables) so pages can render admin-changed values.
   - Sessions: httpOnly `sc_session` cookie; POST /api/login as
     admin/pro creates one; POST /api/logout destroys it. Pages
     never touch tokens — the browser keeps no session state.
   - No business constants here: the SC layer reads settings.
   ============================================================ */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const matchLog = require('./match-log');
const db = require('./db');
const api = require('./sc-api');
const payments = require('./payments');
const paystack = require('./paystack');
const push = require('./push');
const aiParse = require('./ai-parse');
const msgChannels = require('./notify-channels');
const setup = require('./setup');

const PORT = config.infra.PORT;
const ROOT = path.join(__dirname, '..', '..');   // repo root: pages live here
const MIME = {
    '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.sql': 'text/plain; charset=utf-8',
    '.md': 'text/plain; charset=utf-8',
    '.webmanifest': 'application/manifest+json; charset=utf-8'
};

/* Methods callable over HTTP: everything except session primitives,
   which have dedicated routes, plus internal mappers/helpers. */
const INTERNAL = new Set([
    'proOut', 'bookingOut', 'quoteOut', 'txnOut', 'appOut', 'reviewOut', 'supportOut', 'disputeOut',
    'catMap', 'urgencyMap', 'proIconsMap', 'proRow', 'escrowFor', 'eventsFor', 'nextEventSeq',
    'pushEvent', 'addQuoteInternal', 'bookingOut', 'round2', 'createSession', 'destroySession',
    'esc', 'escTxnRef', 'fundEscrowInTx', 'markRegFeePaidInTx', 'ensureSeeded', 'seedBaseline',
    'setSetting',  /* admin-gated via the dedicated route below */
    'setAdminSettingAllowlist', 'idGateSync', 'gateKeep', 'idGateWindows',
    'notifyProByChannel', 'migrateContactChannels',
    'migrateMatchEvents', 'matchEventsExport', 'snapshot',
    'migrateNotifyPrefs',
    'updateOutcome', 'recordMatchEventInTx', 'candidateFeatures', 'ENGINE_VERSION',
    'pushNotify', 'sendToAudience',
    'migrateChannelOutbound', 'deliverProNotice', 'sendChannel', 'normMsisdn',
    'channelOutboundRecent', 'channelTestSend',
]);

function json(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
}

/* ---------- first-run installer (browser-based) ----------
   GET  /setup.html      static page (served like any other file)
   GET  /setupStatus     open read: connection + table state
   POST /setupRun        token-gated: schema + boot migrations + seed
   POST /setupSaveEnv    token-gated: write server/.env DB credentials
   The installer self-locks once the core tables exist — re-running an
   upgrade later is still possible after dropping in new code, but a
   second RUN on a completed install is refused (setup.js returns
   installed:true and the page blocks). */
function setupGuard(req, body) { return setup.authorized(body); }

async function handleSetup(name, req, res, body) {
    if (name === 'setupStatus') {
        let status = null;
        try { status = await setup.dbStatus(); } catch (e) { status = { connected: false, error: e.code || e.message, tables: 0, installed: false }; }
        return json(res, 200, { ok: true, status, tokenRequired: true });
    }
    if (name === 'setupRun') {
        if (!setupGuard(req, body)) return json(res, 403, { ok: false, error: 'Invalid or missing setup token — it is printed in the server console at first start.' });
        try {
            const pre = await setup.dbStatus();
            /* Self-lock ONLY on a fully complete database — an upgrade that
               is missing any expected table (new module, damaged table) must
               stay runnable. Re-running is idempotent by design. */
            if (pre.connected && pre.complete) return json(res, 200, { ok: false, alreadyInstalled: true, error: 'Already installed and complete — nothing to do. For upgrades, drop in the new code and re-run: missing tables/columns/rows are filled without touching data.', status: pre });
            const status = await setup.runInstall();
            return json(res, 200, { ok: true, status });
        } catch (e) {
            return json(res, 200, { ok: false, error: e.message });
        }
    }
    if (name === 'setupSaveEnv') {
        if (!setupGuard(req, body)) return json(res, 403, { ok: false, error: 'Invalid or missing setup token.' });
        try {
            const p = await setup.saveEnv(body || {});
            return json(res, 200, { ok: true, saved: p });
        } catch (e) {
            return json(res, 200, { ok: false, error: e.message });
        }
    }
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        let size = 0;
        const chunks = [];
        req.on('data', c => {
            size += c.length;
            if (size > 5 * 1024 * 1024) { reject(new Error('Request body too large.')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => {
            if (!chunks.length) return resolve({});
            try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
            catch (e) { reject(new Error('Invalid JSON body.')); }
        });
        req.on('error', reject);
    });
}

/* ---------- routes ---------- */

/* ---------- lightweight rate limiting (in-memory, per IP) ----------
   Brute-force guard for credential endpoints. Sliding fixed windows are
   enough here: the goal is making online guessing slow and loud, not
   replacing a WAF. Buckets self-clean on access. */
const RATE_LIMITS = {
    /* login is per-IP, not per-account: a shared office/NAT must not lock
       everyone out, while 20/min still caps online guessing brutally
       (credential-stuffing tools need thousands/min). The OTP and
       password-change routes stay much tighter. */
    'login': { max: 20, windowMs: 60000 },
    'adminLogin': { max: 8, windowMs: 60000 },
    'proLogin': { max: 8, windowMs: 60000 },
    'requestProOtp': { max: 3, windowMs: 300000 },
    'setAdminPassword': { max: 5, windowMs: 300000 },
    'setProPassword': { max: 5, windowMs: 300000 },
    'aiParse': { max: 15, windowMs: 60000 }   /* LLM cost guard (rules are cheap; the cap covers both) */
};
const rateBuckets = new Map();
function rateLimitOk(name, ip) {
    const rule = RATE_LIMITS[name];
    if (!rule) return true;
    const key = name + '|' + ip;
    const now = Date.now();
    let b = rateBuckets.get(key);
    if (!b || now - b.start > rule.windowMs) { b = { start: now, count: 0 }; rateBuckets.set(key, b); }
    b.count++;
    return b.count <= rule.max;
}
function clientIp(req) {
    return (req.socket && req.socket.remoteAddress) || 'unknown';
}

/* ---------- function-level authorization ----------
   The generic dispatcher runs 1:1 mirrored SC functions; admin and pro
   mutations MUST NOT be callable anonymously once real users exist.
   ADMIN_ONLY: admin console operations (the admin pages authenticate via
   POST /api/login first, which sets the session cookie).
   PRO_OWNED(fnIdx): the session proId must equal the given argument —
   applies to the ussd ops console too, which logs in per operator.
   The sc-session.js front-end adapter sends X-SC-Session-Role as a
   hint ONLY for pre-login UI rendering; it never grants anything. */
const ADMIN_ONLY = new Set([
    'allBookings', 'adminCustomers', 'adminNoMatchQueue', 'adminAssign', 'cancellationSummary',
    'adminStats', 'getApplications', 'reviewApplication', 'verifiedNotices', 'approveReverify', 'requestIdDocs',
    'getDisputes', 'resolveDispute', 'getTransactions', 'customerHistory', 'reassignBooking',
    'updateCms', 'supportMessages', 'resolveSupportMessage', 'markProPaid',
    'setAvailabilityStatus', 'addTxn', 'setBookingStatus',
    'payoutQueue', 'approvePayouts', 'rejectPayout', 'createPayoutBatch', 'processPayoutBatch',
    'setIdGateOverride'
]);
const PRO_OWNED = {
    proRespondQuote: 0, toggleProDate: 0, updateProProfile: 0, payoutPro: 0,
    submitReverify: 0, setPortfolio: 0, setProPassword: 0, proBookings: 0,
    requestPayout: 0, cancelPayout: 0, myPayouts: 0,
    notificationPrefsGet: 0, notificationPrefsSet: 0
};
const OPEN_READS = new Set([
    'getBooking', 'getBookingsFor', 'getQuotesFor', 'getPro', 'getPros', 'getReviewsFor',
    'getPortfolio', 'proAvailability', 'dateAvailability', 'chatMessages', 'applicationTrack',
    'notificationsFor', 'idStatus', 'getRegFee', 'proDirectoryUrl', 'proUsesDefaultPassword',
    'adminUsesDefaultPassword', 'getCms'
]);
const OPEN_WRITES = new Set([
    'createBooking', 'acceptQuote', 'payIntoEscrow', 'releaseEscrow', 'openDispute',
    'cancelBooking', 'rebookFrom', 'updateBookingBudget', 'addReview', 'sendChat', 'systemChat',
    'customerRematchOptions', 'customerRematchPick', 'addApplication', 'payRegFee',
    'submitSupportMessage', 'markNotificationsRead', 'notify'
]);
/* getSession/createSession/destroySession/adminLogin/proLogin/requestProOtp
   run before this table through dedicated or credential routes. */

async function authorizeFunction(name, args, req) {
    if (ADMIN_ONLY.has(name)) {
        const sess = await api.getSession(req);
        return sess && sess.role === 'admin'
            ? { ok: true }
            : { ok: false, error: 'Admin sign-in required.' };
    }
    const ownIdx = PRO_OWNED[name];
    if (ownIdx !== undefined) {
        const sess = await api.getSession(req);
        if (!sess || sess.role !== 'pro') return { ok: false, error: 'Professional sign-in required.' };
        const claimed = String(args[ownIdx] == null ? '' : args[ownIdx]);
        if (claimed !== String(sess.proId)) return { ok: false, error: 'You can only manage your own professional account.' };
    }
    /* everything else (OPEN_READS / OPEN_WRITES / credential fns) is open */
    return { ok: true };
}

const ROUTES = {
    /* --- auth/session (cookie-managed; not the raw SC fns) --- */
    'login': async (req, res, body) => {
        if (!rateLimitOk('login', clientIp(req))) return { ok: false, error: 'Too many sign-in attempts — please wait a minute and try again.' };
        const role = body.role === 'pro' ? 'pro' : 'admin';
        if (role === 'admin') {
            const ok = await api.adminLogin(body.password);
            if (!ok) return { ok: false, error: 'Wrong password.' };
            const row = await api.adminAuthMeta();
            await api.createSession(res, 'admin', null, row.updatedAt);
            /* Fresh deployments bootstrap with the seeded admin password;
               flag it so the console can force a real one immediately. */
            return { ok: true, role: 'admin', mustChangePassword: await api.adminUsesDefaultPassword() };
        }
        const r = await api.proLogin(body.phone, body.secret);
        if (!r.ok) return r;
        await api.createSession(res, 'pro', r.pro.id, r.pv);
        /* Go-live credential hygiene: the UI already prompts pros whose
           password is still the seeded default; the login response now
           carries the flag so clients can force the change explicitly. */
        return { ok: true, role: 'pro', pro: r.pro, usedOtp: !!r.usedOtp, mustChangePassword: await api.proUsesDefaultPassword(r.pro.id) };
    },
    'logout': async (req, res) => {
        await api.destroySession(req, res);
        return { ok: true };
    },
    'me': async (req, res) => {
        const sess = await api.getSession(req);
        if (!sess) return { ok: true, session: null };
        if (sess.role === 'pro') {
            const pro = await api.getPro(sess.proId);
            return { ok: true, session: { role: 'pro', proId: sess.proId, pro: pro ? { id: pro.id, name: pro.name } : null } };
        }
        return { ok: true, session: { role: 'admin' } };
    },
    /* --- settings bootstrap (replaces in-file constants) --- */
    'settings': async () => {
        const s = await config.allSettings();
        let priceStats = null;
        try { priceStats = await api.priceStats(); } catch (e) { /* optional */ }
        return {
            ok: true,
            settings: s,
            catalog: await api.getCatalog(),
            cms: await api.getCms(),
            availMeta: api.AVAIL_META,
            priceStats: priceStats
        };
    },
    /* --- payments (gateway seam; see payments.js) ---
       initiate → payment_intents row + checkout (or simulated confirm).
       status  → what the redirect page polls while the gateway works.
       verify  → pull-verify fallback when the webhook can't arrive. */
    'payments/initiate': async (req, res, body) => {
        return payments.initiate(String((body && body.purpose) || ''), String((body && body.refId) || ''), (body && body.method) || 'momo');
    },
    'payments/status': async (req, res, body) => {
        const ref = String((body && body.ref) || '');
        if (!ref) return { ok: false, error: 'Payment reference required.' };
        const [rows] = await db.q(
            'SELECT gateway_ref, purpose, booking_id, app_ref, amount, status, updated_at FROM payment_intents WHERE gateway_ref = ?', [ref]);
        if (!rows.length) return { ok: false, error: 'Unknown payment reference.' };
        const r = rows[0];
        return {
            ok: true,
            intent: {
                ref: r.gateway_ref, purpose: r.purpose,
                bookingId: r.booking_id || null, appRef: r.app_ref || null,
                amount: Number(r.amount), status: r.status, updatedAt: Number(r.updated_at)
            }
        };
    },
    'payments/verify': async (req, res, body) => {
        const ref = String((body && body.ref) || '');
        if (!ref) return { ok: false, error: 'Payment reference required.' };
        return payments.verifyAndConfirm(ref);
    },
    /* Gateway toggle — ADMIN ONLY (cookie session). GET returns status,
       POST {gateway:' '|paystack|mtn_momo} switches. Test-mode hook
       (?adminSession=1) mirrors /api/settings and needs sandbox_mode. */
    'payments/gateway': async (req, res, body) => {
        let isAdmin = false;
        const sess = await api.getSession(req);
        if (sess && sess.role === 'admin') isAdmin = true;
        else if (body && body.adminSession === '1' && config.infra.ALLOW_SANDBOX_HOOKS === true && await config.bool('sandbox_mode', true)) isAdmin = true;
        if (!isAdmin) return { ok: false, error: 'Admin sign-in required.' };
        if (req.method === 'POST' && body && body.gateway !== undefined) {
            const r = await payments.setGateway(String(body.gateway));
            if (!r.ok) return r;
        }
        return payments.gatewayInfo();
    },
    /* Admin-editable settings (allowlisted inside api.setSetting).
       Session-guarded like the gateway toggle; the sandbox test hook
       mirrors /api/settings so the smoke suite can exercise it. */
    /* ---------- AI price guidance ----------
       Live market stats per category + a before-you-submit outcome
       prediction for a specific budget. Open reads — guidance needs no
       account, and no personal data leaves the store. */
    'priceStats': async () => ({ ok: true, stats: await api.priceStats() }),
    'budgetOutcome': async (req, res, body) => {
        const cat = String((body && body.cat) || '');
        const budget = Number((body && body.budget) || 0);
        if (!cat) return { ok: false, error: 'Missing category.' };
        return { ok: true, outcome: await api.budgetOutcome(cat, budget) };
    },
    'adminSetSetting': async (req, res, body) => {
        let isAdmin = false;
        const sess = await api.getSession(req);
        if (sess && sess.role === 'admin') isAdmin = true;
        else if (body && body.adminSession === '1' && config.infra.ALLOW_SANDBOX_HOOKS === true && await config.bool('sandbox_mode', true)) isAdmin = true;
        if (!isAdmin) return { ok: false, error: 'Admin sign-in required.' };
        /* Batch form: { entries: [{key, value}, ...] } — one round-trip for the
           Platform Settings card; all-or-nothing (validate every key first). */
        if (body && Array.isArray(body.entries)) {
            for (const en of body.entries) {
                const probe = await api.setSetting(String((en && en.key) || ''), en && en.value);
                if (!probe.ok) return probe;
            }
            const results = [];
            for (const en of body.entries) {
                results.push(await api.setSetting(String(en.key), en.value));
            }
            return { ok: true, results: results };
        }
        return api.setSetting(String((body && body.key) || ''), body && body.value);
    },
    /* ---------- Web Push (off-website notifications) ----------
       publicKey: the VAPID public key the browser binds subscriptions to.
       subscribe: store a PushSubscription for a pro (session-owned) or a
       customer (identified by a booking ref's phone last-9, same identity
       the Track page already uses — no account needed).
       test: real end-to-end push through the configured pipeline
       (sandbox hook only, so a deployed server can't be spammed). */
    'pushPublicKey': async () => ({ ok: true, publicKey: push.publicKey(), enabled: push.enabled() }),
    /* ---------- SMS/WhatsApp gateway (off-platform pro notices) ----------
       Delivery itself is wired inside sc-api notify() (fire-and-forget,
       best-effort — the same posture as Web Push). These routes are the
       OBSERVABILITY surface: recent audited sends + a sandbox test send.
       Admin-gated because gateway sends cost money and leak phone numbers. */
    'channelOutboundRecent': async (req, res, body) => {
        const sess = await api.getSession(req);
        const viaHook = body && body.adminSession === '1' && config.infra.ALLOW_SANDBOX_HOOKS === true && await config.bool('sandbox_mode', true);
        if ((!sess || sess.role !== 'admin') && !viaHook) return { ok: false, error: 'Admin sign-in required.' };
        return { ok: true, configured: msgChannels.enabled(), rows: await msgChannels.channelOutboundRecent(body && body.limit) };
    },
    'channelTestSend': async (req, res, body) => {
        const sess = await api.getSession(req);
        const viaHook = body && body.adminSession === '1' && config.infra.ALLOW_SANDBOX_HOOKS === true && await config.bool('sandbox_mode', true);
        if ((!sess || sess.role !== 'admin') && !viaHook) return { ok: false, error: 'Admin sign-in required.' };
        if (!(body && body.proId)) return { ok: false, error: 'proId required — pick the pro whose channel preference should be honoured.' };
        const r = await msgChannels.deliverProNotice(String(body.proId), 'test', String((body && body.text) || 'SkillConnect GH test notice — SMS/WhatsApp delivery is live.'), true);
        return { ok: r.ok, results: r.results, error: r.error };
    },
    /* ---------- learning-to-rank capture (LTR-1) ----------
       Admin-gated export of match_events — the training file for a future
       ranker: one self-contained row per matching decision (full candidate
       pool, exposure, outcomes). Read-only; the events themselves are
       written inside the booking transactions (see match-log.js). */
    'matchEventsExport': async (req, res, body) => {
        const sess = await api.getSession(req);
        const viaHook = body && body.adminSession === '1' && config.infra.ALLOW_SANDBOX_HOOKS === true && await config.bool('sandbox_mode', true);
        if ((!sess || sess.role !== 'admin') && !viaHook) return { ok: false, error: 'Admin sign-in required.' };
        return { ok: true, engine: matchLog.ENGINE_VERSION, rows: await matchLog.exportEvents() };
    },
    /* ---------- AI booking assistant ----------
       Free text in → structured booking fields out. Deterministic parser
       always runs; an LLM refines when SC_AI_KEY is configured. Parsing
       NEVER books — the customer confirms the preview and the existing
       matching engine (near-first, budget ceiling, ID gate) takes over. */
    'aiParseBooking': async (req, res, body) => {
        if (!rateLimitOk('aiParse', clientIp(req))) return { ok: false, error: 'Too many attempts — please wait a moment and try again.' };
        const text = String((body && body.text) || '').trim();
        if (text.length < 4) return { ok: false, error: 'Tell us a bit more — what service do you need, where and when?' };
        if (text.length > 800) return { ok: false, error: 'That is a lot of detail — please keep it under 800 characters.' };
        const parsed = await aiParse.aiParse(text, {});
        if (!parsed.cat && !parsed.location && !parsed.date) {
            return { ok: false, error: 'Could not read a service request from that. Mention what you need, where and when — e.g. "MC for my wedding this Saturday in Takoradi".' };
        }
        return { ok: true, parsed: parsed };
    },
    'pushSubscribe': async (req, res, body) => {
        const sub = body && body.subscription;
        if (!sub || !sub.endpoint || !sub.keys) return { ok: false, error: 'Invalid subscription.' };
        let audience = null, refTo = '';
        const sess = await api.getSession(req);
        if (sess && sess.role === 'pro') { audience = 'pro'; refTo = sess.proId; }
        else if (body && body.bookingRef) {
            /* Customer subscriptions pin to the booking/application ref the
               Track page already verifies — customer notices are keyed by
               that same ref, so no account is needed. */
            const ref = String(body.bookingRef).trim();
            let b = null;
            try { b = await api.getBooking(ref); } catch (e) { /* unknown ref → treated as not found */ }
            const [appRows] = await db.q('SELECT id FROM applications WHERE id = ?', [ref]);
            if (!b && !(appRows && appRows.length)) return { ok: false, error: 'Booking not found — open the booking first.' };
            audience = 'customer';
            refTo = ref;
        } else {
            return { ok: false, error: 'Sign in as a professional or open a booking first.' };
        }
        const r = await push.subscribe(audience, refTo, sub.endpoint, sub.keys);
        if (r.ok) {
            await push.pushNotify(audience, refTo, 'welcome',
                audience === 'pro' ? 'Push notifications are ON — new requests, quotes and payments will reach you here even with SkillConnect closed.'
                                   : 'Push notifications are ON — quote and payment updates for this booking will reach you here even with SkillConnect closed.');
        }
        return r;
    },
    'pushUnsubscribe': async (req, res, body) => {
        if (!(body && body.endpoint)) return { ok: false, error: 'Missing endpoint.' };
        return push.unsubscribe(String(body.endpoint));
    },
    'pushTest': async (req, res, body) => {
        if (!(config.infra.ALLOW_SANDBOX_HOOKS === true)) return { ok: false, error: 'Sandbox hooks are disabled on this deployment.' };
        const sess = await api.getSession(req);
        let audience = 'customer', refTo = '';
        if (sess && sess.role === 'pro') { audience = 'pro'; refTo = sess.proId; }
        else if (body && body.bookingRef) {
            refTo = String(body.bookingRef).trim();
        }
        return push.pushTest(audience, refTo, body && body.text);
    },
    /* --- sync bridge for the front-end adapter (pages stay synchronous) --- */
    'snapshot': async (req, res, body) => {
        const snap = await api.snapshot();
        /* Go-live redaction of the client mirror:
           - EVERY caller: no password hashes (pages only need auth presence
             for the default-password prompts), no admin auth row.
           - Non-admin sessions: the applications table is dropped entirely
             (it carries applicants' names/phones/ID docs); the public
             tracker reads its single scoped record via /api/applicationTrack. */
        try {
            if (snap && Array.isArray(snap.pros)) {
                snap.pros = snap.pros.map(p => (p && p.auth ? Object.assign({}, p, { auth: { present: true, updatedAt: p.auth.updatedAt || 0 } }) : p));
            }
            if (snap && snap.adminAuth) delete snap.adminAuth;
            const sess = await api.getSession(req);
            if (!sess || sess.role !== 'admin') {
                if (snap && 'applications' in snap) snap.applications = [];
            }
        } catch (e) { /* never fail the snapshot for redaction */ }
        return { ok: true, db: snap, rev: api.serverRev() };
    },
    'reset': async (req, res, body) => {
        /* Go-live lock: dev-only tooling. Requires an explicit env opt-in —
           the sandbox_mode setting alone is NOT enough on a deployment
           serving real users (one curl could wipe the whole store). */
        if (config.infra.ALLOW_RESET !== true) return { ok: false, error: 'Reset is disabled on this deployment. Set SC_ALLOW_RESET=true only in development.' };
        const r = await api.resetAll();
        return r;
    },
    'health': async () => {
        const started = Date.now();
        try {
            await db.q('SELECT 1');
            api.idGateSweep().catch(e => console.error('[id-gate]', e && e.message || e));   /* lazy stage notifications */
            return { ok: true, status: 'healthy', db: 'up', dbLatencyMs: Date.now() - started, rev: api.serverRev(), uptimeSec: Math.round(process.uptime()) };
        } catch (e) {
            return { ok: false, status: 'degraded', db: 'down', error: e.code || e.message };
        }
    }
};

/* Batched mutations from the sync bridge. Each item names an exported SC
   function; args are positional. Stops on the first failure unless the
   item opts out with {fn, args, optional:true}. */
async function handleMutate(req, res, body) {
    const items = Array.isArray(body && body.mutations) ? body.mutations : [];
    if (!items.length) return { ok: false, error: 'mutations[] required' };
    const results = [];
    for (const item of items) {
        const name = item && item.fn;
        const args = Array.isArray(item && item.args) ? item.args : [];
        const fn = api[name];
        if (typeof fn !== 'function' || INTERNAL.has(name)) {
            results.push({ ok: false, error: 'Unknown function: ' + name });
            if (!item.optional) return { ok: false, error: 'Unknown function: ' + name, results, rev: api.serverRev() };
            continue;
        }
        try {
            const r = await fn(...args);
            results.push(r === undefined ? { ok: true } : r);
        } catch (e) {
            console.error('[mutate]', name, e && e.stack || e);
            results.push({ ok: false, error: 'Server error: ' + (e && e.message || String(e)) });
            if (!item.optional) return { ok: false, error: results[results.length - 1].error, results, rev: api.serverRev() };
        }
    }
    api.revBump();
    return { ok: true, results, rev: api.serverRev() };
}

/* ---------- static files ---------- */

function serveStatic(req, res, pathname) {
    const rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
    const file = path.normalize(path.join(ROOT, rel));
    if (!file.startsWith(ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }
    fs.stat(file, (err, st) => {
        if (err || !st.isFile()) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('Not found');
            return;
        }
        /* PWA correctness: the service worker MUST be re-fetched on every
           visit (stale SWs keep dead caches alive for days), while the
           manifest may cache briefly. Everything else is immutable-ish
           static content. */
        const ext = path.extname(file).toLowerCase();
        const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size };
        if (file.endsWith('sw.js')) headers['Cache-Control'] = 'no-cache, must-revalidate';
        else if (ext === '.webmanifest') headers['Cache-Control'] = 'max-age=3600';
        res.writeHead(200, headers);
        fs.createReadStream(file).pipe(res);
    });
}

/* Gateway webhooks: verify the HMAC against the RAW body bytes (never a
   re-serialized object), always ACK so retries stop, business outcome in
   the JSON body. No session — the signature IS the authentication. */
async function handleWebhook(req, res) {
    const chunks = [];
    let size = 0;
    await new Promise((resolve, reject) => {
        req.on('data', c => {
            size += c.length;
            if (size > 1024 * 1024) { reject(new Error('Webhook body too large.')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', resolve);
        req.on('error', reject);
    }).catch(() => {});
    const raw = Buffer.concat(chunks);
    const secret = config.infra.PAYSTACK_SECRET;
    const sig = req.headers['x-paystack-signature'] || '';
    if (!secret) return json(res, 401, { ok: false, error: 'Webhook verification not configured (SC_PAYSTACK_SECRET).' });
    if (!paystack.verifySignature(secret, raw, sig)) return json(res, 401, { ok: false, error: 'Invalid signature.' });
    let event;
    try { event = JSON.parse(raw.toString('utf8')); }
    catch (e) { return json(res, 200, { ok: false, error: 'Unparseable payload.' }); }
    if (!event || event.event !== 'charge.success' || !event.data || !event.data.reference) {
        return json(res, 200, { ok: true, ignored: true });   /* not a completion event */
    }
    try {
        const out = await payments.confirm(event.data.reference, 'webhook', event.data);
        return json(res, 200, out);
    } catch (e) {
        console.error('[webhook] confirm failed:', e && e.stack || e);
        return json(res, 200, { ok: false, error: 'Confirm failed — will retry.' });
    }
}

/* ---------- server ---------- */

const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const pathname = url.pathname;

    if (pathname.startsWith('/api/')) {
        const name = pathname.slice(5);
        try {
            /* dedicated routes first */
            if (name === 'payments/webhook') {
                if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'POST required.' });
                return await handleWebhook(req, res);
            }
            if (name === 'mutate') {
                if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'POST required.' });
                const body = await readBody(req);
                return json(res, 200, await handleMutate(req, res, body));
            }
            if (name === 'rev') return json(res, 200, { ok: true, rev: api.serverRev() });
            if (name === 'setupStatus' || name === 'setupRun' || name === 'setupSaveEnv') {
                const body = req.method === 'GET' ? Object.fromEntries(url.searchParams) : await readBody(req);
                return await handleSetup(name, req, res, body);
            }
            const special = ROUTES[name];
            if (special) {
                const body = req.method === 'GET' ? Object.fromEntries(url.searchParams) : await readBody(req);
                const out = await special(req, res, body);
                return json(res, 200, out);
            }
            const fn = api[name];
            if (typeof fn !== 'function' || INTERNAL.has(name)) return json(res, 404, { ok: false, error: 'Unknown API function: ' + name });
            if (name === 'applicationTrack') {
                const ref = url.searchParams.get('ref') || '';
                return json(res, 200, { ok: true, result: await api.applicationTrack(ref) });
            }
            if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'POST required.' });

            const body = await readBody(req);
            const args = Array.isArray(body) ? body : (Array.isArray(body.args) ? body.args : [body]);

            if (!rateLimitOk(name, clientIp(req))) return json(res, 429, { ok: false, error: 'Too many attempts — please wait a moment and try again.' });
            const authz = await authorizeFunction(name, args, req);
            if (!authz.ok) return json(res, 403, { ok: false, error: authz.error });

            const result = await fn(...args);
            api.revBump();
            return json(res, 200, { ok: true, result, rev: api.serverRev() });
        } catch (e) {
            console.error('[api]', name, e && e.stack || e);
            return json(res, 500, { ok: false, error: 'Server error: ' + (e && e.message || String(e)) });
        }
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
        res.writeHead(405); res.end('Method not allowed'); return;
    }
    serveStatic(req, res, pathname);
});

/* Boot: connect MySQL (fail loudly with an actionable message), then listen. */
(async () => {
    try {
        await db.init();
        /* A truly EMPTY database must still BOOT — the browser installer at
           /setup.html IS the way the schema arrives. So: run migrations,
           but on ER_NO_SUCH_TABLE drop into SETUP MODE (listen without
           sweepers) and point the user at the installer. Any other error
           is still fatal (real config problem). */
        let setupMode = false;
        try {
            await api.migrateAuthColumns();
            await api.migratePayoutTables();
            await api.migrateIdGateColumn();
            await api.migrateContactChannels();
            await api.migrateMatchEvents();
            await push.migratePushSubscriptions();
            await msgChannels.migrateChannelOutbound();
            await api.migrateNotifyPrefs();
            await api.ensureSeeded();
            api.startNotificationCapSweeper();
            await api.idGateSweep();   /* fire due stage notifications at boot; re-checked on /health */
            api.startIdGateSweeper();  /* hourly so long-running servers stay current */
        } catch (e) {
            const code = e && (e.code || e.errno || '');
            if (code === 'ER_NO_SUCH_TABLE' || /doesn't exist/i.test(e && e.message || '')) {
                setupMode = true;
                console.log('[sc-api] Database schema is NOT installed yet — starting in SETUP MODE.');
                console.log('[sc-api] Open /setup.html in a browser and press "Run Install / Upgrade".');
            } else { throw e; }
        }
        console.log('[sc-api] MySQL connected —', config.infra.DB_HOST + ':' + config.infra.DB_PORT + '/' + config.infra.DB_NAME);
        server.listen(PORT, () => console.log('[sc-api] listening on http://localhost:' + PORT + (setupMode ? '  (SETUP MODE — API calls will fail until installed)' : '')));
    } catch (e) {
        console.error('[sc-api] MySQL connection failed:', e.code || '', e.message);
        console.error('[sc-api] Check SC_DB_HOST/PORT/USER/PASS/NAME env vars and that db/schema.sql has been imported.');
        process.exit(1);
    }
})();
