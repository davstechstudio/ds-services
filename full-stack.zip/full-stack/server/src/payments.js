/* ============================================================
   payments.js — the gateway seam (docs/backend-migration.md §Payments)

   WHAT THIS MODULE IS
   A customer's payment no longer "just happens" client-side: every
   real-money attempt becomes a payment_intents row, money is collected
   by the configured gateway, and ONLY the server-side confirmation
   runs the exact escrow / reg-fee state transitions that the sandbox
   functions always ran (guards included — bookings must still be
   'booked' and unfunded; reg fee must still be unpaid).

   NO LOGIC CHANGES principle: fundEscrowInTx / markRegFeePaidInTx are
   the verbatim sandbox transitions (extracted from payIntoEscrow /
   payRegFee, which now delegate to them). This module only decides
   WHEN they run — at gateway confirmation instead of at button press.

   IDEMPOTENCY: payment_intents.uq_intent_ref (gateway, gateway_ref) is
   UNIQUE. A webhook that arrives twice (or arrives after a pull-verify)
   updates the same row and the confirm transaction is a no-op the
   second time — double funding is impossible.

   CUSTODY: funds land on the platform's gateway balance and settle on
   release (payEscrowOut) — the split-subaccount model can be layered
   onto the same schema later without changing this file's contract.

   MODES (decided per request, never hardcoded):
   - settings.payment_gateway = '' (default) → simulated adapter:
     initiate creates the intent, confirm() flips it success instantly
     (parity with today's sandbox pay flows).
   - settings.payment_gateway = 'paystack' + env SC_PAYSTACK_SECRET →
     real Paystack: initialize returns a hosted checkout URL; money is
     confirmed via the signed webhook (or pull-verify fallback).
   ============================================================ */

'use strict';

const config = require('./config');
const db = require('./db');
const api = require('./sc-api');          /* the InTx transitions + refreshBooking */
const paystack = require('./paystack');
const mtnMomo = require('./mtn-momo');

/* Which gateway is live ('' = simulated sandbox payments) — the check
   itself lives in config.js (shared with sc-api's sandbox-path gating). */
const activeGateway = () => config.activeGateway();

function adapterFor(gateway) {
    if (gateway === 'paystack') return paystack;
    if (gateway === 'mtn_momo') return mtnMomo;
    return null;   /* simulated */
}

function simAdapter() {
    return {
        initialize: async () => ({ ok: true, simulated: true }),
        confirm: async () => ({ ok: true })
    };
}

/* ---------- reference + id helpers ---------- */

/* 13 chars total (ESC- + 9). Longest provider ref we mint is paystack's,
   and escrow.txn_ref is VARCHAR(24) — reassignment appends '/R<n>' on top
   of this base ref, so we stay well under the cap. */
function intentRef() {
    return 'PMT-' + Date.now().toString(36).toUpperCase().slice(-6)
         + '-' + Math.random().toString(36).toUpperCase().slice(2, 6);
}

function decAmount(n) { return Math.round(Number(n) * 100) / 100; }

/* ---------- initiate ----------

   Creates a payment_intents row (status 'initiated') and, on the real
   gateway, starts a checkout. Escrow amounts come from the booking row
   (never from the client); reg-fee amounts from getRegFee().

   Returns { ok, intentRef, amount, checkoutUrl?, simulated? } */
async function initiate(purpose, refId, method) {
    const gateway = await activeGateway();
    const adapter = adapterFor(gateway) || simAdapter();
    const now = Date.now();

    /* Resolve the amount + validate the target BEFORE touching money. */
    let amount, meta, email = 'customer@skillconnectgh.com';
    if (purpose === 'escrow') {
        const [rows] = await db.q('SELECT id, amount, status, customer_name, customer_phone FROM bookings WHERE id = ?', [refId]);
        const b = rows[0];
        if (!b) return { ok: false, error: 'Booking not found.' };
        if (b.status !== 'booked' || !Number(b.amount)) return { ok: false, error: 'Booking is not awaiting payment.' };
        const [esc] = await db.q('SELECT released FROM escrow WHERE booking_id = ?', [refId]);
        if (esc.length && !esc[0].released) return { ok: false, error: 'This booking is already funded — escrow is holding your payment.' };
        amount = decAmount(b.amount);
        meta = { purpose, bookingId: b.id, appRef: null, customerName: b.customer_name, customerPhone: b.customer_phone };
        email = 'cust.' + String(b.customer_phone || '').replace(/\D/g, '').slice(-9) + '@skillconnectgh.com';
    } else if (purpose === 'reg_fee') {
        const fee = await api.getRegFee();
        const [arows] = await db.q('SELECT id, name, email, phone FROM applications WHERE id = ?', [refId]);
        const [prows] = await db.q('SELECT id, name FROM pros WHERE app_id = ? OR id = ?', [refId, refId]);
        const target = prows[0] || arows[0];
        if (!target) return { ok: false, error: 'Application not found.' };
        const [paid] = await db.q('SELECT reg_fee_paid FROM ' + (prows[0] ? 'pros' : 'applications') + ' WHERE id = ?', [target.id]);
        if (paid.length && paid[0].reg_fee_paid) return { ok: false, error: 'Registration fee already paid.' };
        amount = decAmount(fee);
        meta = { purpose, bookingId: null, appRef: refId, customerName: prows[0] ? prows[0].name : arows[0] ? arows[0].name : '', customerPhone: arows[0] ? (arows[0].phone || '') : '' };
        if (arows[0] && arows[0].email) email = arows[0].email;
    } else {
        return { ok: false, error: 'Unknown payment purpose.' };
    }

    const ref = intentRef();
    const secret = config.infra.PAYSTACK_SECRET;
    const cur = await config.get('payment_currency', 'GHS');
    const livePaystack = adapter === paystack && !!secret;
    const liveMtn = adapter === mtnMomo && mtnMomo.configured();

    /* Real gateways: start the checkout/collection first — if it fails, no
       intent row is left dangling in 'initiated' (the client simply retries). */
    let checkoutUrl = null, extra = {}, status = 'initiated', initAudit = {};
    if (livePaystack) {
        const ch = await paystack.initialize({
            secret,
            reference: ref,
            amountMinor: Math.round(amount * 100),   /* pesewas */
            email,
            currency: cur,
            channel: method === 'paystack' || method === 'card' ? 'card' : 'momo',
            meta
        });
        if (!ch.ok) return { ok: false, error: ch.error };
        checkoutUrl = ch.authorizationUrl;
        extra.accessCode = ch.accessCode;
    } else if (liveMtn) {
        /* Direct MoMo push: the customer approves a prompt on their handset.
           The intent stays PENDING until pull-verify sees SUCCESSFUL — MTN
           has no hosted page to redirect to. */
        const phone = meta.customerPhone;
        if (!phone) return { ok: false, error: 'No payer phone number on file for this payment.' };
        const ch = await mtnMomo.initialize({
            reference: ref,
            amountMinor: Math.round(amount * 100),
            currency: cur,
            phone,
            meta: { payerMessage: 'SkillConnect payment ' + (meta.bookingId || meta.appRef || ''), payeeNote: 'SkillConnect' }
        });
        if (!ch.ok) return { ok: false, error: ch.error };
        status = 'pending';
        extra.pending = true;
        initAudit = { mtnReferenceId: ch.referenceId, targetEnv: config.infra.MTN_TARGET_ENV };
    }

    await db.q(
        'INSERT INTO payment_intents (purpose, booking_id, app_ref, gateway, gateway_ref, amount, status, raw, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [purpose, meta.bookingId, meta.appRef, gateway || 'simulated', ref, amount, status,
         JSON.stringify(Object.assign({ initiatedBy: 'api', method: method || 'momo', customer: meta.customerName }, initAudit)), now, now]);

    return Object.assign({
        ok: true,
        intentRef: ref,
        purpose,
        amount,
        gateway: gateway || 'simulated',
        simulated: !(livePaystack || liveMtn),
        checkoutUrl
    }, extra);
}

/* ---------- confirm (the money moment) ----------

   Called by the signed webhook, the pull-verify fallback, or the
   simulated adapter. Runs inside ONE transaction:
     1. re-read the intent FOR UPDATE,
     2. if already success → no-op {ok, alreadyDone:true} (idempotency),
     3. run THE transition (same guards, same ledger, same notifications),
     4. on success persist intent status='success'; on guard failure mark
        the intent 'failed' (auditable) without throwing at the gateway.

   `how` is audit sugar ('webhook' | 'verify' | 'simulated'). */
async function confirm(intentRef, how, payload) {
    return db.tx(async (conn) => {
        const [irows] = await conn.query('SELECT * FROM payment_intents WHERE gateway_ref = ? FOR UPDATE', [intentRef]);
        const intent = irows[0];
        if (!intent) return { ok: false, error: 'Unknown payment reference.' };

        if (intent.status === 'success') {
            return { ok: true, alreadyDone: true, intentRef: intent.gateway_ref, purpose: intent.purpose };
        }

        const result = intent.purpose === 'escrow'
            ? await api.fundEscrowInTx(conn, intent.booking_id, intent.gateway, intent.gateway_ref)
            : await api.markRegFeePaidInTx(conn, intent.app_ref, intent.gateway, intent.gateway_ref);

        if (result.ok) {
            /* MERGE into the existing audit (initiation data such as MTN's
               referenceId must survive confirmation — later verifies need it). */
            const audit = Object.assign({}, pj(intent.raw), {
                confirmedAt: Date.now(), how: how || 'webhook', payload: payload || null, txnId: result.txnId || null
            });
            await conn.query(
                'UPDATE payment_intents SET status = ?, raw = ?, updated_at = ? WHERE id = ?',
                ['success', JSON.stringify(audit), Date.now(), intent.id]);
            return Object.assign({ ok: true, intentRef: intent.gateway_ref, purpose: intent.purpose, how: how || 'webhook' }, result);
        }

        /* The business guard refused (booking no longer awaiting payment,
           fee already paid by another path…) — keep the audit trail. */
        const auditFail = Object.assign({}, pj(intent.raw), { failedAt: Date.now(), how: how || 'webhook', error: result.error });
        await conn.query(
            'UPDATE payment_intents SET status = ?, raw = ?, updated_at = ? WHERE id = ?',
            ['failed', JSON.stringify(auditFail), Date.now(), intent.id]);
        return Object.assign({ ok: false, intentRef: intent.gateway_ref }, result);
    });
}

/* Pull-verify fallback: ask the gateway directly (networks that can't
   reach webhooks, or an ops "retry" button). Simulated gateways confirm
   on the spot; MTN stays "pending" until the customer approves. */
function pj(v) { try { return typeof v === 'string' ? JSON.parse(v) : (v || {}); } catch (e) { return {}; } }

async function verifyAndConfirm(intentRef) {
    const gateway = await activeGateway();
    const secret = config.infra.PAYSTACK_SECRET;
    if (gateway === 'paystack' && secret) {
        const v = await paystack.verify(secret, intentRef);
        if (!v.ok) return { ok: false, error: v.error };
        if (v.status !== 'success') {
            const [pr] = await db.q('SELECT raw FROM payment_intents WHERE gateway_ref = ?', [intentRef]);
            const audit = Object.assign({}, pj(pr.length ? pr[0].raw : null), { failedAt: Date.now(), how: 'verify', gatewayStatus: v.status });
            await db.q('UPDATE payment_intents SET status = ?, raw = ?, updated_at = ? WHERE gateway_ref = ?',
                ['failed', JSON.stringify(audit), Date.now(), intentRef]);
            return { ok: false, error: 'Gateway reports status: ' + v.status };
        }
        return confirm(intentRef, 'verify', v.raw);
    }
    if (gateway === 'mtn_momo' && mtnMomo.configured()) {
        const [rows] = await db.q('SELECT raw, status FROM payment_intents WHERE gateway_ref = ?', [intentRef]);
        if (!rows.length) return { ok: false, error: 'Unknown payment reference.' };
        const mtnRef = pj(rows[0].raw).mtnReferenceId;
        if (!mtnRef) return { ok: false, error: 'Intent has no MTN reference — was it initiated through MTN MoMo?' };
        const v = await mtnMomo.verify(null, mtnRef);
        if (!v.ok) return { ok: false, error: v.error };
        if (v.status === 'pending') {
            return { ok: false, pending: true, intentRef, error: 'Payment not approved yet — the customer must approve the MoMo prompt, then verify again.' };
        }
        if (v.status !== 'success') {
            const audit = Object.assign({}, pj(rows[0].raw), { failedAt: Date.now(), how: 'verify', mtnStatus: v.status, raw: v.raw });
            await db.q('UPDATE payment_intents SET status = ?, raw = ?, updated_at = ? WHERE gateway_ref = ?',
                ['failed', JSON.stringify(audit), Date.now(), intentRef]);
            return { ok: false, error: 'Gateway reports status: ' + v.status };
        }
        return confirm(intentRef, 'verify', v.raw);
    }
    return confirm(intentRef, 'simulated', null);
}

/* ---------- admin gateway controls (settings-driven, zero hardcode) ---------- */

const KNOWN_GATEWAYS = ['', 'paystack', 'mtn_momo'];

function readiness(g) {
    if (g === 'paystack') {
        return config.infra.PAYSTACK_SECRET
            ? { configured: true, needs: [] }
            : { configured: false, needs: ['SC_PAYSTACK_SECRET in server/.env'] };
    }
    if (g === 'mtn_momo') {
        return mtnMomo.configured()
            ? { configured: true, needs: [] }
            : { configured: false, needs: ['SC_MTN_SUBSCRIPTION_KEY / SC_MTN_API_USER / SC_MTN_API_KEY in server/.env'] };
    }
    return { configured: true, needs: [] };   /* simulated always ready */
}

/* Admin toggle: which gateway collects money. Credentials are checked
   (never stored here) so a gateway can't be activated without its keys. */
async function setGateway(name) {
    const g = String(name || '').toLowerCase();
    if (!KNOWN_GATEWAYS.includes(g)) return { ok: false, error: 'Unknown gateway. Use "" (simulated), "paystack" or "mtn_momo".' };
    const r = readiness(g);
    if (g && !r.configured) return { ok: false, error: 'Gateway not configured: ' + r.needs.join('; ') };
    await db.q('UPDATE settings SET setting_value = ?, updated_at = ? WHERE setting_key = ?',
        [JSON.stringify(g), Date.now(), 'payment_gateway']);
    config.invalidate();
    return { ok: true, gateway: g };
}

async function gatewayInfo() {
    const g = await activeGateway();
    const r = readiness(g);
    const [rows] = await db.q('SELECT status, COUNT(*) AS c FROM payment_intents GROUP BY status');
    const byStatus = {}; let total = 0;
    for (const row of rows) { byStatus[row.status] = Number(row.c); total += Number(row.c); }
    return { ok: true, gateway: g, configured: r.configured, needs: r.needs, intents: { total, byStatus } };
}

module.exports = { activeGateway, initiate, confirm, verifyAndConfirm, setGateway, gatewayInfo };
