/* ============================================================
   match-log.js — learning-to-rank data capture (LTR-1)
   ------------------------------------------------------------
   Logs every automated matching decision as a training row so a
   learning-to-rank model can REPLACE the near-first heuristic
   later — with zero behaviour change today.

   Contract the future model must honour (and that this log makes
   learnable):
     match(pool, bookingContext) -> ranked candidates
       • FEATURES (computable at match time, per candidate):
         km, tier, response rank, rating, rating count, bookings,
         price, emergency flag, date-free flag, in-city flag.
       • EXPOSURE: `shown` marks the invited (top-slice) pros with
         their position — the log keeps the FULL candidate pool, so
         the model sees both what was offered AND what was skipped.
       • OUTCOMES (joined later per event row): quotes that arrived,
         which pro was accepted, escrow paid/completed, review
         rating, cancellation — the reward signal.
   Nothing here changes matching; matchNearFirst stays the engine.
   Logging is strictly best-effort: a failure to log must never
   fail the customer's booking (mirrors the notify()/push posture).
   ============================================================ */

'use strict';

const db = require('./db');

/* Bump when the feature extraction or the engine itself changes, so
   training data stays attributable to a behaviour generation. */
const ENGINE_VERSION = 'nearfirst-v1';

/* Per-candidate feature extraction from a proOut() shape + resolved
   distance. This is the single definition of "match-time features"
   the future model trains on — keep it pure and cheap. */
function candidateFeatures(p, km, eventDate, bookingLocation) {
    const tier = km === null ? 'unknown' : (km <= 35 ? 'near' : (km <= 120 ? 'mid' : 'far'));
    const respRank = { '1hr': 0, '3hr': 1, 'sameday': 2, '24hr': 3 }[p.response] ?? 2;
    return {
        proId: p.id,
        km,
        tier,
        respRank,
        rating: Number(p.rating) || 0,
        ratingCount: p.ratingCount || 0,
        bookings: p.bookings || 0,
        price: Number(p.price) || 0,
        emergency: !!p.emergency,
        dateFree: !eventDate || !(p.blocked || []).includes(eventDate),
        inCity: !!bookingLocation && String(p.city || '').toLowerCase() === String(bookingLocation).toLowerCase(),
        city: p.city || ''
    };
}

/* Insert one match event (called INSIDE the caller's transaction).
   ctx: { bookingId, cat, location, baseKm, urgency, budget, date,
          candidates: proOut[], shown: [{proId, position}] }
   Non-fatal by design: callers wrap us, so any throw here only
   surfaces if the CALLER forgot — belt and braces, catch inside. */
async function recordMatchEventInTx(conn, ctx) {
    try {
        await conn.query(
            `INSERT INTO match_events
                (booking_id, cat, location, base_km, urgency, budget, event_date,
                 engine, candidates, shown_ids, outcome, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [ctx.bookingId, ctx.cat || '', ctx.location || '',
             ctx.baseKm === null || ctx.baseKm === undefined ? null : Number(ctx.baseKm),
             ctx.urgency || 'planned',
             ctx.budget === '' || ctx.budget === null || ctx.budget === undefined ? null : Number(ctx.budget),
             ctx.date || null,
             ENGINE_VERSION,
             JSON.stringify(ctx.candidates || []),
             JSON.stringify(ctx.shown || []),
             JSON.stringify({}),
             Date.now()]);
    } catch (e) {
        /* A training-row write must never break a customer booking —
           log and move on (same posture as push in notify()). */
        console.error('[match-log] event insert failed (non-fatal):', e && e.message || e);
    }
}

/* Update the outcome block of the LATEST event for a booking. Usable
   inside the caller's transaction (sees its own uncommitted event rows —
   sandbox quotes fire right after the event insert in the same tx) or
   standalone. `patchOrFn` is a plain object merged into the outcome, or
   a function (current) => next for read-modify-write like counters.
   NEVER throws: outcome capture must not be able to fail business flow. */
async function updateOutcomeInTx(conn, bookingId, patchOrFn) {
    try {
        const [rows] = await conn.query(
            'SELECT id, outcome FROM match_events WHERE booking_id = ? ORDER BY id DESC LIMIT 1',
            [bookingId]);
        if (!rows.length) return false;   /* direct proId request / manual assign: no event */
        let outcome = {};
        const raw = rows[0].outcome;
        if (raw) { try { outcome = typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (e) { outcome = {}; } }
        const next = typeof patchOrFn === 'function' ? (patchOrFn(outcome) || outcome) : Object.assign(outcome, patchOrFn);
        next.updatedAt = Date.now();
        await conn.query('UPDATE match_events SET outcome = ? WHERE id = ?', [JSON.stringify(next), rows[0].id]);
        return true;
    } catch (e) {
        console.error('[match-log] outcome update failed (non-fatal):', e && e.message || e);
        return false;
    }
}

/* Standalone variant on its own connection (outside business txs). */
async function updateOutcome(bookingId, patch) {
    try { return await db.tx(async (conn) => updateOutcomeInTx(conn, bookingId, patch)); }
    catch (e) { return false; }
}

/* Admin export: JSONL — one self-contained training row per line. */
async function exportEvents() {
    const [rows] = await db.q('SELECT * FROM match_events ORDER BY id ASC');
    return rows.map(r => {
        let candidates = [], shown = [], outcome = {};
        try { candidates = typeof r.candidates === 'string' ? JSON.parse(r.candidates) : (r.candidates || []); } catch (e) {}
        try { shown = typeof r.shown_ids === 'string' ? JSON.parse(r.shown_ids) : (r.shown_ids || []); } catch (e) {}
        try { outcome = typeof r.outcome === 'string' ? JSON.parse(r.outcome) : (r.outcome || {}); } catch (e) {}
        return {
            bookingId: r.booking_id,
            cat: r.cat,
            location: r.location,
            baseKm: r.base_km === null ? null : Number(r.base_km),
            urgency: r.urgency,
            budget: r.budget === null ? null : Number(r.budget),
            date: r.event_date || '',
            engine: r.engine,
            candidates,
            shown,
            outcome,
            createdAt: Number(r.created_at)
        };
    });
}

module.exports = { ENGINE_VERSION, candidateFeatures, recordMatchEventInTx, updateOutcomeInTx, updateOutcome, exportEvents };
