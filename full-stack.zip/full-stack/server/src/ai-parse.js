/* ============================================================
   ai-parse.js — natural-language booking parser (the "AI booking
   assistant" brain). Zero dependencies, deterministic first.

   Turns free text like
     "Need an MC for my wedding this Saturday in Takoradi,
      about 200 guests, budget around 2500 — Ama, 024 421 1595"
   into the exact shape the existing matching engine consumes:
     { name, phone, cat, date, location, budget, urgency, details }
   plus parser metadata (confidence, per-field evidence, missing list)
   so the UI can show a transparent preview before creating anything.

   Design rules:
   - Deterministic rules ALWAYS run (dates, phones, budgets, categories,
     cities — Ghana-aware English/Twi phrases). No network needed.
   - If SC_AI_KEY is configured, the text is ALSO sent to an LLM for
     interpretation and the two readings are merged (LLM fills gaps,
     rules win on objective facts like phone numbers and dates).
   - Never creates a booking: parsing and booking are separate steps,
     and the customer confirms the parsed preview.
   ============================================================ */

'use strict';

const https = require('https');

/* ---------- category detection ---------- */
const CAT_PATTERNS = [
    ['mc', ['mc', 'emcee', 'master of ceremony', 'master of ceremonies', 'mc-ing', 'host']],
    ['photographer', ['photograph', 'photo', 'pictures', 'pics', 'camera man', 'cameraman', 'shoot']],
    ['videographer', ['video', 'cinemat', 'filming', 'film the', 'coverage', 'highlight reel', 'drone']],
    ['dj', ['dj', 'disc jockey', 'sound system', 'sound & lighting', 'music system', 'speaker and light', 'deejay']],
    ['caterer', ['cater', 'food', 'chop', 'menu', 'small chops', 'cooking', 'chef', 'drinks service']],
    ['decorator', ['decorat', 'decoration', 'canopy', 'flowers', 'floral', 'stage design', 'theme design', 'event planner', 'planning']],
    ['artist', ['artist', 'band', 'singer', 'performer', 'live music', 'musicians', 'gospel artist', 'afrobeats', 'highlife']],
    ['handy', ['handy', 'electrician', 'plumber', 'plumbing', 'ac ', 'air condition', 'carpenter', 'repair', 'installation', 'fix', 'wiring', 'technician', 'fitter']]
];

/* ---------- date parsing ---------- */
const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

function pad2(n) { return String(n).padStart(2, '0'); }
function toISO(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
function todayISO() {
    const d = new Date();
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
}

function parseDate(text) {
    const t = ' ' + String(text).toLowerCase() + ' ';
    const today = new Date();
    today.setHours(12, 0, 0, 0);

    // ISO / numeric dates: 2026-10-12, 12/10/2026, 12.10.26 (Ghana style = D/M/Y)
    const iso = t.match(/\b(20\d{2})-(\d{1,2})-(\d{1,2})\b/);
    if (iso) return { date: iso[1] + '-' + pad2(+iso[2]) + '-' + pad2(+iso[3]), evidence: iso[0].trim() };
    const dmy = t.match(/\b(\d{1,2})[\/.](\d{1,2})(?:[\/.](\d{2,4}))?\b/);
    if (dmy) {
        const day = +dmy[1], mon = +dmy[2];
        if (day >= 1 && day <= 31 && mon >= 1 && mon <= 12) {
            let year = dmy[3] ? (+dmy[3] < 100 ? 2000 + +dmy[3] : +dmy[3]) : today.getFullYear();
            let cand = new Date(year, mon - 1, day, 12);
            if (!dmy[3] && cand < today) cand.setFullYear(year + 1);   // no year given: roll forward
            return { date: toISO(cand), evidence: dmy[0].trim() };
        }
    }

    // "12th October", "October 12", "October 2026"
    for (let i = 0; i < 12; i++) {
        const m = MONTHS[i];
        const re1 = new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?' + m + '\\b');
        const hit1 = t.match(re1);
        if (hit1) {
            const yr = t.match(new RegExp(m + '\\s*,?\\s*(20\\d{2})')) || t.match(new RegExp('\\b(20\\d{2})\\b'));
            const cand = new Date(yr ? +yr[1] : today.getFullYear(), i, +hit1[1], 12);
            if (!yr && cand < today) cand.setFullYear(cand.getFullYear() + 1);
            return { date: toISO(cand), evidence: hit1[0].trim() };
        }
        const re2 = new RegExp('\\b' + m + '\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b');
        const hit2 = t.match(re2);
        if (hit2) {
            const yr = t.match(new RegExp('\\b(20\\d{2})\\b'));
            const cand = new Date(yr ? +yr[1] : today.getFullYear(), i, +hit2[1], 12);
            if (!yr && cand < today) cand.setFullYear(cand.getFullYear() + 1);
            return { date: toISO(cand), evidence: hit2[0].trim() };
        }
    }

    // Relative days
    if (/\btoday\b|\bthis afternoon\b|\bthis evening\b|\bnow now\b|\bsharp sharp\b/.test(t)) return { date: toISO(today), evidence: 'today', urgency: 'urgent' };
    if (/\btomorrow\b|\btmrw\b/.test(t)) { const d = new Date(today); d.setDate(d.getDate() + 1); return { date: toISO(d), evidence: 'tomorrow' }; }
    if (/\bnext week\b/.test(t)) { const d = new Date(today); d.setDate(d.getDate() + 7); return { date: toISO(d), evidence: 'next week' }; }
    if (/\bthis weekend\b|\bweekend\b/.test(t)) {
        const d = new Date(today);
        const add = (6 - d.getDay() + 7) % 7 || 7;   // coming Saturday (not today)
        d.setDate(d.getDate() + add);
        return { date: toISO(d), evidence: 'this weekend' };
    }

    // Weekday names: "this Saturday", "on Friday"
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    for (let i = 0; i < 7; i++) {
        if (new RegExp('\\b(?:this |next |on )?' + days[i] + '\\b').test(t)) {
            const d = new Date(today);
            const add = (i - d.getDay() + 7) % 7 || 7;
            d.setDate(d.getDate() + add);
            const nextW = new RegExp('\\bnext ' + days[i] + '\\b').test(t);
            if (nextW) d.setDate(d.getDate() + 7);
            return { date: toISO(d), evidence: days[i] };
        }
    }
    return null;
}

/* ---------- urgency ---------- */
function parseUrgency(text, dateHint) {
    const t = String(text).toLowerCase();
    if (dateHint === 'urgent') return { urgency: 'urgent', evidence: 'today' };
    if (/\bemergency\b|\burgent\b|\basp\b|\bas soon as possible\b|\bright now\b|\bthis morning\b|\bwater ?is ?everywhere\b|\bno light\b/.test(t)) return { urgency: 'urgent', evidence: RegExp.lastMatch || 'urgent' };
    if (/\b(?:within|in) (?:the next )?48 ?hours\b|\bday after tomorrow\b|\bthis week\b/.test(t)) return { urgency: 'soon', evidence: 'this week / 48 hours' };
    return { urgency: 'planned', evidence: null };
}

/* ---------- budget ---------- */
function parseBudget(text) {
    const t = String(text).toLowerCase().replace(/,/g, '');
    /* 'budget X' is the strongest cue; vague hedges ('around/about') only
       count when directly attached to a currency amount — otherwise they
       swallow guest counts ('about 200 guests'). */
    let m = t.match(/budget\s*(?:is|:)?\s*(?:of|around|about|roughly|up ?to)?\s*(?:ghs|ghc|cedis?|\u20B5)?\s*(\d{2,7})(?:\.\d{1,2})?/);
    if (!m) m = t.match(/(?:around|about|roughly|up ?to|maximum|max of|not more than|within)\s*(\d{2,7})(?:\.\d{1,2})?\s*(?:ghs|ghc|cedis?|\u20B5)?(?=\s|$|[,.;!?])/);
    if (!m) m = t.match(/(?:ghs|ghc|cedis?|\u20B5)\s*(\d{2,7})(?:\.\d{1,2})?/);
    if (!m) m = t.match(/(\d{2,7})(?:\.\d{1,2})?\s*(?:ghs|ghc|cedis?|\u20B5)/);
    if (!m) m = t.match(/\u20B5\s*(\d{2,7})/);
    if (!m) return null;
    const n = Number(m[1]);
    if (!isFinite(n) || n < 20 || n > 1000000) return null;   // sane bounds
    return { budget: Math.round(n), evidence: m[0].trim() };
}

/* ---------- phone ---------- */
function parsePhone(text) {
    /* Spaced local format (024 421 1595) is the convention — squash ALL
       whitespace and separators, then match the known Ghana shapes. */
    const flat = String(text).replace(/[.()\-–]/g, '').replace(/\s+/g, '');
    const m = flat.match(/(?:^|\D)(\+?233\d{9}|0\d{9})(?:\D|$)/) || flat.match(/(?:^|\D)(\d{10})(?:\D|$)/);
    if (!m) return null;
    let raw = m[1];
    if (raw.startsWith('+')) raw = raw.slice(1);
    if (raw.startsWith('233')) raw = '0' + raw.slice(3);
    if (!/^0\d{9}$/.test(raw)) return null;
    const pretty = raw.slice(0, 3) + ' ' + raw.slice(3, 6) + ' ' + raw.slice(6);
    return { phone: raw, evidence: pretty };
}

/* ---------- location (Ghana-aware) ---------- */
const PLACES = [
    'accra', 'osu', 'labone', 'cantonments', 'east legon', 'airport residential', 'madina', 'adenta',
    'teshie', 'nungua', 'sakumono', 'spintex', 'dansoman', 'achimota', 'tesano', 'ablekuma', 'weija',
    'gbawe', 'haatso', 'dome', 'tema', 'ashaiman', 'kasoa', 'amosa', 'amasaman', 'nsawam', 'ada', 'legon',
    'cape coast', 'elmina', 'winneba', 'swedru', 'mankessim', 'assin fosu', 'dunkwa',
    'takoradi', 'sekondi', 'tarkwa', 'axim', 'bibiani',
    'kumasi', 'obuasi', 'ejisu', 'konongo', 'mampong', 'bekwai', 'agogo',
    'koforidua', 'nkawkaw', 'akosombo', 'suhum', 'begoro', 'kyebi', 'oda',
    'ho', 'keta', 'aflao', 'hohoe', 'kpando', 'dambai', 'nkwanta', 'worawora',
    'tamale', 'yendi', 'savelugu', 'walewale', 'gushegu', 'damongo', 'salaga', 'bole',
    'bolgatanga', 'navrongo', 'bawku', 'paga', 'zuarungu', 'wa', 'tumu', 'lawra',
    'sunyani', 'berekum', 'dormaa', 'wenchi', 'techiman', 'kintampo', 'atebubu',
    'goaso', 'bechem', 'hwidiem'
];
function parseLocation(text) {
    const t = ' ' + String(text).toLowerCase() + ' ';
    let best = null, bestAt = -1;
    for (const p of PLACES) {
        const at = t.indexOf(' ' + p);
        if (at !== -1 && (best === null || p.length > best.length || (p.length === best.length && at < bestAt))) {
            // prefer the LONGEST place name; ties -> earliest
            if (best === null || p.length > best.length) { best = p; bestAt = at; }
        }
    }
    if (!best) return null;
    const pretty = best.replace(/\b\w/g, c => c.toUpperCase());
    return { location: pretty, evidence: best };
}

/* ---------- guest count & event type (goes into details) ---------- */
function parseDetails(text) {
    const t = String(text).toLowerCase();
    const out = [];
    const guests = t.match(/(\d{2,4})\s*(?:guests?|people|pax|persons?|heads?)/);
    if (guests) out.push('~' + guests[1] + ' guests');
    const events = [['wedding', 'wedding'], ['funeral', 'funeral'], ['birthday', 'birthday'], ['naming ceremony', 'naming ceremony'], ['outdooring', 'outdooring'], ['church event', 'church event'], ['conference', 'conference'], ['corporate event', 'corporate event'], ['party', 'party'], ['engagement', 'engagement']];
    for (const [k, label] of events) if (t.includes(k)) { out.push(label); break; }
    return out;
}

/* ---------- name ---------- */
function parseName(text) {
    const t = String(text);
    const m = t.match(/\b(?:i am|i'm|my name is|this is|name:?)\s+([A-Za-z]+(?:\s+[A-Za-z]+){0,2})/i);
    if (m) {
        const cleaned = m[1]
            .replace(/\b(?:and|but|need|want|looking|call|reach|whatsapp|mobile|number|email)\b.*$/i, '')
            .trim();
        if (cleaned && cleaned.length >= 2 && cleaned.split(/\s+/).length <= 3) {
            const pretty = cleaned.replace(/\b\w/g, c => c.toUpperCase());
            return { name: pretty, evidence: pretty };
        }
    }
    /* Fallback: a bare capitalised name right before a phone number
       ("...call Yaa 055 123 4567"). Ghanaian messages often end this way. */
    const fb = t.match(/\b(?:call|contact|ask(?:\s+for)?|text)\s+([A-Z][a-z]{1,15})(?:\s+[A-Z][a-z]{1,15})?\s*(?:[,(]|\+?233|0\d{9}|$)/) ||
               t.match(/\b([A-Z][a-z]{1,15})\s+(?:0\d{9}|\+?233\d{9}|0\d{2}\s?\d{3}\s?\d{4})/);
    if (fb) {
        const nm = fb[1].trim();
        if (nm.length >= 2 && !/^(need|want|find|book|hire|please|hello|hi)$/i.test(nm)) {
            return { name: nm, evidence: nm };
        }
    }
    return null;
}

/* ---------- main deterministic parse ---------- */
function ruleParse(text) {
    const t = String(text || '');
    const lower = t.toLowerCase();
    const missing = [];

    // category: earliest + most specific match wins
    let cat = null, catAt = Infinity;
    for (const [c, words] of CAT_PATTERNS) {
        for (const w of words) {
            const at = lower.indexOf(w);
            if (at !== -1 && at < catAt) { cat = c; catAt = at; }
        }
    }
    if (!cat) missing.push('cat');

    const d = parseDate(t);
    const urgency = parseUrgency(t, d && d.urgency);
    const budget = parseBudget(t);
    const phone = parsePhone(t);
    const location = parseLocation(t);
    const name = parseName(t);
    const detailBits = parseDetails(t);
    if (!d) missing.push('date');
    if (!budget) missing.push('budget');
    if (!phone) missing.push('phone');
    if (!location) missing.push('location');
    if (!name) missing.push('name');

    const detailsParts = [];
    if (detailBits.length) detailsParts.push(detailBits.join(' · '));
    detailsParts.push('From: "' + t.trim().slice(0, 180) + '"');

    // confidence: share of the 7 fields the rules found
    const found = 7 - missing.length;
    const confidence = Math.round((found / 7) * 100) / 100;

    return {
        name: name ? name.name : '',
        phone: phone ? phone.phone : '',
        cat: cat || '',
        date: d ? d.date : '',
        location: location ? location.location : '',
        budget: budget ? String(budget.budget) : '',
        urgency: urgency.urgency,
        details: detailsParts.join(' — '),
        confidence: confidence,
        missing: missing,
        evidence: {
            cat: cat || null, date: d ? d.evidence : null, budget: budget ? budget.evidence : null,
            phone: phone ? phone.evidence : null, location: location ? location.evidence : null,
            name: name ? name.evidence : null, urgency: urgency.evidence
        },
        engine: 'rules'
    };
}

/* ---------- optional LLM refinement (SC_AI_KEY env) ---------- */

function llmCall(prompt, apiKey) {
    return new Promise((resolve) => {
        try {
            const body = JSON.stringify({
                model: 'gpt-4o-mini',
                messages: [
                    { role: 'system', content: 'You extract structured booking fields for a Ghanaian services marketplace. Reply with ONLY minified JSON: {"name":"","phone":"","cat":"mc|artist|photographer|videographer|dj|caterer|decorator|handy","date":"YYYY-MM-DD or empty","location":"","budget":"number as string or empty","urgency":"planned|soon|urgent","details":""}. Use empty strings for unknown fields. Never invent facts.' },
                    { role: 'user', content: prompt }
                ],
                temperature: 0, max_tokens: 300
            });
            const req = https.request({
                hostname: 'api.openai.com', path: '/v1/chat/completions', method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey, 'Content-Length': Buffer.byteLength(body) },
                timeout: 12000
            }, (res) => {
                let buf = '';
                res.on('data', c => { buf += c; });
                res.on('end', () => {
                    try {
                        const j = JSON.parse(buf);
                        const txt = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content || '';
                        const jsonTxt = txt.slice(txt.indexOf('{'), txt.lastIndexOf('}') + 1);
                        resolve(JSON.parse(jsonTxt));
                    } catch (e) { resolve(null); }
                });
            });
            req.on('timeout', () => { req.destroy(); resolve(null); });
            req.on('error', () => resolve(null));
            req.write(body);
            req.end();
        } catch (e) { resolve(null); }
    });
}

function sanitizeLLM(out) {
    if (!out || typeof out !== 'object') return null;
    const cats = ['mc', 'artist', 'photographer', 'videographer', 'dj', 'caterer', 'decorator', 'handy'];
    const org = ['planned', 'soon', 'urgent'];
    const s = (v, ok) => (typeof v === 'string' && v.trim() && ok(v.trim()) ? v.trim() : null);
    return {
        name: s(out.name, v => v.length <= 80) || null,
        phone: s(out.phone, v => /^(\+?233|0)\d{9}$/.test(v.replace(/[\s-]/g, ''))) || null,
        cat: s(out.cat, v => cats.includes(v)) || null,
        date: s(out.date, v => /^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(new Date(v).getTime())) || null,
        location: s(out.location, v => v.length <= 80) || null,
        budget: s(String(out.budget || ''), v => /^\d{2,7}$/.test(v)) || null,
        urgency: s(out.urgency, v => org.includes(v)) || null,
        details: s(out.details, v => v.length <= 400) || null
    };
}

async function aiParse(text, opts) {
    const base = ruleParse(text);
    const apiKey = (opts && opts.aiKey) || process.env.SC_AI_KEY || '';
    if (!apiKey) return base;   // deterministic-only mode

    const llm = await llmCall(String(text).slice(0, 800), apiKey);
    const refined = sanitizeLLM(llm);
    if (!refined) return base;   // LLM unavailable/wrong — rules result stands

    // Merge: LLM fills gaps; rules win on objective facts they found.
    const merged = Object.assign({}, base);
    for (const k of ['name', 'phone', 'cat', 'date', 'location', 'budget', 'urgency', 'details']) {
        if (!merged[k] && refined[k]) merged[k] = refined[k];
    }
    merged.missing = ['name', 'phone', 'cat', 'date', 'location', 'budget'].filter(k => !merged[k]);
    const found = 7 - merged.missing.length;
    merged.confidence = Math.round((found / 7) * 100) / 100;
    merged.engine = 'rules+llm';
    merged.evidence.llmFilled = Object.keys(refined).filter(k => refined[k] && !base[k]);
    return merged;
}

module.exports = { ruleParse, aiParse, parseDate, parseBudget, parsePhone, parseLocation, parseUrgency, parseName };
