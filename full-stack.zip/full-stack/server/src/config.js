/* ============================================================
   config.js — runtime configuration loader
   NO business constants live here. Values come from (in order):
     1. the `settings` table (single source of truth, admin-editable)
     2. process env for INFRASTRUCTURE only (DB creds, port, admin
        bootstrap password) — never business rules.
   The bootstrap admin password defaults to the sandbox's '4321'
   ONLY when the DB has no admin_auth row yet (first-run parity
   with the sandbox's ensureAdminAuth lazy bootstrap).
   ============================================================ */

'use strict';

let pool = null;

function setPool(p) { pool = p; }
function getPool() {
    if (!pool) throw new Error('config.setPool() must be called before config reads');
    return pool;
}

/* Cache settings with a short TTL so hot loops don't re-query,
   but admin edits apply within a second. */
let cache = null;
let cacheAt = 0;
const CACHE_MS = 1000;

async function allSettings(force) {
    if (!force && cache && Date.now() - cacheAt < CACHE_MS) return cache;
    const [rows] = await getPool().query('SELECT setting_key, setting_value FROM settings');
    cache = {};
    for (const r of rows) cache[r.setting_key] = typeof r.setting_value === 'string'
        ? JSON.parse(r.setting_value)
        : r.setting_value;
    cacheAt = Date.now();
    return cache;
}

async function get(key, fallback) {
    const s = await allSettings();
    const v = s[key];
    return (v === undefined || v === null) ? fallback : v;
}

async function num(key, fallback) {
    const v = await get(key, fallback);
    const n = Number(v);
    return isFinite(n) ? n : fallback;
}

async function bool(key, fallback) {
    const v = await get(key, fallback);
    return v === true || v === 'true' || v === 1;
}

function invalidate() { cache = null; }

/* Which payment gateway is live ('' = simulated sandbox payments).
   Lives here because both sc-api.js (sandbox-path gating) and
   payments.js (adapter selection) need it — no require cycle. */
async function activeGateway() {
    const g = await get('payment_gateway', '');
    return g ? String(g).toLowerCase() : '';
}

/* Infrastructure-only env config (no business rules). */
const infra = {
    DB_HOST: process.env.SC_DB_HOST || '127.0.0.1',
    DB_PORT: Number(process.env.SC_DB_PORT || 3306),
    DB_USER: process.env.SC_DB_USER || 'skillconnect',
    DB_PASS: process.env.SC_DB_PASS || '',
    DB_NAME: process.env.SC_DB_NAME || 'skillconnect',
    PORT: Number(process.env.SC_PORT || 8200),
    /* First-run bootstrap only; once admin_auth exists this is unused. */
    BOOTSTRAP_ADMIN_PASSWORD: process.env.SC_BOOTSTRAP_ADMIN_PASSWORD || '4321',
    /* Go-live lock: POST /api/reset is dev-only tooling. It requires an
       explicit opt-in env flag; the sandbox_mode setting alone is not
       enough on a deployment that serves real users. */
    ALLOW_RESET: (process.env.SC_ALLOW_RESET || 'false') === 'true',
    /* Sandbox hatches on dedicated routes (adminSession=1 on the gateway
       toggle / settings write). Development convenience only — an explicit
       env flag keeps them off a deployment serving real users. */
    ALLOW_SANDBOX_HOOKS: (process.env.SC_ALLOW_SANDBOX_HOOKS || 'false') === 'true',
    /* Secure cookie flag: ON by default (go-live). Only localhost-style dev
       deployments should set SC_INSECURE_COOKIES=true. */
    INSECURE_COOKIES: (process.env.SC_INSECURE_COOKIES || 'false') === 'true',
    /* Payment gateway secrets — infrastructure credentials only (env, never
       the settings table). WHICH gateway is active is the settings key
       'payment_gateway'. Empty secret ⇒ simulated confirm path (sandbox). */
    PAYSTACK_SECRET: process.env.SC_PAYSTACK_SECRET || '',
    PAYSTACK_PUBLIC: process.env.SC_PAYSTACK_PUBLIC || '',   /* inline checkout later; server itself only needs the secret */
    /* MTN MoMo Collections (direct) — infrastructure credentials only.
       All five must be present for the mtn_momo adapter to engage.
       Base URL/target env overridable so tests can point at a local stub. */
    MTN_BASE_URL: process.env.SC_MTN_BASE_URL || 'https://sandbox.momodeveloper.mtn.com',
    MTN_TARGET_ENV: process.env.SC_MTN_TARGET_ENV || 'sandbox',
    MTN_SUBSCRIPTION_KEY: process.env.SC_MTN_SUBSCRIPTION_KEY || '',
    MTN_API_USER: process.env.SC_MTN_API_USER || '',
    MTN_API_KEY: process.env.SC_MTN_API_KEY || '',
    /* Web Push (VAPID) — the "off-website notifications" channel. A browser
       subscription is bound to the server's public key, so a rotated key
       invalidates subscriptions. SC_VAPID_PUBLIC/PRIVATE are a generated
       P-256 pair (base64url); the sandbox test hook needs SC_ALLOW_SANDBOX_HOOKS. */
    VAPID_PUBLIC: process.env.SC_VAPID_PUBLIC || '',
    VAPID_PRIVATE: process.env.SC_VAPID_PRIVATE || '',
    VAPID_SUBJECT: process.env.SC_VAPID_SUBJECT || 'mailto:dispatch@skillconnectgh.com'
};

module.exports = { setPool, getPool, allSettings, get, num, bool, invalidate, activeGateway, infra };
