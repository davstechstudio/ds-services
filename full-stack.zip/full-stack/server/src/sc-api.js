/* ============================================================
   sc-api.js part 1 of 2 — read-only + CMS + catalog helpers
   (module.exports lives at the end of part 2)
   Every SC.* function mirrored 1:1 onto MySQL. NO business
   constants live here: tunables come from the settings table
   via config.get/num/bool (commission %, reg fee, OTP TTL,
   caps, max matches, sandbox_mode …), catalog data (labels,
   ranges, icons, SLAs) comes from categories/urgency_levels.
   Return shapes and {ok,error} strings match the sandbox so
   no page-level logic changes.
   ============================================================ */

'use strict';

const config = require('./config');
const db = require('./db');
const matchLog = require('./match-log');

/* ---------- notification preference classes (pro preference center) ----------
   Types a pro may mute vs. types that always arrive. The split is a HARD
   rule (informed by real usage patterns): anything about money the pro is
   owed, an assigned job, or platform enforcement cannot be silenced —
   muting those has burned pros on missed payouts and delistings.
   Both the server and the sandbox mirror (data-store.js) share this list
   verbatim — keep the two in sync when adding types. */
const NOTIFY_CRITICAL_TYPES = ['job', 'escrow', 'payment', 'payout', 'dispute'];
const NOTIFY_MUTABLE_TYPES = ['booking', 'application', 'review'];
const NOTIFY_PREFS_KEY = 'notify_muted_types';

function normNotifyPrefs(v) {
    const arr = Array.isArray(v) ? v : parseJson(v, []);
    if (!Array.isArray(arr)) return [];
    return [...new Set(arr.map(String))].filter(t => NOTIFY_MUTABLE_TYPES.includes(t));
}

/* ---------- row mappers: DB snake_case -> SC contract camelCase ----------

   JSON columns: mysql2 returns real objects on MySQL but plain strings on
   MariaDB (JSON = LONGTEXT + CHECK there). parseJson() normalizes both so
   the SC contract always carries arrays/objects. */
function parseJson(v, fallback) {
    if (v === null || v === undefined) return fallback;
    if (typeof v === 'string') { try { return JSON.parse(v); } catch (e) { return fallback; } }
    return v;
}

function proOut(r) {
    if (!r) return null;
    return {
        id: r.id, name: r.name, short: r.short_name, cat: r.cat, role: r.role, city: r.city,
        rating: Number(r.rating), ratingCount: r.rating_count, bookings: r.bookings_count,
        price: Number(r.price), unit: r.unit, note: r.note || '', phone: r.phone,
        verified: !!r.verified, emergency: !!r.emergency, response: r.response, years: r.years,
        languages: parseJson(r.languages, []), desc: r.description || '',
        earnings: Number(r.earnings), commissionPaid: Number(r.commission_paid), balance: Number(r.balance),
        blocked: parseJson(r.blocked, []), portfolio: parseJson(r.portfolio, null),
        joinedAt: Number(r.joined_at), source: r.source,
        appId: r.app_id || undefined,
        regFeePaid: !!r.reg_fee_paid, regFeeAt: r.reg_fee_at || undefined,
        idType: r.id_type || '', idNumber: r.id_number || '', tin: r.tin || '',
        contactChannels: r.contact_channels || 'both',
        notifyMutedTypes: parseJson(r.notify_muted_types, []),
        idDocsReceived: !!r.id_docs_received,
        idFrontName: r.id_front_name || '', idBackName: r.id_back_name || '',
        idFrontData: r.id_front_data || '', idBackData: r.id_back_data || '',
        idVerifiedAt: r.id_verified_at || 0, idReverify: r.id_reverify || '',
        idSubmittedAt: r.id_submitted_at || undefined,
        idGateUntil: Number(r.id_gate_until || 0),   /* admin ID-gate time override (0 = none) */
        hasRealPortfolio: !!r.has_real_portfolio,
        auth: r.auth_hash ? {
            salt: r.auth_salt, hash: r.auth_hash, algo: r.auth_algo || 'sha256',
            updatedAt: Number(r.auth_updated_at || 0)
        } : null
    };
}

/* Booking shape: events[] and escrow{} inlined exactly as the sandbox's object. */
function bookingOut(r, events, escrow) {
    if (!r) return null;
    const esc = escrow ? {
        method: escrow.method,
        paidAt: Number(escrow.paid_at),
        amount: Number(escrow.amount),
        released: !!escrow.released,
        txnRef: escrow.txn_ref
    } : null;
    if (esc && escrow.released_at) esc.releasedAt = Number(escrow.released_at);
    if (esc && escrow.pro_id) esc.proId = escrow.pro_id;
    return {
        id: r.id,
        name: r.customer_name, phone: r.customer_phone, cat: r.cat,
        date: r.event_date || '',
        location: r.location, budget: r.budget === null ? '' : Number(r.budget),
        urgency: r.urgency, details: r.details || '',
        status: r.status,
        matchedProIds: parseJson(r.matched_pro_ids, []),
        chosenProId: r.chosen_pro_id || null,
        amount: Number(r.amount),
        createdAt: Number(r.created_at),
        slaHours: (r.sla_hours === null || r.sla_hours === undefined) ? undefined : Number(r.sla_hours),
        events: events || [],
        escrow: esc,
        commission: r.commission === null ? undefined : Number(r.commission),
        reviewed: !!r.reviewed,
        rematchExclude: r.rematch_exclude || undefined,
        rematchPick: r.rematch_pick === null ? undefined : !!r.rematch_pick,
        proPaid: !!r.pro_paid, proPaidAt: r.pro_paid_at || undefined, proPaidMethod: r.pro_paid_method || undefined,
        paidAt: r.paid_at || undefined
    };
}

function quoteOut(r) {
    if (!r) return null;
    return {
        id: r.id, bookingId: r.booking_id, proId: r.pro_id,
        price: Number(r.price), etaHours: r.eta_hours,
        message: r.message, status: r.status,
        createdAt: Number(r.created_at), etaAt: Number(r.eta_at)
    };
}

function txnOut(r) {
    return {
        id: r.id, type: r.type, bookingId: r.booking_id, proId: r.pro_id,
        amount: Number(r.amount), method: r.method, note: r.note || '',
        status: r.status, at: Number(r.at)
    };
}

function appOut(r) {
    return {
        id: r.id, name: r.name, phone: r.phone, whatsapp: r.whatsapp || '', email: r.email || '',
        city: r.city, cat: r.cat, years: r.years || '', spec: r.spec || '',
        desc: r.description || '', languages: parseJson(r.languages, []),
        portfolioUrl: r.portfolio_url || '', social: r.social || '', samples: parseJson(r.samples, []),
        idType: r.id_type || '', idNumber: r.id_number || '', tin: r.tin || '',
        idFrontName: r.id_front_name || '', idBackName: r.id_back_name || '',
        idFrontData: r.id_front_data || '', idBackData: r.id_back_data || '',
        rate: r.rate, unit: r.unit || '', emergency: r.emergency === null ? '' : (r.emergency ? 'yes' : 'no'),
        response: r.response || '', momo: r.momo || '', days: parseJson(r.days, []),
        status: r.status, source: r.source, adminNote: r.admin_note || '',
        editedFields: r.edited_fields || undefined, editedAt: r.edited_at || undefined,
        regFeePaid: !!r.reg_fee_paid, regFeeAt: r.reg_fee_at || undefined,
        submittedAt: Number(r.submitted_at), reviewedAt: r.reviewed_at || undefined
    };
}

function reviewOut(r) {
    return {
        id: r.id, bookingId: r.booking_id, proId: r.pro_id, by: r.by_name,
        rating: r.rating, text: r.text || '', at: Number(r.at)
    };
}

function supportOut(r) {
    return {
        id: r.id, ref: r.ref, name: r.name, phone: r.phone, topic: r.topic,
        bookingRef: r.booking_ref || '', message: r.message,
        at: Number(r.at), status: r.status,
        handledAt: r.handled_at || undefined, handledBy: r.handled_by || undefined
    };
}

function disputeOut(r) {
    return {
        id: r.id, bookingId: r.booking_id, reason: r.reason, details: r.details || '',
        status: r.status, note: r.note || '', openedAt: Number(r.opened_at),
        resolvedAt: r.resolved_at || undefined
    };
}

/* cmsOut(): pro-auth columns are stripped (adminLogin-shaped response only). */

/* ---------- settings-driven constants (never hardcoded) ----------
   Tunables are read directly via config.get/num/bool (1s TTL cache). */

/* Sandbox rounding semantics on DECIMAL money: Math.round half-away-from-zero
   for positives — identical to the sandbox's Math.round on these values. */
function round2(n) { return Math.round(Number(n) * 100) / 100; }

/* Sandboxed features (simulated quotes, chat notes, OTP echo) are gated by
   the sandbox_mode setting so going live flips behaviour, not code. */
async function sandboxMode() { return config.bool('sandbox_mode', true); }

/* ---------- static lookups (from tables, admin-changeable) ---------- */

async function catMap() {
    const [rows] = await db.q('SELECT code, label, icon, range_min, range_max, advice FROM categories WHERE active = 1 ORDER BY sort');
    const out = {};
    for (const r of rows) out[r.code] = { name: r.label, advice: r.advice || '', range: [r.range_min, r.range_max], icon: r.icon };
    return out;
}

async function urgencyMap() {
    const [rows] = await db.q('SELECT code, label, sla_hours, note FROM urgency_levels WHERE active = 1 ORDER BY sort');
    const out = {};
    for (const r of rows) out[r.code] = { label: r.label, slaHours: Number(r.sla_hours), note: r.note };
    return out;
}

async function proIconsMap() {
    const [rows] = await db.q('SELECT code, icon FROM categories WHERE active = 1');
    const out = {};
    for (const r of rows) out[r.code] = r.icon;
    return out;
}

/* notification preference center (pro-level, staged 1:2)
   notify_muted_types: JSON array of MUTABLE types the pro has muted
   (['booking','application','review']). Critical types (job/escrow/payment/
   payout/dispute) are enforced in notify() and can never be stored. */
async function migrateNotifyPrefs() {
    const [cols] = await db.q(
        "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pros' AND COLUMN_NAME = 'notify_muted_types'");
    if (!cols.length) {
        await db.q("ALTER TABLE pros ADD COLUMN notify_muted_types JSON NULL AFTER contact_channels");
    }
}

/* ---------- notifications ---------- */

async function notify(conn, audience, refTo, type, text) {
    /* Pro preference center: a pro's muted types NEVER land (skipped before
       insert — the bell, Web Push, and the SMS/WhatsApp gateway leg all
       read the same row, so one check silences every surface). Money-critical
       and enforcement types are exempt by design (NOTIFY_CRITICAL_TYPES). */
    if (audience === 'pro' && refTo && !NOTIFY_CRITICAL_TYPES.includes(type)) {
        try {
            const q = (sql, p) => (conn ? conn.query(sql, p) : db.q(sql, p));
            const [mrows] = await q('SELECT notify_muted_types FROM pros WHERE id = ?', [refTo]);
            const muted = normNotifyPrefs(mrows.length ? mrows[0].notify_muted_types : null);
            if (muted.includes(String(type))) return null;   /* muted — silently skipped */
        } catch (e) { /* preference read failed — deliver (fail-open) */ }
    }
    const d = conn || { query: (sql, p) => db.q(sql, p) };
    const now = Date.now();
    /* 9-digit random suffix: parallel notifies in the same millisecond
       must not collide on the primary key (load-tested failure mode). */
    const id = 'N' + now + Math.floor(Math.random() * 1e9);
    const cap = await config.num('notifications_cap', 400);
    await d.query('INSERT INTO notifications (id, audience, ref_to, type, text, at, `read`) VALUES (?, ?, ?, ?, ?, ?, 0)',
        [id, audience, refTo || '', type, String(text || '').slice(0, 400), now]);
    /* Cap is NOT enforced here on purpose: the range DELETE gap-locks the
       notifications(audience) index and once an audience saturates its cap
       every parallel mutation would run it inside its tx — serializing and
       deadlocking them (found by tools/load-test.js). enforceNotificationCaps()
       sweeps periodically OUTSIDE business transactions instead. */
    /* Off-website delivery (Web Push) — strictly best-effort and OUTSIDE
       any open transaction: a push failure must never fail the booking.
       Customer pushes key on the same ref the notice was stored with
       (booking ref or application ref); pros key on their pro id. */
    try {
        const push = require('./push');
        push.pushNotify(audience, refTo, type, text).catch(() => {});
    } catch (e) { /* push layer unavailable — in-app notice still landed */ }
    /* Off-platform delivery (SMS / WhatsApp) — pro notices only, honouring
       the pro's contact_channels preference. Fire-and-forget like push:
       a gateway outage must never fail the business mutation. Every attempt
       is audited in channel_outbound (see notify-channels.js). */
    if (audience === 'pro' && refTo) {
        try {
            const channels = require('./notify-channels');
            channels.deliverProNotice(refTo, type, text, false).catch(() => {});
        } catch (e) { /* channel layer unavailable — in-app/push still landed */ }
    }
    return id;
}

/* ---------- transaction ledger ---------- */

async function addTxn(conn, type, bookingId, proId, amount, method, note, status) {
    const d = conn || { query: (sql, p) => db.q(sql, p) };
    const id = await db.nextRef(d, 'txn');
    const t = {
        id, type,
        bookingId: bookingId || null,
        proId: proId || null,
        amount: Number(amount),
        method: method || 'momo',
        note: note || '',
        status: status || 'success',
        at: Date.now()
    };
    await d.query(
        'INSERT INTO transactions (id, type, booking_id, pro_id, amount, method, note, status, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [t.id, t.type, t.bookingId, t.proId, t.amount, t.method, t.note, t.status, t.at]);
    return t;
}

/* ---------- pro row fetch / phone identity ---------- */

async function proRow(conn, id) {
    const [rows] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [id]);
    const p = rows[0] || null;
    if (p) {
        /* normalize JSON columns (MariaDB returns them as strings) so callers
           can use p.blocked.includes(...) etc. directly */
        p.blocked = parseJson(p.blocked, []);
        p.languages = parseJson(p.languages, []);
        p.portfolio = parseJson(p.portfolio, null);
    }
    return p;
}

function normPhone(p) {
    const d = String(p || '').replace(/\D/g, '');
    if (d.startsWith('233')) return '0' + d.slice(3);
    if (d.length === 9) return '0' + d;
    return d;
}

/* ---------- escrow helpers ---------- */

/* Inline escrow object for one booking (used by mappers that must re-read it). */
async function escrowFor(conn, bookingId) {
    const [rows] = await conn.query('SELECT * FROM escrow WHERE booking_id = ?', [bookingId]);
    return rows[0] || null;
}

/* All events for a booking, ordered by seq — the sandbox's b.events array. */
async function eventsFor(conn, bookingId) {
    const [rows] = await conn.query('SELECT at, text FROM booking_events WHERE booking_id = ? ORDER BY seq', [bookingId]);
    return rows.map(e => ({ at: Number(e.at), text: e.text }));
}

/* Next booking_events seq for a booking. */
async function nextEventSeq(conn, bookingId) {
    const [rows] = await conn.query('SELECT COALESCE(MAX(seq), -1) + 1 AS n FROM booking_events WHERE booking_id = ?', [bookingId]);
    return rows[0].n;
}

/* Push one timeline event (b.events.push in the sandbox). */
async function pushEvent(conn, bookingId, text, at) {
    const seq = await nextEventSeq(conn, bookingId);
    await conn.query('INSERT INTO booking_events (booking_id, seq, at, text) VALUES (?, ?, ?, ?)',
        [bookingId, seq, at || Date.now(), String(text).slice(0, 500)]);
}

/* ---------- shared write-side subroutines ---------- */

/* addQuoteInternal(): create a quote, flip matching -> quoted, log + notify. */
async function addQuoteInternal(conn, bookingId, proId, price, etaMs, proName) {
    const now = Date.now();
    const id = await db.nextRef(conn, 'quote');
    const [brows] = await conn.query('SELECT urgency, status FROM bookings WHERE id = ?', [bookingId]);
    const b = brows[0];
    if (!b) return null;
    const quote = {
        id, bookingId, proId,
        price: Number(price),
        etaHours: b.urgency === 'urgent' ? 1 : 24,
        message: 'Available for this job. Price covers scope discussed; parts/transport confirmed on chat.',
        status: 'sent',
        createdAt: now,
        etaAt: now + (etaMs || 0)
    };
    await conn.query(
        'INSERT INTO quotes (id, booking_id, pro_id, price, eta_hours, message, status, created_at, eta_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [quote.id, quote.bookingId, quote.proId, quote.price, quote.etaHours, quote.message, quote.status, quote.createdAt, quote.etaAt]);
    if (b.status === 'matching') await conn.query("UPDATE bookings SET status = 'quoted' WHERE id = ?", [bookingId]);
    await pushEvent(conn, bookingId, 'Quote ' + cedi(price) + ' received from ' + (proName || proId));
    /* LTR outcome: a quote arrived for this booking's latest match event. */
    await matchLog.updateOutcomeInTx(conn, bookingId, (o) => {
        o.quoteCount = (o.quoteCount || 0) + 1;
        o.lastQuoteProId = proId;
        o.lastQuotePrice = Number(price);
        return o;
    });
    await notify(conn, 'customer', bookingId, 'quote', 'New quote ' + cedi(price) + ' on booking ' + bookingId);
    return quote;
}

function cedi(n) { return 'GH\u20B5 ' + Number(n || 0).toLocaleString('en-US'); }

/* ---------- read-only SC functions ---------- */

async function getPros() {
    const [rows] = await db.q('SELECT * FROM pros ORDER BY id');
    return rows.map(proOut);
}

async function getPro(id) {
    const [rows] = await db.q('SELECT * FROM pros WHERE id = ?', [id]);
    return proOut(rows[0] || null);
}

async function getCms() {
    const [rows] = await db.q('SELECT * FROM cms WHERE id = 1');
    const r = rows[0];
    if (!r) return {};
    const out = {
        heroTitle: r.hero_title, heroSub: r.hero_sub,
        announceOn: !!r.announce_on, announceText: r.announce_text,
        regFee: Number(r.reg_fee), updatedAt: Number(r.updated_at)
    };
    return out;
}

async function updateCms(patch) {
    return db.tx(async (conn) => {
        const p = patch || {};
        const sets = [], params = [];
        if (p.heroTitle !== undefined) { sets.push('hero_title = ?'); params.push(String(p.heroTitle).slice(0, 160)); }
        if (p.heroSub !== undefined) { sets.push('hero_sub = ?'); params.push(String(p.heroSub)); }
        if (p.announceOn !== undefined) { sets.push('announce_on = ?'); params.push(p.announceOn ? 1 : 0); }
        if (p.announceText !== undefined) { sets.push('announce_text = ?'); params.push(String(p.announceText)); }
        if (p.regFee !== undefined) { sets.push('reg_fee = ?'); params.push(Number(p.regFee) || 0); }
        const now = Date.now();
        sets.push('updated_at = ?'); params.push(now);
        await conn.query('UPDATE cms SET ' + sets.join(', ') + ' WHERE id = 1', params);
        config.invalidate();
        const [rows] = await conn.query('SELECT * FROM cms WHERE id = 1');
        const r = rows[0];
        return {
            heroTitle: r.hero_title, heroSub: r.hero_sub,
            announceOn: !!r.announce_on, announceText: r.announce_text,
            regFee: Number(r.reg_fee), updatedAt: Number(r.updated_at)
        };
    });
}

async function getRegFee() {
    const [rows] = await db.q('SELECT reg_fee FROM cms WHERE id = 1');
    const n = rows.length ? Number(rows[0].reg_fee) : 0;
    if (n > 0 && isFinite(n)) return n;
    return config.num('default_reg_fee', 50);
}

/* Category/urgency lookups the pages consume as constants today. */
async function getCatalog() {
    const [cats] = await db.q('SELECT code, label, icon, range_min, range_max, advice FROM categories WHERE active = 1 ORDER BY sort');
    const [urg] = await db.q('SELECT code, label, sla_hours, note FROM urgency_levels WHERE active = 1 ORDER BY sort');
    return {
        CAT_LABELS: Object.fromEntries(cats.map(r => [r.code, r.label])),
        CATEGORY_INFO: Object.fromEntries(cats.map(r => [r.code, { name: r.label, advice: r.advice || '', range: [r.range_min, r.range_max] }])),
        PRO_ICONS: Object.fromEntries(cats.map(r => [r.code, r.icon])),
        URGENCY_INFO: Object.fromEntries(urg.map(r => [r.code, { label: r.label, slaHours: Number(r.sla_hours), note: r.note }])),
        COMMISSION_RATE: await config.num('commission_rate', 0.10)
    };
}

/* ---------- AI price guidance (live market stats) ----------
   Real numbers beat static advice: blend verified pros' listed rates with
   actually-quoted amounts (quotes carry real negotiation outcomes) and the
   curated category range into one guidance packet per category. Cached for
   60s — the booking form and the AI assistant both read it. */
let PRICE_STATS_AT = 0;
let PRICE_STATS = null;
async function priceStats() {
    if (PRICE_STATS && Date.now() - PRICE_STATS_AT < 60000) return PRICE_STATS;
    const cats = await catMap();
    const [proRows] = await db.q('SELECT cat, MIN(price) AS lo, MAX(price) AS hi, COUNT(*) AS n FROM pros WHERE verified = 1 GROUP BY cat');
    const [quoteRows] = await db.q("SELECT b.cat AS cat, MIN(q.price) AS lo, MAX(q.price) AS hi, COUNT(*) AS n, AVG(q.price) AS avg FROM quotes q JOIN bookings b ON b.id = q.booking_id WHERE q.status IN ('sent','accepted') GROUP BY b.cat");
    const [acceptRows] = await db.q("SELECT b.cat AS cat, AVG(q.price) AS avg, COUNT(*) AS n FROM quotes q JOIN bookings b ON b.id = q.booking_id WHERE q.status = 'accepted' GROUP BY b.cat");
    const proMap = Object.fromEntries(proRows.map(r => [r.cat, r]));
    const quoteMap = Object.fromEntries(quoteRows.map(r => [r.cat, r]));
    const acceptMap = Object.fromEntries(acceptRows.map(r => [r.cat, r]));
    const out = {};
    for (const [code, info] of Object.entries(cats)) {
        const [rMin, rMax] = info.range;
        const p = proMap[code], q = quoteMap[code], a = acceptMap[code];
        /* Blend: curated range is the floor/ceiling scaffold; observed rates
           pull the typical band toward reality as the marketplace grows. */
        const lo = Math.min(p ? Number(p.lo) : Infinity, rMin);
        const hi = Math.max(p ? Number(p.hi) : 0, rMax);
        const typicalLo = Math.round((Math.max(lo, p ? Number(p.lo) : lo) * 0.9 + rMin * 0.1) / 10) * 10;
        const typicalHi = Math.round((Math.min(hi, p ? Number(p.hi) : hi) * 0.9 + rMax * 0.1) / 10) * 10;
        out[code] = {
            name: info.name,
            range: [rMin, rMax],
            observed: p ? { lo: Number(p.lo), hi: Number(p.hi), pros: Number(p.n) } : null,
            quoted: q ? { lo: Number(q.lo), hi: Number(q.hi), avg: Math.round(Number(q.avg)), samples: Number(q.n) } : null,
            acceptedAvg: a ? Math.round(Number(a.avg)) : null,
            typical: [Math.min(typicalLo, typicalHi), Math.max(typicalLo, typicalHi)],
            sampleSize: (p ? Number(p.n) : 0) + (q ? Number(q.n) : 0)
        };
    }
    PRICE_STATS = out;
    PRICE_STATS_AT = Date.now();
    return out;
}

/* Predict the match outcome for a budget BEFORE the customer submits —
   the no-match killer. Uses the same floor the matching engine uses
   (50% of the category minimum) and the live verified pool. */
async function budgetOutcome(cat, budget) {
    const stats = await priceStats();
    const s = stats[cat];
    if (!s) return { ok: false };
    const [rows] = await db.q('SELECT COUNT(*) AS n, MIN(price) AS lo FROM pros WHERE verified = 1 AND cat = ?', [cat]);
    const poolCount = rows.length ? Number(rows[0].n) : 0;
    const poolLo = rows.length ? Number(rows[0].lo) : 0;
    const b = Number(budget) || 0;
    if (!b) return { ok: true, level: 'none', poolCount: poolCount, message: 'No budget given — every available pro in this category will be considered.' };
    const floor = s.range[0] * 0.5;
    let level, message;
    if (b < floor) {
        level = 'unlikely';
        message = 'Below the minimum any verified ' + s.name + ' charges (' + cedi(poolLo) + ') — this would go to manual search. Raise it to at least ' + cedi(poolLo) + '.';
    } else {
        const [inRange] = await db.q('SELECT COUNT(*) AS n FROM pros WHERE verified = 1 AND cat = ? AND price <= ?', [cat, b]);
        const n = inRange.length ? Number(inRange[0].n) : 0;
        if (n === 0) {
            level = 'unlikely';
            message = 'No verified ' + s.name + ' currently charges within ' + cedi(b) + ' — this would go to manual search. The lowest available rate is ' + cedi(poolLo) + '.';
        } else if (n === 1) {
            level = 'thin';
            message = 'Only 1 verified ' + s.name + ' fits ' + cedi(b) + ' — expect one quote. A little more budget widens the choice.';
        } else if (n <= 2) {
            level = 'fair';
            message = n + ' verified ' + s.name + ' pros fit ' + cedi(b) + ' — good odds of quick quotes.';
        } else {
            level = 'strong';
            message = n + ' verified ' + s.name + ' pros fit ' + cedi(b) + ' — expect several competing quotes fast.';
        }
    }
    return { ok: true, level: level, poolCount: poolCount, message: message, fittingPros: level === 'unlikely' ? 0 : undefined };
}

/* ---------- support messages ---------- */

async function submitSupportMessage(name, phone, topic, bookingRef, message) {
    const n = String(name || '').trim();
    const ph = String(phone || '').trim();
    const msg = String(message || '').trim();
    if (!n || !ph || !msg) return { ok: false, error: 'Name, phone and message are required.' };
    if (msg.length > 2000) return { ok: false, error: 'Message is too long (max 2000 characters).' };
    const topicMap = {
        booking: 'Booking / Existing Request', payment: 'Payment / Escrow Question',
        pro: 'I Am A Professional', complaint: 'Complaint / Dispute',
        suggestion: 'Suggestion / New Category', other: 'Something Else'
    };
    const t = topicMap[topic] ? topic : 'other';
    return db.tx(async (conn) => {
        const id = await db.nextRef(conn, 'msg');
        const m = {
            id, ref: db.supportRef(),
            name: n.slice(0, 80), phone: ph.slice(0, 20), topic: t,
            bookingRef: String(bookingRef || '').trim().slice(0, 20),
            message: msg, at: Date.now(), status: 'open'
        };
        await conn.query(
            'INSERT INTO support_messages (id, ref, name, phone, topic, booking_ref, message, at, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [m.id, m.ref, m.name, m.phone, m.topic, m.bookingRef, m.message, m.at, m.status]);
        await notify(conn, 'admin', m.id, 'support', 'Support message ' + m.ref + ' from ' + n + ' (' + topicMap[m.topic] + ')');
        return { ok: true, message: m };
    });
}

async function supportMessages() {
    const [rows] = await db.q('SELECT * FROM support_messages ORDER BY at DESC, id DESC');
    return rows.map(supportOut);
}

async function resolveSupportMessage(id, adminTag) {
    return db.tx(async (conn) => {
        const [rows] = await conn.query('SELECT id FROM support_messages WHERE id = ? FOR UPDATE', [id]);
        if (!rows.length) return { ok: false, error: 'Support message not found.' };
        await conn.query('UPDATE support_messages SET status = ?, handled_at = ?, handled_by = ? WHERE id = ?',
            ['resolved', Date.now(), adminTag || 'admin', id]);
        return { ok: true };
    });
}

/* ---------- reviews ---------- */

async function addReview(bookingId, rating, text) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        if (!b || !b.chosen_pro_id || b.status !== 'completed') return { ok: false, error: 'You can review after the job is completed.' };
        const [dup] = await conn.query('SELECT id FROM reviews WHERE booking_id = ?', [bookingId]);
        if (dup.length) return { ok: false, error: 'Already reviewed this booking.' };
        const [prows] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [b.chosen_pro_id]);
        const pro = prows[0];
        if (!pro) return { ok: false, error: 'Pro not found.' };

        const id = await db.nextRef(conn, 'review');
        const review = {
            id, bookingId, proId: pro.id,
            by: b.customer_name || 'Verified Customer',
            rating: Math.max(1, Math.min(5, Number(rating) || 5)),
            text: text || '', at: Date.now()
        };
        await conn.query('INSERT INTO reviews (id, booking_id, pro_id, by_name, rating, text, at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [review.id, review.bookingId, review.proId, review.by, review.rating, review.text, review.at]);
        const total = Number(pro.rating) * pro.rating_count + review.rating;
        const newCount = pro.rating_count + 1;
        const newRating = Math.round((total / newCount) * 10) / 10;
        await conn.query('UPDATE pros SET rating_count = ?, rating = ? WHERE id = ?', [newCount, newRating, pro.id]);
        await conn.query('UPDATE bookings SET reviewed = 1 WHERE id = ?', [bookingId]);
        /* LTR outcome: customer satisfaction for the chosen candidate. */
        await matchLog.updateOutcomeInTx(conn, bookingId, { reviewRating: review.rating });
        await notify(conn, 'pro', pro.id, 'review', 'New ' + review.rating + '\u2605 review on ' + bookingId + (review.text ? ': \u201C' + review.text.slice(0, 60) + '\u201D' : ''));
        return { ok: true, review };
    });
}

async function getReviewsFor(proId) {
    const [rows] = await db.q('SELECT * FROM reviews WHERE pro_id = ? ORDER BY at DESC, id DESC', [proId]);
    return rows.map(reviewOut);
}

/* ---------- chat ---------- */

async function chatMessages(bookingId) {
    const [rows] = await db.q('SELECT sender, text, at FROM chat_messages WHERE booking_id = ? ORDER BY seq', [bookingId]);
    return rows.map(m => ({ from: m.sender, text: m.text, at: Number(m.at) }));
}

/* chat insert usable inside an existing transaction (nested db.tx would
   deadlock: the inner FK check blocks on the outer's parent-row lock) */
async function sendChatInTx(conn, bookingId, from, text) {
    const [rows] = await conn.query('SELECT COALESCE(MAX(seq), -1) + 1 AS n FROM chat_messages WHERE booking_id = ?', [bookingId]);
    await conn.query('INSERT INTO chat_messages (booking_id, seq, sender, text, at) VALUES (?, ?, ?, ?, ?)',
        [bookingId, rows[0].n, from, String(text).slice(0, 1000), Date.now()]);
}

async function sendChat(bookingId, from, text) {
    return db.tx(async (conn) => {
        await sendChatInTx(conn, bookingId, from, text);
        return chatMessages(bookingId);
    });
}

function systemChat(bookingId, text) { return sendChat(bookingId, 'system', text); }


/* ============================================================
   PART 2 — write-side logic (bookings, matching, escrow,
   disputes, payouts, admin, credentials, sessions).
   Business rules ported 1:1 from data-store.js: same order of
   events, same notify texts, same rounding. Tunables from
   settings (max_matches, commission_rate, otp_ttl_minutes,
   default passwords for bootstrap, sandbox_mode); catalog data
   from categories/urgency_levels tables.
   ============================================================ */

/* ---------- applications ---------- */

async function addApplication(app) {
    return db.tx(async (conn) => {
        const id = await db.nextRef(conn, 'app');
        const rec = Object.assign({
            id,
            status: 'pending',
            submittedAt: Date.now(),
            source: 'register-page'
        }, app);
        await conn.query(
            `INSERT INTO applications
                (id, name, phone, whatsapp, email, city, cat, years, spec, description,
                 languages, portfolio_url, social, samples, id_type, id_number, tin,
                 id_front_name, id_back_name, id_front_data, id_back_data,
                 rate, unit, emergency, response, momo, days, status, source, submitted_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [rec.id, rec.name, rec.phone, rec.whatsapp || null, rec.email || null, rec.city, rec.cat,
             rec.years || null, rec.spec || null, rec.desc || null,
             JSON.stringify(rec.languages || []), rec.portfolioUrl || null, rec.social || null,
             JSON.stringify(rec.samples || []), rec.idType || null, rec.idNumber || null, rec.tin || null,
             rec.idFrontName || null, rec.idBackName || null, rec.idFrontData || null, rec.idBackData || null,
             rec.rate === undefined || rec.rate === '' ? null : Number(rec.rate),
             rec.unit || null,
             rec.emergency === undefined || rec.emergency === '' ? null : (rec.emergency === 'yes' ? 1 : 0),
             rec.response || null, rec.momo || null, JSON.stringify(rec.days || []),
             'pending', rec.source || 'register-page', rec.submittedAt]);
        const [crows] = await conn.query('SELECT label FROM categories WHERE code = ?', [rec.cat]);
        const catLabel = crows.length ? crows[0].label : rec.cat;
        await notify(conn, 'admin', rec.id, 'application', 'New application: ' + rec.name + ' (' + catLabel + ', ' + rec.city + ') \u2014 ' + rec.id);
        await notify(conn, 'customer', rec.id, 'application', 'Application received (' + rec.id + '). Verification happens within 24 hours.');
        return appOut(Object.assign(rec, {
            languages: rec.languages || [], samples: rec.samples || [], days: rec.days || [],
            emergency: rec.emergency === undefined || rec.emergency === '' ? '' : (rec.emergency === 'yes' ? 'yes' : 'no')
        }));
    });
}

async function getApplications() {
    const [rows] = await db.q('SELECT * FROM applications ORDER BY submitted_at DESC, id DESC');
    return rows.map(appOut);
}

/* Admin-editable settings (tiny allowlist — full settings stay code/gateway
   managed). Used by the admin CMS, e.g. to publish the USSD shortcode the
   day the network provisions it, without a code change. */
const SETTING_ALLOWLIST = ['ussd_code', 'id_grace_days', 'id_valid_years', 'id_warn_days', 'commission_rate'];

/* Extend the admin-editable settings allowlist at boot (used by index.js
   to expose the ID-gate windows without widening the function surface). */
function setAdminSettingAllowlist(keys) {
    for (const k of Array.isArray(keys) ? keys : []) {
        if (!SETTING_ALLOWLIST.includes(k)) SETTING_ALLOWLIST.push(k);
    }
}

async function setSetting(key, value) {
    if (!SETTING_ALLOWLIST.includes(key)) return { ok: false, error: 'Setting is not admin-editable: ' + key };
    let v = value;
    if (key === 'ussd_code') {
        v = String(value === undefined || value === null ? '' : value).trim();
        if (v) {
            if (!/^\*\d{1,4}(\*\d{1,4})*#?$/.test(v)) return { ok: false, error: 'USSD codes look like *384*444# — please check the format.' };
            if (!v.endsWith('#')) v += '#';
        }
    }
    if (key === 'id_grace_days' || key === 'id_valid_years' || key === 'id_warn_days') {
        const n = Math.floor(Number(value));
        const max = key === 'id_valid_years' ? 10 : 365;
        if (!isFinite(n) || n < 0 || n > max) return { ok: false, error: 'Enter a number between 0 and ' + max + '.' };
        v = n;
    }
    if (key === 'commission_rate') {
        const n = Number(value);
        /* Percent (0–100) or fraction (≤1); clamp to a sane band. */
        const frac = n > 1 ? n / 100 : n;
        if (!isFinite(frac) || frac < 0 || frac > 0.5) return { ok: false, error: 'Commission must be between 0% and 50%.' };
        v = Math.round(frac * 10000) / 10000;
    }
    const [upd] = await db.q('UPDATE settings SET setting_value = ?, updated_at = ? WHERE setting_key = ?', [JSON.stringify(v), Date.now(), key]);
    if (!upd || upd.affectedRows === 0) {
        await db.q('INSERT INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?)', [key, JSON.stringify(v), Date.now()]);
    }
    config.invalidate();
    /* Time-sensitive windows take effect the moment they change: drop the
       cached id windows so the next gate check re-reads them. */
    if (key === 'id_valid_years' || key === 'id_warn_days') {
        ID_W = await idWindows();
    }
    if (key === 'id_grace_days') {
        await idGateWindows();
    }
    return { ok: true, key: key, value: v };
}

/* Outreach drafts (WhatsApp / SMS / email) for a verified applicant —
   computed live so they always reflect final profile values. */
async function verifiedNotices(appRef) {
    const [arows] = await db.q('SELECT * FROM applications WHERE id = ?', [appRef]);
    const app = arows[0];
    if (!app) return { ok: false, error: 'Application is not verified yet.' };
    const [prows] = await db.q('SELECT id FROM pros WHERE app_id = ?', [appRef]);
    const pro = prows[0];
    if (!pro) return { ok: false, error: 'Application is not verified yet.' };

    const siteUrl = await config.get('site_url', 'https://skillconnectgh.com');
    const link = siteUrl + '/index.html?pro=' + pro.id;
    const digits = String(app.whatsapp || app.phone || '').replace(/\D/g, '');
    let intl = digits;
    if (intl.startsWith('0')) intl = '233' + intl.slice(1);
    else if (!intl.startsWith('233')) intl = '233' + intl;
    const local = intl.startsWith('233') && intl.length >= 12 ? '0' + intl.slice(3) : digits;

    const name = app.name;
    const waMsg = '\uD83C\uDF89 Congratulations ' + name + '! Your SkillConnect application is VERIFIED.\n\n' +
        'Your professional profile is now live:\n' + link + '\n\n' +
        'Customers can find and book you from today. Share your link to get booked faster.\n\n\u2014 SkillConnect GH (024 421 1595)';
    const smsMsg = 'SkillConnect GH: You are VERIFIED ' + name + '! Your profile is live: ' + link;
    const mailBody = 'Hello ' + name + ',\n\nGreat news \u2014 your SkillConnect application has been verified.\n\n' +
        'Your professional profile is now live at:\n' + link + '\n\n' +
        'What happens next:\n' +
        '1. Customers discover you in the directory and request quotes.\n' +
        '2. You get job alerts on WhatsApp for your category and city.\n' +
        '3. Payments are held in escrow and released to you when the job is done.\n\n' +
        'Tip: share your profile link with past clients to build reviews quickly.\n\n' +
        '\u2014 The SkillConnect GH Team\n024 421 1595';

    return {
        ok: true, ref: appRef, proId: pro.id, name, link,
        channels: {
            wa: 'https://wa.me/' + intl + '?text=' + encodeURIComponent(waMsg),
            sms: 'sms:' + local + '?&body=' + encodeURIComponent(smsMsg),
            email: app.email ? 'mailto:' + app.email + '?subject=' + encodeURIComponent('You are verified on SkillConnect GH \uD83C\uDF89') + '&body=' + encodeURIComponent(mailBody) : null
        }
    };
}

async function reviewApplication(appId, decision, note, edits) {
    return db.tx(async (conn) => {
        const [arows] = await conn.query('SELECT * FROM applications WHERE id = ? FOR UPDATE', [appId]);
        const app = arows[0];
        if (!app) return null;
        await conn.query('UPDATE applications SET status = ?, reviewed_at = ?, admin_note = ? WHERE id = ?',
            [decision, Date.now(), note || '', appId]);

        /* Admin corrections (rate/city/category) applied before the pro record is
           created; original values kept on the application for the audit trail. */
        const applied = { rate: Number(app.rate), city: app.city, cat: app.cat };
        if (decision === 'verified' && edits && typeof edits === 'object') {
            const e = {};
            if (edits.rate !== undefined && Number(edits.rate) > 0 && Number(edits.rate) !== Number(app.rate)) { e.rate = app.rate; applied.rate = Number(edits.rate); }
            if (typeof edits.city === 'string' && edits.city.trim() && edits.city.trim() !== app.city) { e.city = app.city; applied.city = edits.city.trim(); }
            if (edits.cat && (await catExists(conn, edits.cat)) && edits.cat !== app.cat) { e.cat = app.cat; applied.cat = edits.cat; }
            if (Object.keys(e).length) {
                await conn.query('UPDATE applications SET edited_fields = ?, edited_at = ? WHERE id = ?',
                    [JSON.stringify(e), Date.now(), appId]);
                await conn.query('UPDATE applications SET city = ?, cat = ? WHERE id = ?', [applied.city, applied.cat, appId]);
            }
        }

        if (decision === 'verified') {
            /* id rule identical to the sandbox: P + 1001 + number of existing pros */
            const [cnt] = await conn.query('SELECT COUNT(*) AS c FROM pros');
            const id = 'P' + String(1001 + cnt[0].c);
            const [langRows] = await conn.query('SELECT languages FROM applications WHERE id = ?', [appId]);
            const langs = (langRows[0] && langRows[0].languages) || ['English'];
            await conn.query(
                `INSERT INTO pros (id, name, short_name, cat, role, city, rating, rating_count, bookings_count,
                    price, unit, note, phone, verified, emergency, response, years, languages, description,
                    earnings, commission_paid, balance, blocked, joined_at, source, app_id,
                    id_type, id_number, tin, id_docs_received, id_front_name, id_back_name)
                 VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, 'registration', ?, ?, ?, ?, ?, ?, ?)`,
                [id, app.name, app.name.split(' ')[0], applied.cat,
                 await catLabelOf(conn, applied.cat), applied.city,
                 Number(applied.rate) || 100, app.unit || 'visit',
                 (app.spec || 'New professional') + ' \u00B7 New on SkillConnect',
                 app.phone, app.emergency === 1 ? 1 : 0,
                 app.response || 'sameday', app.years || '0-2',
                 JSON.stringify(langs), app.description || '',
                 JSON.stringify([]), Date.now(), app.id,
                 app.id_type || 'ghana_card', app.id_number || '', app.tin || '',
                 !!(app.id_front_name && app.id_back_name), app.id_front_name || '', app.id_back_name || '']);
            const siteUrl = await config.get('site_url', 'https://skillconnectgh.com');
            await notify(conn, 'customer', app.id, 'application', 'You are VERIFIED! Your profile is live: ' + siteUrl + '/index.html?pro=' + id + ' \u2014 share your link to get booked faster.');
        } else {
            await notify(conn, 'customer', app.id, 'application', 'Application ' + app.id + ' was not approved. ' + (note || ''));
        }
        const [after] = await conn.query('SELECT * FROM applications WHERE id = ?', [appId]);
        return appOut(after[0]);
    });
}

/* category helpers */
async function catLabelOf(conn, code) {
    const [rows] = await conn.query('SELECT label FROM categories WHERE code = ?', [code]);
    return rows.length ? rows[0].label : code;
}
async function catExists(conn, code) {
    const [rows] = await conn.query('SELECT code FROM categories WHERE code = ? AND active = 1', [code]);
    return rows.length > 0;
}

/* ---------- bookings & matching engine ---------- */

const RESP_RANK = { '1hr': 0, '3hr': 1, 'sameday': 2, '24hr': 3 };   /* sort key only (not tunable) */

/* ---------- travel-distance helpers (near-first matching) ----------
   Approximate road-km between the service hubs pros list as their city and
   the customer's stated location. The location string is a free-text field,
   so this is a deliberate heuristic, not geocoding: the customer's text is
   scanned for the nearest known place, with neighbourhood aliases folded in
   (Osu/Airport Residential are Accra; Tema Comm. 25 is Tema, etc.). */
const HUBS = {
    'accra': 0, 'osu': 5, 'labone': 6, 'east legon': 12, 'airport residential': 8, 'cantonments': 7,
    'madina': 16, 'tema': 27, 'kasoa': 33, 'amosa': 33, 'kumasi': 253, 'takoradi': 226, 'cape coast': 138
};
const HUB_ALIASES = [
    ['tema comm', 'tema'], ['tema community', 'tema'], ['ashaiman', 'tema'],
    ['airport city', 'airport residential'], ['airport hills', 'airport residential']
];

function locationKm(location) {
    const s = String(location || '').toLowerCase();
    for (const [alias, canonical] of HUB_ALIASES) {
        if (s.includes(alias)) return HUBS[canonical];
    }
    let best = null;
    for (const place of Object.keys(HUBS)) {
        if (s.includes(place)) {
            const d = HUBS[place];
            if (best === null || d < best) best = d;
        }
    }
    return best;   /* null = unknown location: distance plays no part */
}

function proKm(p, baseKm) {
    if (baseKm === null || baseKm === undefined) return null;
    const hub = HUBS[String(p.city || '').toLowerCase()];
    return hub === undefined ? null : Math.abs(hub - baseKm);
}

/* ---------- learning-to-rank capture (LTR-1) ----------
   match_events logs every automated matching decision (full candidate
   pool + per-candidate features + who was shown) so a model can replace
   the near-first heuristic later. See match-log.js. These helpers are
   strictly non-fatal: training capture must never alter booking flow. */
async function migrateMatchEvents() {
    await db.q(`CREATE TABLE IF NOT EXISTS match_events (
        id          BIGINT       NOT NULL AUTO_INCREMENT,
        booking_id  VARCHAR(16)  NOT NULL,
        cat         VARCHAR(20)  NOT NULL,
        location    VARCHAR(160) NOT NULL,
        base_km     INT          NULL,
        urgency     VARCHAR(12)  NOT NULL,
        budget      DECIMAL(10,2) NULL,
        event_date  DATE         NULL,
        engine      VARCHAR(32)  NOT NULL,
        candidates  JSON         NOT NULL,
        shown_ids   JSON         NOT NULL,
        outcome     JSON         NOT NULL,
        created_at  BIGINT       NOT NULL,
        PRIMARY KEY (id),
        KEY idx_me_booking (booking_id),
        KEY idx_me_engine (engine, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
}

/* Marks the candidate pool in gateKeep's return shape (true = hidden from
   NEW matching, not from quotes/notifications — pro stays matched if a
   decision predates the delisting). The log exports this so future models
   can learn the ID-gate boundary. */
const MATCH_GATE_HIDDEN = Symbol('matchGateHidden');

/* Tier labels for the transparency event: how local was the match? */
function kmTier(km) {
    if (km === null) return 'near';
    if (km <= 35) return 'near';
    if (km <= 120) return 'mid';
    return 'far';
}

/* Near-first matcher shared by createBooking, updateBookingBudget and the
   rematch pool. Fills the invite list from the closest tier outward (near →
   mid → far → unknown-distance remainder) up to maxMatches; only when NO pro
   at all matched does the caller fall back to its calm no-match path.
   Matching stays best-effort, never a hard wall: a far pro still beats an
   empty invite list. Unknown distances (unrecognised city text) rank last,
   after the known map — a real near/mid/far always beats a guess. */
function matchNearFirst(pool, location, maxMatches) {
    const base = locationKm(location);
    const withKm = pool.map(p => ({ p, km: proKm(p, base) }));
    const tierOf = e => kmTier(e.km);
    const rank = { near: 0, mid: 1, far: 2 };
    withKm.sort((x, y) => {
        const tx = tierOf(x), ty = tierOf(y);
        const rx = rank[tx], ry = rank[ty];
        if (rx !== ry) return rx - ry;
        if (tx === 'near' || tx === 'mid') return (x.km - y.km) || ((RESP_RANK[x.p.response] ?? 2) - (RESP_RANK[y.p.response] ?? 2)) || (y.p.rating - x.p.rating) || (y.p.bookings - x.p.bookings);
        if (tx === 'far') return (x.km - y.km) || ((RESP_RANK[x.p.response] ?? 2) - (RESP_RANK[y.p.response] ?? 2)) || (y.p.rating - x.p.rating);
        return ((RESP_RANK[x.p.response] ?? 2) - (RESP_RANK[y.p.response] ?? 2)) || (y.p.rating - x.p.rating) || (y.p.bookings - x.p.bookings);
    });
    return withKm.slice(0, maxMatches).map(e => e.p);
}

async function createBooking(request) {
    return db.tx(async (conn) => createBookingInTx(conn, request));
}

/* createBooking core for use inside an existing transaction. */
async function createBookingInTx(conn, request) {
    const now = Date.now();
    const id = await db.nextRef(conn, 'booking');
    const b = {
        id,
        name: request.name, phone: request.phone,
        cat: request.job || request.cat,
        date: request.date || '',
        location: request.location,
        budget: request.budget || '',
        urgency: request.urgency || 'planned',
        details: request.details || '',
        status: 'matching',
        matchedProIds: [],
        chosenProId: null,
        amount: 0,
        createdAt: now
    };
    await conn.query(
        `INSERT INTO bookings (id, customer_name, customer_phone, cat, event_date, location, budget,
            urgency, details, status, matched_pro_ids, chosen_pro_id, amount, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 0, ?)`,
        [b.id, b.name, b.phone, b.cat,
         b.date || null, b.location, b.budget === '' || b.budget === null ? null : Number(b.budget),
         b.urgency, b.details, b.status, JSON.stringify([]), b.createdAt]);
    await pushEvent(conn, b.id, 'Request received. Searching verified pros\u2026', now);

    /* ---- matching engine (ported 1:1; max_matches from settings) ---- */
    const [urows] = await conn.query('SELECT sla_hours FROM urgency_levels WHERE code = ?', [b.urgency]);
    const slaHours = urows.length ? Number(urows[0].sla_hours) : 24;
    const [crow] = await conn.query('SELECT range_min, range_max FROM categories WHERE code = ?', [b.cat]);
    const range = crow.length ? [crow[0].range_min, crow[0].range_max] : [0, 99999999];
    const budgetN = Number(b.budget) || 0;

    /* Budget rule: a stated budget is a hard ceiling — only pros whose
       service charge sits within budget are invited to quote. */
    const [poolRows] = await conn.query(
        "SELECT * FROM pros WHERE verified = 1 AND cat = ?",
        [b.cat]);
    const pool = poolRows.map(proOut).filter(gateKeep).filter(p => !budgetN || (p.price >= range[0] * 0.5 && p.price <= budgetN));
    const dayOk = (p) => !b.date || !(p.blocked || []).includes(b.date);

    let matched, matchTiers;
    if (request.proId) {
        /* Pro-card request: invite only the requested pro (within-budget
           requests land directly on them; anything else falls through to
           the calm no-match path below). */
        const pref = pool.find(p => p.id === request.proId);
        matched = pref ? [pref] : [];
        matchTiers = [];
    } else {
        /* Near-first: fill from the closest distance tier outward so a
           250 km pro is only invited when nobody nearer is available. */
        const baseKm = locationKm(b.location);
        matched = matchNearFirst(pool.filter(dayOk), b.location, 100);
        if (b.urgency === 'urgent') {
            const em = matched.filter(p => p.emergency);
            if (em.length >= 1) matched = em.concat(matched.filter(p => !p.emergency));
        }
        const maxMatches = await config.num('max_matches', 3);
        matched = matched.slice(0, maxMatches);
        matchTiers = matched.map(p => kmTier(proKm(p, baseKm)));
        /* LTR capture: log the decision — full candidate pool + who was
           shown (best-effort, never alters the invite list). */
        await snapshotMatchEvent(conn, { pool, bookedPros: matched, b });
    }
    const matchedIds = matched.map(p => p.id);
    await conn.query('UPDATE bookings SET sla_hours = ?, matched_pro_ids = ? WHERE id = ?',
        [slaHours, JSON.stringify(matchedIds), b.id]);

    await pushEvent(conn, b.id, matched.length
        ? 'Matched with ' + matched.length + ' verified pro' + (matched.length > 1 ? 's' : '') + ' — quotes requested (SLA ' + (slaHours < 1 ? '30 minutes' : slaHours + ' hours') + ').' +
            (matchTiers.includes('far') ? ' Note: no closer pro was available for this request, so a pro from outside your area is included.' : '')
        : 'No verified pro available within a ' + cedi(budgetN) + ' budget right now. Your request is saved (Ref ' + b.id + ') \u2014 our team will search manually and reach out, or you can raise your budget on the Track page to widen the match.', now);
    if (!matched.length && budgetN > 0) {
        await notify(conn, 'customer', b.id, 'booking', 'Booking ' + b.id + ': no verified pro matched your ' + cedi(budgetN) + ' budget yet. Our team has your request for manual search \u2014 we will reach out shortly. You can also raise your budget on the Track page to see more pros.');
        await notify(conn, 'admin', b.id, 'booking', 'Manual search needed: ' + b.id + ' (' + (await catLabelOf(conn, b.cat)) + ', ' + cedi(budgetN) + ' budget) matched no verified pro \u2014 assign one or contact the customer.');
    }

    /* simulated quotes (sandbox behaviour; gated by sandbox_mode at go-live) */
    if (await sandboxMode()) {
        for (let i = 0; i < matched.length; i++) {
            const p = matched[i];
            const jitter = [1, 1.12, 0.92][i % 3];
            let price = Math.round(p.price * jitter);
            if (!request.proId && budgetN > 0 && price > budgetN) price = budgetN;   /* quotes never exceed the customer's budget (direct pro requests keep the pro's real rate) */
            await addQuoteInternal(conn, b.id, p.id, price, (b.urgency === 'urgent' ? 10 : 25 + i * 35) * 60000, p.name);
        }
    }

    await notify(conn, 'customer', b.id, 'booking', 'Booking ' + b.id + ': ' + matchedIds.length + ' pros invited to quote. Track it on the Track Booking page.');
    const catLabel = await catLabelOf(conn, b.cat);
    await notify(conn, 'admin', b.id, 'booking', 'New ' + (b.urgency === 'urgent' ? 'EMERGENCY ' : '') + 'booking ' + b.id + ' \u2014 ' + catLabel + ' in ' + b.location);
    return refreshBooking(conn, b.id);
}

/* Re-read a booking with its events + escrow inlined. */
async function refreshBooking(conn, id) {
    const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ?', [id]);
    if (!brows.length) return null;
    const events = await eventsFor(conn, id);
    const esc = await escrowFor(conn, id);
    return bookingOut(brows[0], events, esc);
}

async function getBooking(id) {
    return db.tx(async (conn) => refreshBooking(conn, id));
}

/* Identity = last 9 digits of the phone (spaces/dashes ignored). */
async function getBookingsFor(phone) {
    const p = String(phone || '').replace(/[\s-]/g, '');
    if (!p) return [];
    const key = p.slice(-9);
    const [rows] = await db.q(
        'SELECT b.*, (RIGHT(REPLACE(REPLACE(b.customer_phone, " ", ""), "-", ""), 9) = ?) AS is_match FROM bookings b ORDER BY b.created_at DESC, b.id DESC',
        [key]);
    const out = [];
    for (const r of rows) {
        if (!r.is_match) continue;
        out.push(await refreshBooking(db.get(), r.id));
    }
    return out;
}

async function getQuotesFor(bookingId) {
    const [rows] = await db.q("SELECT * FROM quotes WHERE booking_id = ? AND status != 'expired' ORDER BY created_at, id", [bookingId]);
    return rows.map(quoteOut);
}

async function acceptQuote(quoteId) {
    return db.tx(async (conn) => {
        const [qrows] = await conn.query('SELECT * FROM quotes WHERE id = ? FOR UPDATE', [quoteId]);
        const qt = qrows[0];
        if (!qt || qt.status !== 'sent') return null;
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [qt.booking_id]);
        const booking = brows[0];
        const [prows] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [qt.pro_id]);
        const pro = prows[0];
        if (!booking || !pro) return null;

        await conn.query("UPDATE quotes SET status = 'accepted' WHERE id = ?", [qt.id]);
        await conn.query("UPDATE quotes SET status = 'declined' WHERE booking_id = ? AND id != ? AND status = 'sent'", [qt.booking_id, qt.id]);
        await conn.query('UPDATE bookings SET chosen_pro_id = ?, amount = ?, status = ? WHERE id = ?',
            [pro.id, qt.price, 'booked', qt.booking_id]);
        /* LTR outcome: which candidate won (the reward anchor for training). */
        await matchLog.updateOutcomeInTx(conn, qt.booking_id, { acceptedProId: pro.id, acceptedAmount: Number(qt.price) });
        await pushEvent(conn, qt.booking_id, 'Quote accepted \u2014 ' + pro.name + ' booked for ' + cedi(qt.price) + '. Awaiting escrow payment.');
        const catLabel = await catLabelOf(conn, booking.cat);
        const dateTxt = booking.event_date ? await fmtDateOf(booking.event_date) : 'flexible date';
        await notify(conn, 'pro', pro.id, 'job', 'BOOKED! ' + booking.id + ' \u2014 ' + catLabel + ' on ' + dateTxt + ' in ' + booking.location + '. ' + cedi(qt.price) + ' (escrow)');
        await notify(conn, 'admin', booking.id, 'booking', 'Quote ' + qt.id + ' accepted on ' + booking.id + ' by ' + pro.name);
        return quoteOut(Object.assign({}, qt, { status: 'accepted' }));
    });
}

async function setBookingStatus(bookingId, status, eventText) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT id FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        if (!brows.length) return null;
        await conn.query('UPDATE bookings SET status = ? WHERE id = ?', [status, bookingId]);
        if (eventText) await pushEvent(conn, bookingId, eventText);
        return refreshBooking(conn, bookingId);
    });
}

/* ---------- cancellation analytics (admin Overview) ---------- */

async function cancellationSummary() {
    const [rows] = await db.q("SELECT * FROM bookings WHERE status = 'cancelled' ORDER BY created_at DESC");
    const out = [];
    for (const b of rows) {
        const events = await eventsFor(db.get(), b.id);
        const cancels = events.filter(e => String(e.text || '').indexOf('Cancelled by customer') === 0);
        const last = cancels[cancels.length - 1] || null;
        if (!last) continue;
        const m = String(last.text || '').match(/^Cancelled by customer(?: \u2014 "([^"]*)")?/);
        const dm = String(last.text || '').match(/(\d+) pending quote\(s\) declined/);
        const rebook = events.map(e => String(e.text || '').match(/rebooked this request as (SC-BK-\d+)/i)).filter(Boolean);
        const [qrows] = await db.q('SELECT id FROM quotes WHERE booking_id = ? LIMIT 1', [b.id]);
        out.push({
            ref: b.id, cat: b.cat, location: b.location, budget: b.budget === null ? 0 : Number(b.budget),
            reason: (m && m[1]) ? m[1].trim() : '',
            hadQuotes: qrows.length > 0,
            quotesDeclined: dm ? Number(dm[1]) : 0,
            cancelledAt: Number(last.at),
            rebookedAs: rebook.length ? rebook[rebook.length - 1][1] : null
        });
    }
    return out.sort((a, b) => b.cancelledAt - a.cancelledAt).slice(0, 8);
}

async function fmtDateOf(iso) {
    return new Date(iso + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

/* ---------- cancellation (pre-booking only) ---------- */

async function cancelBooking(bookingId, reason) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        if (!b) return { ok: false, error: 'Booking not found.' };
        if (!['matching', 'quoted'].includes(b.status)) {
            const [erows] = await conn.query('SELECT released FROM escrow WHERE booking_id = ?', [bookingId]);
            const funded = erows.length && !erows[0].released;
            return { ok: false, error: 'This request is already booked' + (funded ? ' and paid into escrow' : '') + ' \u2014 open it on the tracking page to manage it there.' };
        }
        let notifiedPros = 0;
        const [qrows] = await conn.query("SELECT * FROM quotes WHERE booking_id = ? AND status = 'sent' FOR UPDATE", [bookingId]);
        for (const qt of qrows) {
            await conn.query("UPDATE quotes SET status = 'declined' WHERE id = ?", [qt.id]);
            await notify(conn, 'pro', qt.pro_id, 'booking', 'Request ' + bookingId + ' was cancelled by the customer before booking \u2014 no action needed.');
            notifiedPros++;
        }
        await conn.query("UPDATE bookings SET status = 'cancelled' WHERE id = ?", [bookingId]);
        /* LTR outcome: the request died before booking (negative signal for
           every candidate — none of them converted). */
        await matchLog.updateOutcomeInTx(conn, bookingId, { cancelled: true });
        await pushEvent(conn, bookingId, 'Cancelled by customer' + (reason ? ' \u2014 "' + reason + '"' : '') + (notifiedPros ? '. ' + notifiedPros + ' pending quote(s) declined.' : ''));
        await notify(conn, 'customer', bookingId, 'booking', 'Booking ' + bookingId + ' cancelled. You can post a new request any time.');
        const catLabel = await catLabelOf(conn, b.cat);
        await notify(conn, 'admin', bookingId, 'booking', 'Customer cancelled ' + bookingId + ' (' + catLabel + ', ' + b.location + ')' + (reason ? ': ' + reason : '') + '.');
        return { ok: true, declinedQuotes: notifiedPros };
    });
}

/* ---------- learning-to-rank capture (LTR-1) ----------
   Snapshot the FULL pre-slice candidate pool with per-candidate match-time
   features and mark who was actually invited (`shown`, with position).
   Pure capture — it must never alter what the matcher invites. For direct
   proId requests (pro-card flow, no ranking happens) no event is logged.
   pool: the filtered candidate pool the matcher ranked; bookedPros: the
   finally-invited proOut list; b: booking shape; excludeId: disputed pro
   in the rematch path (kept as a logged candidate with exclude flag). */
async function snapshotMatchEvent(conn, { pool, bookedPros, b, excludeId, baseKmOverride }) {
    try {
        if (!pool || !pool.length) return;   /* empty pool ⇒ no decision to learn from */
        const baseKm = baseKmOverride !== undefined ? baseKmOverride : locationKm(b.location);
        const dateIso = b.date || (b.event_date || '') || '';
        const candidates = pool
            .map(p => {
                const f = matchLog.candidateFeatures(p, proKm(p, baseKm), dateIso, b.location);
                if (excludeId === p.id) f.excluded = true;   /* disputed pro kept visible with a flag */
                /* ID-gate stage is exported as a feature so a future model
                   can learn the gate boundary instead of it being a silent
                   pre-filter outside the log. */
                const gate = idGateSync(p);
                f.gateStage = gate.stage;
                f.graceDaysLeft = gate.graceDaysLeft === undefined ? null : gate.graceDaysLeft;
                return f;
            });
        const shown = (bookedPros || [])
            .map((p, i) => ({ proId: p.id, position: i }));
        await matchLog.recordMatchEventInTx(conn, {
            bookingId: b.id, cat: b.cat, location: b.location, baseKm,
            urgency: b.urgency, budget: b.budget, date: dateIso,
            candidates, shown
        });
    } catch (e) {
        /* Logging is observability, not business flow — never fail a booking. */
        console.error('[match-log] snapshot failed (non-fatal):', e && e.message || e);
    }
}

/* ---------- budget raise → fresh match run (customer action on the track page) ---------- */

async function updateBookingBudget(bookingId, newBudget) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        if (!b) return { ok: false, error: 'Booking not found.' };
        if (!['matching', 'quoted'].includes(b.status)) {
            return { ok: false, error: 'Only requests that are not yet booked can be re-matched — open it on the tracking page to manage it there.' };
        }
        const nb = Number(newBudget);
        if (!nb || nb <= 0) return { ok: false, error: 'Enter a valid budget amount.' };
        const oldBudget = Number(b.budget) || 0;
        if (oldBudget && nb <= oldBudget) {
            return { ok: false, error: 'Raise your budget above ' + cedi(oldBudget) + ' to widen the match — lowering it would narrow, not widen, the search.' };
        }
        await conn.query('UPDATE bookings SET budget = ? WHERE id = ?', [nb, bookingId]);

        /* Re-run the match pool with the new ceiling. Pros already invited stay
           invited (any quote they sent remains valid); only newcomers get fresh
           simulated quotes. */
        const [crow] = await conn.query('SELECT range_min, range_max FROM categories WHERE code = ?', [b.cat]);
        const range = crow.length ? [crow[0].range_min, crow[0].range_max] : [0, 99999999];
        const [poolRows] = await conn.query('SELECT * FROM pros WHERE verified = 1 AND cat = ?', [b.cat]);
        const pool = poolRows.map(proOut).filter(gateKeep).filter(p => p.price >= range[0] * 0.5 && p.price <= nb);
        const dayOk = (p) => !b.event_date || !(p.blocked || []).includes(b.event_date);

        /* Same near-first fill as createBooking (pros already invited stay
           invited; the list may still grow or shift within the cap). */
        let matched = matchNearFirst(pool.filter(dayOk), b.location, 100);
        if (b.urgency === 'urgent') {
            const em = matched.filter(p => p.emergency);
            if (em.length >= 1) matched = em.concat(matched.filter(p => !p.emergency));
        }
        const maxMatches = await config.num('max_matches', 3);
        matched = matched.slice(0, maxMatches);
        /* LTR capture: a budget raise is its own matching decision — logged
           separately with the NEW ceiling (best-effort, never alters flow). */
        await snapshotMatchEvent(conn, {
            pool, bookedPros: matched,
            b: { id: b.id, cat: b.cat, location: b.location, urgency: b.urgency, budget: nb, date: b.event_date || '' }
        });
        const prevIds = JSON.parse(b.matched_pro_ids || '[]');
        const matchedIds = matched.map(p => p.id);
        await conn.query('UPDATE bookings SET matched_pro_ids = ? WHERE id = ?', [JSON.stringify(matchedIds), bookingId]);
        const added = matchedIds.filter(id => !prevIds.includes(id));

        await pushEvent(conn, bookingId, matched.length
            ? 'Budget raised to ' + cedi(nb) + ' — re-matched with ' + matched.length + ' verified pro' + (matched.length > 1 ? 's' : '') + (added.length ? ' (' + added.length + ' new invite' + (added.length > 1 ? 's' : '') + ')' : '') + '. Quotes requested.'
            : 'Budget raised to ' + cedi(nb) + ' — still no verified pro within budget. Our team will search manually and reach out.', Date.now());
        if (matched.length) {
            await notify(conn, 'customer', bookingId, 'booking', 'Booking ' + bookingId + ': budget raised to ' + cedi(nb) + ' — ' + matched.length + ' pro' + (matched.length > 1 ? 's' : '') + ' invited to quote.');
        } else {
            await notify(conn, 'customer', bookingId, 'booking', 'Booking ' + bookingId + ': budget raised to ' + cedi(nb) + ' but no pro matches yet. Our manual search continues.');
        }
        await notify(conn, 'admin', bookingId, 'booking', 'Customer raised budget on ' + bookingId + ' to ' + cedi(nb) + (added.length ? ' — ' + added.length + ' new pro(s) invited.' : ' — no new matches.'));

        /* simulated quotes for newly invited pros only (sandbox behaviour) */
        if (added.length && await sandboxMode()) {
            let i = 0;
            for (const p of matched) {
                if (!added.includes(p.id)) continue;
                const jitter = [1, 1.12, 0.92][i % 3];
                let price = Math.round(p.price * jitter);
                if (price > nb) price = nb;
                await addQuoteInternal(conn, bookingId, p.id, price, (b.urgency === 'urgent' ? 10 : 25 + i * 35) * 60000, p.name);
                i++;
            }
        }
        const booking = await refreshBooking(conn, bookingId);
        return { ok: true, booking, addedCount: added.length };
    });
}

/* ---------- one-tap rebook ---------- */

async function rebookFrom(bookingId) {
    return db.tx(async (conn) => {
        const [orows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const old = orows[0];
        if (!old) return { ok: false, error: 'Booking not found.' };
        if (old.status !== 'cancelled') return { ok: false, error: 'Only cancelled requests can be rebooked.' };
        const nb = await createBookingInTx(conn, {
            name: old.customer_name, phone: old.customer_phone, cat: old.cat, date: old.event_date || '',
            location: old.location, budget: old.budget === null ? '' : Number(old.budget),
            urgency: old.urgency, details: old.details || ''
        });
        if (!nb || !nb.id) return { ok: false, error: 'Could not create the new request \u2014 try again in a moment.' };
        await pushEvent(conn, nb.id, 'Rebooked from ' + old.id + ' \u2014 same request details, fresh matching run.');
        await pushEvent(conn, old.id, 'Customer rebooked this request as ' + nb.id + '.');
        return { ok: true, booking: nb, fromId: old.id };
    });
}

/* ---------- escrow ---------- */

/* ---------- escrow ---------- */

/* fundEscrowInTx — THE escrow state transition (booked → in_progress, escrow
   row, event, notifications). payIntoEscrow (sandbox) and the gateway
   confirm handler (payments.js) both run exactly this; the only input
   difference is where the money reference came from. Returns {ok} or
   {ok:false,error}. Caller owns the transaction and the row lock. */
async function fundEscrowInTx(conn, bookingId, method, txnRef) {
    const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
    const b = brows[0];
    if (!b || b.status !== 'booked' || !Number(b.amount)) return { ok: false, error: 'Booking is not awaiting payment.' };
    const existing = await escrowFor(conn, bookingId);
    if (existing && !existing.released) return { ok: false, error: 'This booking is already funded \u2014 escrow is holding your payment.' };
    const pro = b.chosen_pro_id ? (await proRow(conn, b.chosen_pro_id)) : null;
    if (!pro) return { ok: false, error: 'Chosen professional not found.' };

    const now = Date.now();
    await conn.query('UPDATE bookings SET status = ? WHERE id = ?', ['in_progress', bookingId]);
    await conn.query(
        'INSERT INTO escrow (booking_id, pro_id, method, paid_at, amount, released, txn_ref) VALUES (?, ?, ?, ?, ?, 0, ?)',
        [bookingId, pro.id, method || 'momo', now, b.amount, txnRef]);
    /* LTR outcome: money moved — the strongest intent signal. */
    await matchLog.updateOutcomeInTx(conn, bookingId, { escrowPaid: true, escrowMethod: method || 'momo' });
    await pushEvent(conn, bookingId, 'Payment ' + cedi(b.amount) + ' held in escrow (' + txnRef + '). ' + pro.name + ' notified to start.', now);
    await notify(conn, 'pro', pro.id, 'escrow', 'Escrow funded for ' + bookingId + ' (' + cedi(b.amount) + '). You can start the job \u2014 funds release after customer approval.');
    await notify(conn, 'admin', bookingId, 'escrow', 'Escrow ' + txnRef + ' funded ' + cedi(b.amount) + ' on ' + bookingId);
    return { ok: true, txnRef, booking: await refreshBooking(conn, bookingId) };
}

/* Sandbox path (unchanged behavior): pay now, confirm instantly, money is
   simulated. When a real gateway secret is configured the HTTP layer routes
   customers through payment intents + gateway confirmation instead. */
async function payIntoEscrow(bookingId, method, momoNumber) {
    if (await config.activeGateway()) {
        return { ok: false, error: 'Sandbox payment is disabled \u2014 use the checkout flow (POST /api/payments/initiate).' };
    }
    return db.tx(async (conn) => fundEscrowInTx(conn, bookingId, method, db.escTxnRef()));
}

async function releaseEscrow(bookingId) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        if (!b) return { ok: false, error: 'Nothing to release.' };
        const esc = await escrowFor(conn, bookingId);
        if (!esc || esc.released) return { ok: false, error: 'Nothing to release.' };
        const pro = b.chosen_pro_id ? (await proRow(conn, b.chosen_pro_id)) : null;
        if (!pro) return { ok: false, error: 'Professional not found.' };

        const now = Date.now();
        const amount = Number(b.amount);
        const commissionRate = await config.num('commission_rate', 0.10);
        const commission = Math.round(amount * commissionRate);
        await conn.query('UPDATE escrow SET released = 1, released_at = ? WHERE booking_id = ?', [now, bookingId]);
        await conn.query('UPDATE bookings SET status = ?, paid_at = ?, commission = ? WHERE id = ?', ['completed', now, commission, bookingId]);
        /* LTR outcome: job completed. */
        await matchLog.updateOutcomeInTx(conn, bookingId, { completed: true });
        const net = round2(amount - commission);
        await conn.query('UPDATE pros SET balance = balance + ?, earnings = earnings + ?, commission_paid = commission_paid + ?, bookings_count = bookings_count + 1 WHERE id = ?',
            [net, net, commission, pro.id]);
        await addTxn(conn, 'service_payment', bookingId, pro.id, amount, esc.method, 'Customer payment for ' + bookingId + ' \u2014 ' + pro.name);
        await addTxn(conn, 'commission', bookingId, pro.id, commission, 'platform', 'Platform commission (' + Math.round(commissionRate * 100) + '%) on ' + bookingId);
        await pushEvent(conn, bookingId, 'Job approved. ' + cedi(net) + ' released to ' + pro.name + ' (commission ' + cedi(commission) + ').', now);
        await notify(conn, 'pro', pro.id, 'escrow', cedi(net) + ' released to your wallet from ' + bookingId + '. Rate the customer experience!');
        await notify(conn, 'admin', bookingId, 'escrow', 'Escrow released on ' + bookingId + ' \u2014 commission ' + cedi(commission));
        return { ok: true, booking: await refreshBooking(conn, bookingId), commission };
    });
}

/* ---------- disputes ---------- */

async function openDispute(bookingId, reason, details) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        if (!b) return { ok: false, error: 'Booking not found.' };
        const esc = await escrowFor(conn, bookingId);
        if (!esc || esc.released) return { ok: false, error: 'Escrow already released or never funded \u2014 contact support.' };

        const id = await db.nextRef(conn, 'dispute');
        const now = Date.now();
        await conn.query('INSERT INTO disputes (id, booking_id, reason, details, status, opened_at) VALUES (?, ?, ?, ?, ?, ?)',
            [id, bookingId, reason || 'other', details || '', 'open', now]);
        await conn.query("UPDATE bookings SET status = 'disputed' WHERE id = ?", [bookingId]);
        await pushEvent(conn, bookingId, 'Dispute opened (' + id + '): ' + (reason || 'other') + '. Escrow frozen pending resolution.', now);
        await notify(conn, 'admin', id, 'dispute', 'DISPUTE ' + id + ' on ' + bookingId + ': ' + (reason || 'other'));
        await notify(conn, 'pro', b.chosen_pro_id, 'dispute', 'Dispute opened on ' + bookingId + '. Our resolution team will contact you.');
        return { ok: true, dispute: { id, bookingId, reason: reason || 'other', details: details || '', status: 'open', openedAt: now } };
    });
}

async function getDisputes() {
    const [rows] = await db.q('SELECT * FROM disputes ORDER BY opened_at DESC, id DESC');
    return rows.map(disputeOut);
}

async function resolveDispute(disputeId, resolution, note) {
    return db.tx(async (conn) => {
        const [drows] = await conn.query('SELECT * FROM disputes WHERE id = ? FOR UPDATE', [disputeId]);
        const ds = drows[0];
        if (!ds || ds.status !== 'open') return null;
        const now = Date.now();
        await conn.query('UPDATE disputes SET status = ?, resolved_at = ?, note = ? WHERE id = ?',
            [resolution, now, note || '', disputeId]);
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [ds.booking_id]);
        const b = brows[0];
        if (b) {
            if (resolution === 'resolved_refund') {
                await conn.query('UPDATE escrow SET released = 1, released_at = ? WHERE booking_id = ?', [now, b.id]);
                await conn.query("UPDATE bookings SET status = 'cancelled' WHERE id = ?", [b.id]);
                await pushEvent(conn, b.id, 'Dispute resolved: REFUND to customer. ' + (note || ''), now);
                await notify(conn, 'customer', b.id, 'dispute', 'Your dispute was resolved with a full refund.');
            } else if (resolution === 'resolved_rematch') {
                /* Escrow stays HELD — transfers to the replacement pro on pick. */
                const disputedProId = b.chosen_pro_id;
                await conn.query('UPDATE bookings SET status = ?, chosen_pro_id = NULL, rematch_pick = 1, rematch_exclude = ?, matched_pro_ids = ? WHERE id = ?',
                    ['matching', disputedProId || null, JSON.stringify([]), b.id]);
                const [pool] = await conn.query(
                    'SELECT * FROM pros WHERE verified = 1 AND cat = ? AND id != ? FOR UPDATE',
                    [b.cat, disputedProId || '']);
                let fresh = matchNearFirst(
                    pool.map(proOut).filter(gateKeep).filter(p => !(p.blocked || []).includes(b.event_date || '')),
                    b.location, await config.num('max_matches', 3));
                await conn.query('UPDATE bookings SET matched_pro_ids = ? WHERE id = ?', [JSON.stringify(fresh.map(p => p.id)), b.id]);
                /* LTR capture: a dispute rematch is a matching decision too —
                   logged as its own event (candidate pool + replacement picks). */
                await snapshotMatchEvent(conn, {
                    pool: pool.map(proOut).filter(gateKeep).filter(p => !(p.blocked || []).includes(b.event_date || '')),
                    bookedPros: fresh,
                    b: { id: b.id, cat: b.cat, location: b.location, urgency: b.urgency, budget: b.budget, date: b.event_date || '' },
                    excludeId: disputedProId || null
                });
                for (let i = 0; i < fresh.length; i++) {
                    await addQuoteInternal(conn, b.id, fresh[i].id, Math.round(Number(fresh[i].price) * [1, 1.1, 0.94][i % 3]), (20 + i * 30) * 60000, fresh[i].name);
                }
                await pushEvent(conn, b.id, 'Dispute resolved: REMATCH. ' + fresh.length + ' replacement pros invited \u2014 customer picks from the tracking page.', now);
                await notify(conn, 'customer', b.id, 'dispute', 'Rematch started \u2014 open your booking to pick a replacement pro. Your money stays held in escrow.');
                await notify(conn, 'admin', b.id, 'dispute', 'Rematch for ' + b.id + ' \u2014 waiting for the customer to pick a replacement pro.');
            } else {
                /* resolved_release — pay the pro anyway */
                const esc2 = await escrowFor(conn, b.id);
                if (esc2 && !esc2.released) {
                    const pro = b.chosen_pro_id ? (await proRow(conn, b.chosen_pro_id)) : null;
                    if (pro) {
                        const commissionRate = await config.num('commission_rate', 0.10);
                        const commission = Math.round(Number(b.amount) * commissionRate);
                        const net = round2(Number(b.amount) - commission);
                        await conn.query('UPDATE escrow SET released = 1, released_at = ? WHERE booking_id = ?', [now, b.id]);
                        await conn.query('UPDATE pros SET balance = balance + ?, commission_paid = commission_paid + ?, bookings_count = bookings_count + 1 WHERE id = ?',
                            [net, commission, pro.id]);
                    }
                    await conn.query("UPDATE bookings SET status = 'completed' WHERE id = ?", [b.id]);
                }
                await pushEvent(conn, b.id, 'Dispute resolved: RELEASED to professional. ' + (note || ''), now);
            }
        }
        const [after] = await conn.query('SELECT * FROM disputes WHERE id = ?', [disputeId]);
        return disputeOut(after[0]);
    });
}

/* ---------- rematch pick ---------- */

async function customerRematchOptions(bookingId) {
    const [brows] = await db.q('SELECT * FROM bookings WHERE id = ?', [bookingId]);
    const b = brows[0];
    if (!b || !b.rematch_pick || !['matching', 'quoted'].includes(b.status)) return [];
    const quoted = {};
    const [qrows] = await db.q("SELECT pro_id, price FROM quotes WHERE booking_id = ? AND status = 'sent'", [bookingId]);
    for (const q of qrows) quoted[q.pro_id] = Number(q.price);
    const [pool] = await db.q('SELECT * FROM pros WHERE verified = 1 AND cat = ? AND id != ?', [b.cat, b.rematch_exclude || '']);
    return pool.map(proOut)
        .filter(gateKeep)
        .filter(p => !(p.blocked || []).includes(b.event_date || ''))
        .map(p => ({ id: p.id, name: p.name, city: p.city, rating: p.rating, ratingCount: p.ratingCount || 0, price: quoted[p.id] || p.price, quoted: !!quoted[p.id] }))
        .sort((x, y) => (y.rating - x.rating) || (y.ratingCount - x.ratingCount))
        .slice(0, 6);
}

async function customerRematchPick(bookingId, proId) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        const p = proId ? (await proRow(conn, proId)) : null;
        if (!b || !p) return { ok: false, error: 'Booking or professional not found.' };
        if (!b.rematch_pick || !['matching', 'quoted'].includes(b.status)) return { ok: false, error: 'This booking is not waiting for a rematch pick.' };
        if (proId === b.rematch_exclude) return { ok: false, error: 'That is the disputed professional \u2014 please pick someone else.' };
        if ((p.blocked || []).includes(b.event_date || '')) return { ok: false, error: p.name + ' is not free on ' + (b.event_date || 'the chosen date') + '.' };
        const r = await reassignBookingInTx(conn, bookingId, proId);
        if (!r.ok) return r;
        await conn.query('UPDATE bookings SET rematch_pick = 0, status = ? WHERE id = ?', ['in_progress', bookingId]);
        await pushEvent(conn, bookingId, 'Customer picked ' + p.name + ' as the replacement \u2014 escrow transferred, no re-payment needed.');
        return { ok: true, booking: await refreshBooking(conn, bookingId), pro: { id: p.id, name: p.name } };
    });
}

/* ---------- pro dashboard ---------- */

async function proBookings(proId) {
    const [rows] = await db.q(
        'SELECT b.id FROM bookings b ORDER BY b.created_at DESC, b.id DESC');
    const out = [];
    for (const r of rows) {
        const [brows] = await db.q('SELECT * FROM bookings WHERE id = ?', [r.id]);
        const b = brows[0];
        const ids = b.matched_pro_ids || [];
        if (!ids.includes(proId) && b.chosen_pro_id !== proId) continue;
        const [qrows] = await db.q('SELECT * FROM quotes WHERE booking_id = ? AND pro_id = ? ORDER BY created_at DESC LIMIT 1', [b.id, proId]);
        out.push({ booking: bookingOut(b, await eventsFor(db.get(), b.id), await escrowFor(db.get(), b.id)), quote: qrows.length ? quoteOut(qrows[0]) : null });
    }
    return out;
}

async function proRespondQuote(quoteId, action, price, message) {
    return db.tx(async (conn) => {
        const [qrows] = await conn.query('SELECT * FROM quotes WHERE id = ? FOR UPDATE', [quoteId]);
        if (!qrows.length) return null;
        const qt = qrows[0];
        if (action === 'decline') {
            await conn.query("UPDATE quotes SET status = 'declined', responded_at = ? WHERE id = ?", [Date.now(), quoteId]);
        } else {
            await conn.query('UPDATE quotes SET price = COALESCE(?, price), message = COALESCE(?, message), status = ?, responded_at = ? WHERE id = ?',
                [price === undefined || price === null || price === '' ? null : Number(price),
                 message || null, 'sent', Date.now(), quoteId]);
        }
        const [after] = await conn.query('SELECT * FROM quotes WHERE id = ?', [quoteId]);
        return quoteOut(after[0]);
    });
}

async function toggleProDate(proId, isoDate) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p || !isoDate) return proOut(p);
        const blocked = p.blocked || [];
        const i = blocked.indexOf(isoDate);
        if (i === -1) blocked.push(isoDate); else blocked.splice(i, 1);
        await conn.query('UPDATE pros SET blocked = ? WHERE id = ?', [JSON.stringify(blocked), proId]);
        p.blocked = blocked;
        return proOut(p);
    });
}

async function updateProProfile(proId, patch) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p) return null;
        const map = { name: 'name', short: 'short_name', cat: 'cat', role: 'role', city: 'city', price: 'price', unit: 'unit', note: 'note', phone: 'phone', emergency: 'emergency', response: 'response', years: 'years', languages: 'languages', desc: 'description', contactChannels: 'contact_channels' };
        const sets = [], params = [];
        for (const k of Object.keys(patch || {})) {
            const col = map[k];
            if (!col) continue;
            let v = patch[k];
            if (k === 'languages') v = JSON.stringify(v || []);
            if (k === 'emergency') v = v ? 1 : 0;
            if (k === 'contactChannels') { v = ['sms', 'whatsapp', 'both'].includes(String(v)) ? String(v) : 'both'; }
            if (k === 'price') v = Number(v) || 0;
            sets.push(col + ' = ?'); params.push(v);
        }
        if (sets.length) {
            params.push(proId);
            await conn.query('UPDATE pros SET ' + sets.join(', ') + ' WHERE id = ?', params);
        }
        return proOut(await proRow(conn, proId));
    });
}

/* ---------- ID re-verification (Ghana Card; validity length is the
   admin-editable id_valid_years setting) ---------- */

async function idWindows() {
    return {
        validMs: (await config.num('id_valid_years', 5)) * 365.25 * 86400000,
        warnMs: (await config.num('id_warn_days', 60)) * 86400000
    };
}

function idStatusSync(p) {
    if (!p) return { state: 'missing', label: 'No documents' };
    if (p.idReverify === 'pending') return { state: 'pending', label: 'New docs under review' };
    if (p.idReverify === 'flagged') return { state: 'flagged', label: 'Docs requested' };
    if (!p.idDocsReceived) return { state: 'missing', label: 'No documents on file' };
    const ref = p.idVerifiedAt || 0;
    if (!ref) return { state: 'verified', label: 'Verified' };
    const age = Date.now() - ref;
    if (age >= ID_W.validMs) return { state: 'expired', label: 'ID expired', stage: 'expired', expiredDays: Math.max(1, Math.floor((age - ID_W.validMs) / 86400000)) };
    if (age >= ID_W.validMs - ID_W.warnMs) return { state: 'expiring', label: 'Expiring soon', daysLeft: Math.max(1, Math.floor((ID_W.validMs - age) / 86400000)) };
    return { state: 'verified', label: 'Verified' };
}
let ID_W = { validMs: 5 * 365.25 * 86400000, warnMs: 60 * 86400000 };   /* refreshed lazily by idStatus */

async function idStatus(pro) {
    ID_W = await idWindows();
    return idStatusSync(pro);
}

/* ---------- staged ID-renewal enforcement ----------
   An expired Ghana Card alone never touches a pro's money or live jobs.
   Enforcement is minimal and reversible:
     expired        (T+0)   matched everywhere; flagged on the public profile
     delisted       (T+grace, default 14d) excluded from NEW matching only —
                    existing quotes/bookings/escrow continue untouched
   Recovery is one click: approveReverify (or an admin time-override)
   instantly restores full listing. Admins can also OVERRIDE the clock
   per pro (id_gate_until) for edge cases like delayed NIA renewals. */

let ID_GATE = { softDays: 14 };   /* refreshed lazily by idGateWindows */

async function idGateWindows() {
    ID_GATE = {
        softDays: await config.num('id_grace_days', 14)
    };
    return ID_GATE;
}

/* Pure stage computation (sync): where is this pro on the enforcement ladder? */
function idGateSync(p) {
    const st = idStatusSync(p);
    if (st.state !== 'expired') return { stage: st.state };
    const expDays = st.expiredDays || 0;
    const overrideLeft = p.idGateUntil || p.id_gate_until
        ? Math.ceil((Number(p.idGateUntil || p.id_gate_until) - Date.now()) / 86400000)
        : 0;
    if (overrideLeft > 0) return { stage: 'expired', expiredDays: expDays, overrideDaysLeft: overrideLeft };
    if (expDays < ID_GATE.softDays) return { stage: 'expired', expiredDays: expDays, graceDaysLeft: ID_GATE.softDays - expDays, notify: false };
    return { stage: 'delisted', expiredDays: expDays, delistDays: expDays - ID_GATE.softDays, notify: expDays === ID_GATE.softDays };
}

/* Async wrapper that refreshes the settings cache first. */
async function idGate(pro) {
    ID_W = await idWindows();
    await idGateWindows();
    return idGateSync(pro);
}

/* Pool predicate: TRUE keeps the pro. Delisted pros are excluded from NEW
   matching only; everything else (expired-in-grace included) stays in.
   When `opts` carries `logGate: true` the result is instead annotated:
   TRUE stays TRUE (the caller has already filtered), and the symbol marks
   which pros the ID gate WOULD hide — the LTR log exports this so a future
   model learns the gate boundary as a feature rather than a silent filter. */
function gateKeep(p) {
    return idGateSync(p).stage !== 'delisted';
}

/* Lazy escalation sweep (called from boot, /api/health and an hourly
   interval). Computes the stage for every verified pro and fires the
   stage-transition notifications exactly once — idempotent by design,
   no cron dependency. Throttled to at most one run per minute; callers
   pass force=true to bypass the throttle (boot). */
let idGateSweepAt = 0;
let gateSweeperStarted = false;
async function idGateSweep(force) {
    if (!force && Date.now() - idGateSweepAt < 55000) return;
    idGateSweepAt = Date.now();
    const [rows] = await db.q('SELECT * FROM pros WHERE verified = 1');
    ID_W = await idWindows();
    await idGateWindows();
    for (const r of rows) {
        const p = proOut(r);
        const g = idGateSync(p);
        if (g.stage !== 'delisted') continue;
        /* Notify once per stage transition (first observation of the stage) —
           survives restarts and missed boundary days via id_gate_notified. */
        if (r.id_gate_notified === 'delisted') continue;
        await notify(null, 'pro', p.id, 'id_gate', 'ACTION NEEDED: your Ghana Card has been expired for ' + g.expiredDays + ' days and you are now hidden from NEW customer requests. Existing jobs and your wallet are NOT affected — upload fresh FRONT & BACK card photos in your Pro Dashboard (Identity Check) to be relisted immediately.');
        await notify(null, 'admin', p.id, 'application', 'ID GATE: ' + p.name + ' (' + p.id + ') delisted from new matches — expired ' + g.expiredDays + 'd, past the ' + ID_GATE.softDays + '-day grace. Hidden from new bookings until they re-verify.');
        await db.q('UPDATE pros SET id_gate_notified = ? WHERE id = ?', ['delisted', p.id]);
    }
}
function startIdGateSweeper() {
    if (gateSweeperStarted) return;
    gateSweeperStarted = true;
    setInterval(() => { idGateSweep(true).catch(e => console.error('[id-gate]', e && e.message || e)); }, 60 * 60 * 1000).unref();
}

/* Admin override: pause the enforcement clock for N days (edge cases like
   delayed NIA card renewals). days=0 or negative clears the override.
   Clearing the override also resets the notified-stage marker so the sweep
   re-announces the current stage; granting one only clears a stale marker. */
async function setIdGateOverride(proId, days) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p) return { ok: false, error: 'Pro not found.' };
        const n = Math.max(0, Math.min(365, Math.floor(Number(days) || 0)));
        await conn.query('UPDATE pros SET id_gate_until = ?, id_gate_notified = NULL WHERE id = ?',
            [n > 0 ? Date.now() + n * 86400000 : null, proId]);
        if (n > 0) {
            await notify(conn, 'pro', proId, 'application', 'Good news: SkillConnect has extended your ID re-verification window by ' + n + ' day' + (n === 1 ? '' : 's') + ' — you remain fully listed while you complete your renewal.');
            await notify(conn, 'admin', proId, 'application', 'ID gate override: ' + p.name + ' (' + proId + ') exempt from delisting for ' + n + ' more day(s).');
        }
        const after = proOut((await proRow(conn, proId)));   /* camelCase for idGate */
        return { ok: true, proId: proId, overrideDays: n, gate: await idGate(after) };
    });
}

async function requestIdDocs(proId) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p) return { ok: false, error: 'Pro not found.' };
        if (p.id_reverify === 'flagged') return { ok: false, error: 'Documents already requested from this pro.' };
        await conn.query("UPDATE pros SET id_reverify = 'flagged' WHERE id = ?", [proId]);
        await notify(conn, 'pro', proId, 'id_gate', 'ACTION NEEDED: your Ghana Card on file has expired (or is expiring). Upload fresh FRONT & BACK photos in your Pro Dashboard under Identity Check. After a ' + ID_GATE.softDays + '-day grace period an expired card hides you from new customer requests — uploading sooner keeps you fully listed.');
        await notify(conn, 'admin', proId, 'application', 'Documents requested from ' + p.name + ' (' + proId + '). Waiting for their re-upload.');
        return { ok: true, pro: proOut(await proRow(conn, proId)) };
    });
}

async function submitReverify(proId, frontData, backData) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p) return { ok: false, error: 'Pro not found.' };
        if (!frontData || !backData || !frontData.startsWith('data:image') || !backData.startsWith('data:image'))
            return { ok: false, error: 'Please attach both the FRONT and BACK photos of your card.' };
        if (frontData.length > 150000 || backData.length > 150000)
            return { ok: false, error: 'One of the photos is too large after compression — try a smaller file.' };
        await conn.query('UPDATE pros SET id_front_data = ?, id_back_data = ?, id_front_name = ?, id_back_name = ?, id_docs_received = 1, id_reverify = ?, id_submitted_at = ? WHERE id = ?',
            [frontData, backData, 'reupload-front.jpg', 'reupload-back.jpg', 'pending', Date.now(), proId]);
        await notify(conn, 'pro', proId, 'application', 'New Ghana Card photos received — our team will verify them shortly.');
        await notify(conn, 'admin', proId, 'application', 'RE-VERIFICATION: ' + p.name + ' (' + proId + ') uploaded new ID documents. Approve in the Workers tab.');
        return { ok: true };
    });
}

async function approveReverify(proId) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p) return { ok: false, error: 'Pro not found.' };
        await conn.query('UPDATE pros SET id_verified_at = ?, id_reverify = ?, id_submitted_at = NULL, id_gate_until = NULL, id_gate_notified = NULL WHERE id = ?', [Date.now(), '', proId]);
        await notify(conn, 'pro', proId, 'application', 'Your renewed Ghana Card is verified — you are fully listed again. Next renewal in 5 years.');
        await notify(conn, 'admin', proId, 'application', 'Re-verification approved for ' + p.name + ' (' + proId + ').');
        return { ok: true };
    });
}

/* ---------- payouts (wallet decrement + admin notify; request queue has
   no writer in the sandbox either — known quirk preserved) ---------- */

/* ---------- payouts (controlled withdrawal workflow) ----------
   Money NEVER leaves a wallet at request time. Flow:
     pro: payoutPro/requestPayout → payout_requests row (status 'pending')
          pending amounts stay claimable until a batch pays them
     admin: approvePayouts → 'approved' | rejectPayout → 'rejected'
          createPayoutBatch → groups requests into a payout_batches row
          processPayoutBatch → THE single money move: wallet deductions,
          ledger txns and status='paid', all in one transaction
   payoutPro keeps its historical name/signature (ussd.html + dashboard
   call it) but now creates a request instead of debiting the wallet. */
const PAYOUT_MIN = 20;   /* GH₵ minimum withdrawal */

async function pendingPayoutSum(conn, proId) {
    const [rows] = await conn.query(
        "SELECT COALESCE(SUM(amount), 0) AS s FROM payout_requests WHERE pro_id = ? AND status IN ('pending','approved')",
        [proId]);
    return Number(rows[0].s || 0);
}

async function requestPayout(proId, amount) {
    return db.tx(async (conn) => {
        const pro = await proRow(conn, proId);
        if (!pro) return { ok: false, error: 'Pro not found.' };
        amount = Number(amount);
        if (!amount || amount <= 0) return { ok: false, error: 'Enter a valid amount.' };
        if (amount < PAYOUT_MIN) return { ok: false, error: 'Minimum withdrawal is ' + cedi(PAYOUT_MIN) + '.' };
        const pending = await pendingPayoutSum(conn, proId);
        if (pending + amount > Number(pro.balance)) {
            return { ok: false, error: 'Amount exceeds your available balance. ' + (pending > 0 ? cedi(pending) + ' is already reserved by pending request(s) — ' : '') + 'available: ' + cedi(Number(pro.balance) - pending) + '.' };
        }
        const id = await db.nextRef(conn, 'payout');
        const now = Date.now();
        await conn.query(
            "INSERT INTO payout_requests (id, pro_id, amount, method, status, requested_at) VALUES (?, ?, ?, 'momo', 'pending', ?)",
            [id, proId, amount, now]);
        await notify(conn, 'admin', proId, 'payout', 'Withdrawal request ' + id + ': ' + cedi(amount) + ' to ' + pro.name + ' (MoMo ' + (pro.phone || 'n/a') + ') — awaiting approval.');
        return { ok: true, requestId: id, amount, pendingAmount: amount, availableBalance: round2(Number(pro.balance) - pending - amount) };
    });
}

/* Historical name kept — ussd.html and dashboard.html call payoutPro. */
const payoutPro = requestPayout;

async function cancelPayout(proId, requestId) {
    return db.tx(async (conn) => {
        const [rows] = await conn.query('SELECT * FROM payout_requests WHERE id = ? FOR UPDATE', [requestId]);
        const r = rows[0];
        if (!r || r.pro_id !== proId) return { ok: false, error: 'Withdrawal request not found.' };
        if (r.status !== 'pending' || r.batch_id) return { ok: false, error: 'Only requests that are still pending and not yet batched can be cancelled — contact support.' };
        await conn.query("UPDATE payout_requests SET status = 'cancelled', processed_at = ?, processed_by = 'pro-cancelled' WHERE id = ?", [Date.now(), requestId]);
        return { ok: true, requestId };
    });
}

async function myPayouts(proId) {
    const [rows] = await db.q('SELECT * FROM payout_requests WHERE pro_id = ? ORDER BY requested_at DESC, id DESC', [proId]);
    return rows.map(r => ({
        id: r.id, proId: r.pro_id, amount: Number(r.amount), method: r.method, status: r.status,
        batchId: r.batch_id || undefined,
        requestedAt: Number(r.requested_at),
        processedAt: r.processed_at ? Number(r.processed_at) : undefined,
        note: r.processed_by || undefined
    }));
}

async function rejectPayout(requestId, note) {
    return db.tx(async (conn) => {
        const [rows] = await conn.query('SELECT * FROM payout_requests WHERE id = ? FOR UPDATE', [requestId]);
        const r = rows[0];
        if (!r) return { ok: false, error: 'Withdrawal request not found.' };
        if (r.batch_id) return { ok: false, error: 'This request is already in a payout batch — process or rebuild the batch instead.' };
        if (!['pending', 'approved'].includes(r.status)) return { ok: false, error: 'Only pending or approved requests can be rejected.' };
        await conn.query("UPDATE payout_requests SET status = 'rejected', processed_at = ?, processed_by = ? WHERE id = ?", [Date.now(), String(note || 'admin-rejected').slice(0, 40), requestId]);
        await notify(conn, 'pro', r.pro_id, 'payout', 'Withdrawal request ' + r.id + ' (' + cedi(r.amount) + ') was declined. ' + (note ? 'Reason: ' + note : 'Contact support for details.'));
        return { ok: true, requestId };
    });
}

async function approvePayouts(requestIds) {
    const ids = Array.isArray(requestIds) ? requestIds : [requestIds];
    if (!ids.length) return { ok: false, error: 'No requests selected.' };
    return db.tx(async (conn) => {
        let approved = 0;
        for (const id of ids) {
            const [rows] = await conn.query('SELECT * FROM payout_requests WHERE id = ? FOR UPDATE', [String(id)]);
            const r = rows[0];
            if (!r || r.status !== 'pending' || r.batch_id) continue;
            await conn.query("UPDATE payout_requests SET status = 'approved' WHERE id = ?", [r.id]);
            await notify(conn, 'pro', r.pro_id, 'payout', 'Withdrawal request ' + r.id + ' (' + cedi(r.amount) + ') approved — payment is being processed.');
            approved++;
        }
        return { ok: approved > 0, approved, requested: ids.length };
    });
}

async function createPayoutBatch(requestIds, note) {
    const ids = (Array.isArray(requestIds) ? requestIds : [requestIds]).map(String);
    if (!ids.length) return { ok: false, error: 'No requests selected.' };
    return db.tx(async (conn) => {
        const items = [];
        let total = 0;
        for (const id of ids) {
            const [rows] = await conn.query('SELECT * FROM payout_requests WHERE id = ? FOR UPDATE', [id]);
            const r = rows[0];
            if (!r) return { ok: false, error: 'Unknown request ' + id + '.' };
            if (!['pending', 'approved'].includes(r.status) || r.batch_id) {
                return { ok: false, error: 'Request ' + id + ' is not claimable (status: ' + r.status + (r.batch_id ? ', already batched' : '') + ').' };
            }
            const pro = await proRow(conn, r.pro_id);
            if (!pro) return { ok: false, error: 'Professional missing for ' + id + '.' };
            items.push({ r, pro });
            total += Number(r.amount);
        }
        const batchId = await db.nextRef(conn, 'pbatch');
        const now = Date.now();
        await conn.query(
            'INSERT INTO payout_batches (id, item_count, total, status, note, processed_by, processed_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [batchId, items.length, round2(total), 'processing', String(note || '').slice(0, 255) || null, 'admin', now]);
        for (const it of items) {
            await conn.query("UPDATE payout_requests SET status = 'approved', batch_id = ? WHERE id = ?", [batchId, it.r.id]);
            await notify(conn, 'pro', it.r.pro_id, 'payout', 'Withdrawal ' + it.r.id + ' (' + cedi(it.r.amount) + ') approved — payment is being processed.');
        }
        return { ok: true, batchId, count: items.length, total: round2(total), items: items.map(i => i.r.id) };
    });
}

/* processPayoutBatch — the ONLY place wallet money moves for withdrawals.
   Atomic: if any pro's balance cannot cover their request (balance changed
   after the request was filed), the WHOLE batch rolls back and nothing is
   half-paid. Ledger + notifications ride the same transaction. */
async function processPayoutBatch(batchId, note) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM payout_batches WHERE id = ? FOR UPDATE', [batchId]);
        const batch = brows[0];
        if (!batch) return { ok: false, error: 'Payout batch not found.' };
        if (batch.status === 'completed') return { ok: false, error: 'Batch ' + batchId + ' was already completed.' };
        const [reqs] = await conn.query('SELECT * FROM payout_requests WHERE batch_id = ? ORDER BY requested_at, id FOR UPDATE', [batchId]);
        if (!reqs.length) return { ok: false, error: 'Batch has no requests.' };
        /* pre-flight every balance before touching any wallet */
        for (const r of reqs) {
            const [prows] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [r.pro_id]);
            const p = prows[0];
            if (!p) return { ok: false, error: 'Professional ' + r.pro_id + ' missing — batch aborted, nothing was paid.' };
            if (Number(p.balance) < Number(r.amount)) {
                return { ok: false, error: cedi(r.amount) + ' exceeds ' + p.name + '\'s available balance (' + cedi(p.balance) + ') — batch aborted, nothing was paid. Reject the stale request and rebuild the batch.' };
            }
        }
        const now = Date.now();
        let total = 0;
        for (const r of reqs) {
            const [prows] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [r.pro_id]);
            const p = prows[0];
            const newBalance = round2(Number(p.balance) - Number(r.amount));
            await conn.query('UPDATE pros SET balance = ? WHERE id = ?', [newBalance, p.id]);
            await addTxn(conn, 'payout', null, p.id, Number(r.amount), r.method || 'momo', 'Batch payout ' + batchId + ' (' + r.id + ') — ' + p.name);
            await conn.query("UPDATE payout_requests SET status = 'paid', processed_at = ?, processed_by = ? WHERE id = ?", [now, batchId, r.id]);
            await notify(conn, 'pro', p.id, 'payment', cedi(r.amount) + ' paid out (' + batchId + ') via ' + String(r.method || 'momo').toUpperCase() + '. New balance: ' + cedi(newBalance) + '.');
            total += Number(r.amount);
        }
        await conn.query("UPDATE payout_batches SET status = 'completed', processed_at = ?, note = COALESCE(?, note) WHERE id = ?", [now, String(note || '').slice(0, 255) || null, batchId]);
        return { ok: true, batchId, paid: reqs.length, total: round2(total) };
    });
}

async function payoutQueue() {
    const [rows] = await db.q(
        "SELECT pr.*, p.name AS pro_name, p.phone AS pro_phone, p.balance AS pro_balance " +
        "FROM payout_requests pr LEFT JOIN pros p ON p.id = pr.pro_id " +
        "WHERE pr.status IN ('pending','approved') ORDER BY pr.requested_at, pr.id");
    const [batches] = await db.q('SELECT * FROM payout_batches ORDER BY processed_at DESC, id DESC');
    const map = r => ({
        id: r.id, proId: r.pro_id, proName: r.pro_name || r.pro_id, proPhone: r.pro_phone || '',
        proBalance: Number(r.pro_balance || 0), amount: Number(r.amount), method: r.method,
        status: r.status, batchId: r.batch_id || undefined, requestedAt: Number(r.requested_at)
    });
    return {
        pending: rows.filter(r => r.status === 'pending').map(map),
        approved: rows.filter(r => r.status === 'approved').map(map),
        batches: batches.map(b => ({ id: b.id, count: Number(b.item_count), total: Number(b.total), status: b.status, note: b.note || undefined, processedAt: Number(b.processed_at) }))
    };
}

/* ---------- portfolio ---------- */

const PORTFOLIO_CAPTIONS = {
    mc: ['Anchoring a traditional wedding in Accra', 'Corporate awards night stage', 'Outdoor concert crowd control', 'Engagement ceremony programme'],
    artist: ['Live band setup for a wedding', 'Festival main stage performance', 'Church worship concert', 'Acoustic session setup'],
    photographer: ['Traditional wedding portraits', 'Studio headshot session', 'Outdoor engagement shoot', 'Event coverage gallery'],
    videographer: ['Wedding highlight reel frame', 'Corporate promo shoot', 'Drone aerial coverage', 'Multi-cam concert setup'],
    dj: ['Wedding reception setup', 'Club night sound & lights', 'Outdoor stage rig with generator backup', 'Corporate party mixing'],
    caterer: ['Wedding buffet service', 'Chops & cocktails table', 'Full-course plated dinner', 'Birthday cake and dessert bar'],
    decorator: ['Traditional wedding entrance arch', 'Gold & white reception hall', 'Balloon & drapery stage design', 'Outdoor canopy setup'],
    handy: ['Home wiring project', 'AC installation job', 'Custom carpentry fitting', 'Plumbing repair callout']
};

async function getPortfolio(proId) {
    const [rows] = await db.q('SELECT id, cat, portfolio FROM pros WHERE id = ?', [proId]);
    if (!rows.length) return [];
    const portfolio = rows[0].portfolio;
    if (Array.isArray(portfolio) && portfolio.length) return portfolio;
    const caps = PORTFOLIO_CAPTIONS[rows[0].cat] || ['Project sample'];
    return caps.map((c, i) => ({ url: 'https://picsum.photos/seed/' + rows[0].id + '-' + i + '/640/420', caption: c }));
}

const PORTFOLIO_MAX = 8;                 /* UI cap (matches sandbox); URL length from settings */

async function setPortfolio(proId, items) {
    return db.tx(async (conn) => {
        const p = await proRow(conn, proId);
        if (!p) return { ok: false, error: 'Pro not found.' };
        if (!Array.isArray(items)) return { ok: false, error: 'Invalid portfolio data.' };
        if (items.length > PORTFOLIO_MAX) return { ok: false, error: 'Maximum ' + PORTFOLIO_MAX + ' portfolio images.' };
        const maxLen = await config.num('portfolio_url_max_len', 300000);
        for (const it of items) {
            if (!it || typeof it.url !== 'string' || !it.url) return { ok: false, error: 'Each portfolio item needs an image.' };
            if (it.url.length > maxLen) return { ok: false, error: 'One of the images is too large after compression — try a smaller photo.' };
            if (!/^(data:image\/(png|jpe?g|webp);base64,|https:\/\/)/.test(it.url)) return { ok: false, error: 'Images must be PNG, JPG or WebP.' };
            it.caption = String(it.caption || '').slice(0, 80);
        }
        await conn.query('UPDATE pros SET portfolio = ?, has_real_portfolio = ? WHERE id = ?',
            [JSON.stringify(items), items.length > 0 ? 1 : 0, proId]);
        return { ok: true, count: items.length, portfolio: items };
    });
}

/* ---------- availability ---------- */

function proAvailability(pro) {
    const blocked = pro.blocked || [];
    if (blocked.includes(db.todayISO())) return 'booked';
    if (!blocked.length) return 'onrequest';
    return 'available';
}

async function setAvailabilityStatus(proId, status) {
    return db.tx(async (conn) => {
        const pro = await proRow(conn, proId);
        if (!pro) return { ok: false, error: 'Pro not found.' };
        const today = db.todayISO();
        let blocked = (pro.blocked || []).filter(x => x !== today);
        if (status === 'booked' && !blocked.includes(today)) blocked.push(today);
        if (status === 'onrequest') blocked = [];
        await conn.query('UPDATE pros SET blocked = ? WHERE id = ?', [JSON.stringify(blocked), proId]);
        return { ok: true, avail: proAvailability(proOut(Object.assign({}, pro, { blocked }))) };
    });
}

const AVAIL_META = {
    available: { label: 'Available Today', cls: 'avail-available', title: 'Free today — can accept new jobs immediately' },
    booked: { label: 'Booked', cls: 'avail-booked', title: 'Already booked today — check another date' },
    onrequest: { label: 'On Request', cls: 'avail-onrequest', title: 'Calendar not published — send a request to confirm' }
};

/* Date-aware availability: who is blocked on a given ISO date, who is free,
   next date the (optionally specific) pro can take the job. */
async function dateAvailability(opts) {
    const o = opts || {};
    const cat = o.cat || null;
    const date = o.date || null;
    const chosenId = o.proId || null;
    if (!date) return { ok: false, error: 'date required' };

    const [rows] = await db.q(cat ? 'SELECT * FROM pros WHERE cat = ?' : 'SELECT * FROM pros', cat ? [cat] : []);
    const pool = rows.map(proOut);
    const blockedOnDate = [], freeOnDate = [], suggested = [];
    let nextFreeDate = null;

    for (const p of pool) {
        const blocked = p.blocked || [];
        if (!blocked.length) continue;
        const isBlocked = blocked.includes(date);
        if (p.id === chosenId) {
            if (isBlocked) blockedOnDate.unshift(p); else freeOnDate.unshift(p);
        } else if (isBlocked) {
            blockedOnDate.push(p);
        } else {
            freeOnDate.push(p);
            suggested.push(p);
        }
    }
    suggested.sort((a, b) => (b.rating - a.rating) || (b.bookings - a.bookings));

    const targets = chosenId ? pool.filter(p => p.id === chosenId) : pool.filter(p => (p.blocked || []).length);
    const today = db.todayISO();
    if (date >= today && targets.length) {
        outer:
        for (let off = 0; off <= 30; off++) {
            const dt = new Date(date + 'T00:00:00');
            dt.setDate(dt.getDate() + off);
            const iso = dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
            for (const p of targets) {
                if (!((p.blocked || []).includes(iso))) { nextFreeDate = iso; break outer; }
            }
        }
    }
    return { ok: true, date, dateKnown: blockedOnDate.length + freeOnDate.length > 0, blocked: blockedOnDate, free: freeOnDate, suggest: suggested.slice(0, 3), nextFreeDate };
}

/* ---------- credentials & sessions ----------
   Same salted SHA-256 scheme as the sandbox (crypto-backed here).
   Bootstrap passwords come from settings (NOT code) and are only
   used to seed the hash rows on first login — never compared at
   runtime after that. */

async function defaultProPassword() { return config.get('default_pro_password', 'skillconnect'); }
async function defaultAdminPassword() { return config.get('default_admin_password', '4321'); }

/* ---------- password verify + transparent scrypt upgrade ----------
   Rows written before go-live use sha256(salt + password); new rows store
   a self-describing scrypt$N$r$p$salt$key string. Every successful login
   upgrades a legacy row to scrypt, so old hashes disappear organically. */
function isScryptHash(stored) { return String(stored || '').startsWith('scrypt$'); }

async function checkAndUpgradeProPassword(conn, p, secret) {
    if (isScryptHash(p.auth_hash)) return db.scryptVerify(secret, p.auth_hash);
    const ok = db.hashEq(db.sha256Hex(p.auth_salt + secret), p.auth_hash);
    if (ok) {
        const upgraded = db.scryptHash(secret);
        const now = Date.now();
        await conn.query("UPDATE pros SET auth_hash = ?, auth_algo = 'scrypt', auth_salt = '', auth_updated_at = ? WHERE id = ?",
            [upgraded, now, p.id]);
        p.auth_hash = upgraded; p.auth_algo = 'scrypt'; p.auth_salt = ''; p.auth_updated_at = now;
    }
    return ok;
}

async function checkAndUpgradeAdminPassword(conn, auth, pw) {
    if (isScryptHash(auth.hash)) return db.scryptVerify(pw, auth.hash);
    const ok = db.hashEq(db.sha256Hex(auth.salt + pw), auth.hash);
    if (ok) {
        const upgraded = db.scryptHash(pw);
        const now = Date.now();
        await conn.query("UPDATE admin_auth SET hash = ?, algo = 'scrypt', salt = '', updated_at = ? WHERE id = 1",
            [upgraded, now]);
        auth.hash = upgraded; auth.algo = 'scrypt'; auth.salt = ''; auth.updated_at = now;
    }
    return ok;
}

async function ensureProAuth(conn, proRowObj) {
    if (proRowObj.auth_hash) return proRowObj;
    const hash = db.scryptHash(await defaultProPassword());
    const now = Date.now();
    await conn.query("UPDATE pros SET auth_salt = '', auth_hash = ?, auth_algo = 'scrypt', auth_updated_at = ? WHERE id = ?",
        [hash, now, proRowObj.id]);
    proRowObj.auth_salt = ''; proRowObj.auth_hash = hash;
    proRowObj.auth_algo = 'scrypt'; proRowObj.auth_updated_at = now;
    return proRowObj;
}

function findProByPhoneSync(rows, phone) {
    const want = normPhone(phone);
    if (!want || want.length < 9) return null;
    return rows.find(r => normPhone(r.phone) === want) || null;
}

async function requestProOtp(phone) {
    const [rows] = await db.q('SELECT * FROM pros');
    const pro = findProByPhoneSync(rows, phone);
    if (!pro) return { ok: false, error: 'No verified professional is registered with that phone number.' };
    return db.tx(async (conn) => {
        const [locked] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [pro.id]);
        const p = await ensureProAuth(conn, locked[0]);
        const code = String(Math.floor(100000 + Math.random() * 900000));
        const ttlMin = await config.num('otp_ttl_minutes', 10);
        const now = Date.now();
        await conn.query(
            'INSERT INTO pro_otp (pro_id, hash, expires_at, created_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE hash = VALUES(hash), expires_at = VALUES(expires_at), created_at = VALUES(created_at)',
            [p.id, db.sha256Hex(p.auth_salt + code), now + ttlMin * 60000, now]);
        /* Real deployment: hand `code` to an SMS gateway. Sandbox: echo it in
           the response so the flow is testable end-to-end. */
        const out = { ok: true, proId: p.id, name: p.name, ttlMins: ttlMin };
        if (await sandboxMode()) out.sandboxCode = code;
        return out;
    });
}

async function proLogin(phone, secret) {
    const [rows] = await db.q('SELECT * FROM pros');
    const pro = findProByPhoneSync(rows, phone);
    if (!pro) return { ok: false, error: 'No verified professional is registered with that phone number.' };
    const s = String(secret == null ? '' : secret);
    if (!s) return { ok: false, error: 'Enter your password or the 6-digit code we sent you.' };
    return db.tx(async (conn) => {
        const [locked] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [pro.id]);
        const p = await ensureProAuth(conn, locked[0]);
        const [otpRows] = await conn.query('SELECT * FROM pro_otp WHERE pro_id = ?', [p.id]);
        const otp = otpRows[0] || null;
        const isOtp = /^\d{6}$/.test(s) && otp && Number(otp.expires_at) > Date.now();
        const okHash = isOtp
            ? db.hashEq(db.sha256Hex(p.auth_salt + s), otp.hash)
            : await checkAndUpgradeProPassword(conn, p, s);
        if (!okHash) return { ok: false, error: isOtp ? 'That code is not valid (or has expired) — request a new one.' : 'Wrong password. Use your password or switch to a WhatsApp login code.' };
        if (isOtp) await conn.query('DELETE FROM pro_otp WHERE pro_id = ?', [p.id]);   /* single-use */
        return { ok: true, pro: { id: p.id, name: p.name }, usedOtp: !!isOtp, pv: Number(p.auth_updated_at) };
    });
}

async function setProPassword(proId, currentSecret, newPassword) {
    const pw = String(newPassword == null ? '' : newPassword);
    if (pw.length < 8) return { ok: false, error: 'New password must be at least 8 characters.' };
    const chk = await proLoginById(proId, currentSecret);
    if (!chk.ok) return { ok: false, error: 'Current password or code is incorrect.' };
    return db.tx(async (conn) => {
        const [rows] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [proId]);
        if (!rows.length) return { ok: false, error: 'Professional not found.' };
        await conn.query("UPDATE pros SET auth_salt = '', auth_hash = ?, auth_algo = 'scrypt', auth_updated_at = ? WHERE id = ?",
            [db.scryptHash(pw), Date.now(), proId]);
        return { ok: true };
    });
}

/* proLogin by stored id (setProPassword) — same checks as proLogin(phone,·). */
async function proLoginById(proId, secret) {
    const [rows] = await db.q('SELECT * FROM pros WHERE id = ?', [proId]);
    if (!rows.length) return { ok: false, error: 'Professional not found.' };
    const s = String(secret == null ? '' : secret);
    if (!s) return { ok: false, error: 'Enter your password or the 6-digit code we sent you.' };
    return db.tx(async (conn) => {
        const [locked] = await conn.query('SELECT * FROM pros WHERE id = ? FOR UPDATE', [proId]);
        const p = await ensureProAuth(conn, locked[0]);
        const [otpRows] = await conn.query('SELECT * FROM pro_otp WHERE pro_id = ?', [p.id]);
        const otp = otpRows[0] || null;
        const isOtp = /^\d{6}$/.test(s) && otp && Number(otp.expires_at) > Date.now();
        const okHash = isOtp
            ? db.hashEq(db.sha256Hex(p.auth_salt + s), otp.hash)
            : await checkAndUpgradeProPassword(conn, p, s);
        if (!okHash) return { ok: false, error: isOtp ? 'That code is not valid (or has expired) — request a new one.' : 'Wrong password. Use your password or switch to a WhatsApp login code.' };
        if (isOtp) await conn.query('DELETE FROM pro_otp WHERE pro_id = ?', [p.id]);
        return { ok: true, pro: { id: p.id, name: p.name }, usedOtp: !!isOtp, pv: Number(p.auth_updated_at) };
    });
}

async function proUsesDefaultPassword(proId) {
    const [rows] = await db.q('SELECT * FROM pros WHERE id = ?', [proId]);
    if (!rows.length) return true;
    return db.tx(async (conn) => {
        const p = await ensureProAuth(conn, rows[0]);
        if (isScryptHash(p.auth_hash)) return db.scryptVerify(await defaultProPassword(), p.auth_hash);
        return db.hashEq(db.sha256Hex(p.auth_salt + (await defaultProPassword())), p.auth_hash);
    });
}

/* Admin auth lives in admin_auth (singleton), lazily bootstrapped from
   settings.default_admin_password exactly like the sandbox's ensureAdminAuth. */
async function ensureAdminAuth(conn) {
    const [rows] = await conn.query('SELECT * FROM admin_auth WHERE id = 1 FOR UPDATE');
    let row = rows[0];
    if (!row || !row.hash) {
        const hash = db.scryptHash(await defaultAdminPassword());
        const now = Date.now();
        await conn.query('INSERT INTO admin_auth (id, salt, hash, algo, updated_at) VALUES (1, \'\', ?, \'scrypt\', ?) ON DUPLICATE KEY UPDATE salt = VALUES(salt), hash = VALUES(hash), algo = VALUES(algo), updated_at = VALUES(updated_at)',
            [hash, now]);
        row = { id: 1, salt: '', hash, algo: 'scrypt', updated_at: now };
    }
    return row;
}

async function adminLogin(password) {
    const pw = String(password == null ? '' : password);
    if (!pw) return false;
    return db.tx(async (conn) => {
        const auth = await ensureAdminAuth(conn);
        return checkAndUpgradeAdminPassword(conn, auth, pw);
    });
}

async function adminUsesDefaultPassword() {
    return adminLogin(await defaultAdminPassword());
}

/* Credential metadata for session binding (never exposes usable secrets
   beyond the hash pair already stored at rest). */
async function adminAuthMeta() {
    return db.tx(async (conn) => {
        const row = await ensureAdminAuth(conn);
        return { salt: row.salt, hash: row.hash, algo: row.algo, updatedAt: Number(row.updated_at) };
    });
}

async function setAdminPassword(currentPassword, newPassword) {
    const pw = String(newPassword == null ? '' : newPassword);
    if (pw.length < 8) return { ok: false, error: 'New password must be at least 8 characters.' };
    if (!(await adminLogin(currentPassword))) return { ok: false, error: 'Current password is incorrect.' };
    return db.tx(async (conn) => {
        await conn.query("UPDATE admin_auth SET salt = '', hash = ?, algo = 'scrypt', updated_at = ? WHERE id = 1",
            [db.scryptHash(pw), Date.now()]);
        return { ok: true, pv: Date.now() };
    });
}

/* ---------- server-side sessions (replaces sc_session_v2 localStorage) ----------
   Role-parameterized capability bound to the credential version (pv) that was
   current at login. TTL from settings.session_ttl_hours; sliding refresh.
   Token lives ONLY in an httpOnly cookie — the browser keeps no session state. */

const COOKIE = 'sc_session';

function parseCookies(req) {
    const h = req.headers.cookie || '';
    const out = {};
    h.split(';').forEach(part => {
        const i = part.indexOf('=');
        if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
    });
    return out;
}

function sessionTtlMs(ttlHours) { return ttlHours * 3600000; }

async function createSession(res, role, proId, pv) {
    const token = db.randomHex(32);
    const now = Date.now();
    await db.q('INSERT INTO sessions (token, role, pro_id, pv, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?, ?)',
        [token, role, proId || null, pv || 0, now, now]);
    const ttlH = await config.num('session_ttl_hours', 8);
    res.setHeader('Set-Cookie',
        COOKIE + '=' + token + '; Path=/; HttpOnly; SameSite=Lax' + (config.infra.INSECURE_COOKIES ? '' : '; Secure'));
    return { token, role, proId: proId || null, pv: pv || 0, ttlHours: ttlH };
}

/* Returns {role, proId, pro?, admin?} or null; refreshes sliding expiry. */
async function getSession(req) {
    const token = parseCookies(req)[COOKIE];
    if (!token) return null;
    const [rows] = await db.q('SELECT * FROM sessions WHERE token = ?', [token]);
    if (!rows.length) return null;
    const s = rows[0];
    const ttlH = await config.num('session_ttl_hours', 8);
    const now = Date.now();
    if (now - Number(s.last_seen_at) > sessionTtlMs(ttlH)) {
        await db.q('DELETE FROM sessions WHERE token = ?', [token]);
        return null;
    }
    /* credential-version check: password change invalidates existing sessions */
    if (s.role === 'pro') {
        const [prows] = await db.q('SELECT auth_updated_at FROM pros WHERE id = ?', [s.pro_id]);
        if (!prows.length || Number(prows[0].auth_updated_at) !== Number(s.pv)) {
            await db.q('DELETE FROM sessions WHERE token = ?', [token]);
            return null;
        }
    } else {
        const [arows] = await db.q('SELECT updated_at FROM admin_auth WHERE id = 1');
        if (arows.length && Number(s.pv) !== 0 && Number(arows[0].updated_at) !== Number(s.pv)) {
            await db.q('DELETE FROM sessions WHERE token = ?', [token]);
            return null;
        }
    }
    await db.q('UPDATE sessions SET last_seen_at = ? WHERE token = ?', [now, token]);
    return { role: s.role, proId: s.pro_id, pv: Number(s.pv), token };
}

async function destroySession(req, res) {
    const token = parseCookies(req)[COOKIE];
    if (token) await db.q('DELETE FROM sessions WHERE token = ?', [token]);
    res.setHeader('Set-Cookie', COOKIE + '=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
}

/* ---------- admin ---------- */

async function adminCustomers() {
    const [rows] = await db.q(
        `SELECT RIGHT(REPLACE(REPLACE(customer_phone, ' ', ''), '-', ''), 9) AS key9,
                SUBSTRING_INDEX(GROUP_CONCAT(customer_name ORDER BY created_at DESC), ',', 1) AS name,
                SUBSTRING_INDEX(GROUP_CONCAT(customer_phone ORDER BY created_at DESC), ',', 1) AS phone,
                COUNT(*) AS bookings, SUM(CASE WHEN paid_at IS NOT NULL THEN amount ELSE 0 END) AS spent,
                MAX(created_at) AS lastAt,
                SUBSTRING_INDEX(GROUP_CONCAT(id ORDER BY created_at DESC), ',', 5) AS refs
         FROM bookings
         GROUP BY key9
         ORDER BY lastAt DESC`);
    return rows.map(r => ({
        key: r.key9, name: r.name, phone: r.phone,
        bookings: Number(r.bookings), spent: Number(r.spent),
        lastAt: Number(r.lastAt), refs: String(r.refs || '').split(',').slice(0, 5)
    }));
}

async function customerHistory(phone) {
    const key = String(phone || '').replace(/[\s-]/g, '').slice(-9);
    const list = await getBookingsFor(phone);
    list.sort((a, b) => b.createdAt - a.createdAt);
    const ids = new Set(list.map(b => b.id));
    const stats = { total: list.length, paidCount: 0, spend: 0, escrowHeld: 0, active: 0, cancelled: 0, reviews: 0, avg: 0, cats: {}, firstAt: 0 };
    list.forEach(b => {
        if (b.paidAt) { stats.paidCount++; stats.spend += (b.amount || 0); }
        if (b.escrow && !b.escrow.released) stats.escrowHeld += b.escrow.amount;
        if (['matching', 'quoted', 'booked', 'in_progress'].includes(b.status)) stats.active++;
        if (b.status === 'cancelled' || b.status === 'disputed') stats.cancelled++;
        if (b.cat) stats.cats[b.cat] = (stats.cats[b.cat] || 0) + 1;
        stats.firstAt = stats.firstAt ? Math.min(stats.firstAt, b.createdAt) : b.createdAt;
    });
    stats.avg = stats.paidCount ? Math.round(stats.spend / stats.paidCount) : 0;
    if (list.length) {
        const [revs] = await db.q('SELECT booking_id FROM reviews');
        stats.reviews = revs.filter(r => ids.has(r.booking_id)).length;
    }
    stats.topCat = Object.keys(stats.cats).sort((a, b) => stats.cats[b] - stats.cats[a])[0] || null;
    return { key, name: list.length ? list[0].name : '', phone, bookings: list, stats };
}

async function adminStats() {
    const d = db.get();
    const one = async (sql, params) => { const [rows] = await d.query(sql, params || []); return rows[0]; };
    const escrowHeldRow = await one("SELECT COALESCE(SUM(b.amount), 0) AS s FROM bookings b JOIN escrow e ON e.booking_id = b.id WHERE e.released = 0");
    const completedRow = await one("SELECT COUNT(*) AS c, COALESCE(SUM(amount), 0) AS gmv, COALESCE(SUM(commission), 0) AS comm FROM bookings WHERE status = 'completed'");
    const awaitingRow = await one("SELECT COALESCE(SUM(amount - COALESCE(commission, 0)), 0) AS s FROM bookings WHERE status = 'completed' AND pro_paid = 0");
    const prosRow = await one('SELECT COUNT(*) AS c FROM pros');
    const appsPendingRow = await one("SELECT COUNT(*) AS c FROM applications WHERE status = 'pending'");
    const bookingsRow = await one('SELECT COUNT(*) AS c FROM bookings');
    const openJobsRow = await one("SELECT COUNT(*) AS c FROM bookings WHERE status IN ('matching','quoted','booked','in_progress')");
    const disputesRow = await one("SELECT COUNT(*) AS c FROM disputes WHERE status = 'open'");
    const revenueRow = await one("SELECT COALESCE(SUM(amount), 0) AS s FROM transactions WHERE type IN ('commission','registration_fee')");
    const regFeesRow = await one("SELECT COALESCE(SUM(amount), 0) AS s FROM transactions WHERE type = 'registration_fee'");
    const payoutRow = await one("SELECT COUNT(*) AS c FROM payout_requests WHERE status = 'pending'");
    const [catRows] = await d.query("SELECT cat, COUNT(*) AS total, SUM(status = 'cancelled') AS cancelled FROM bookings GROUP BY cat");
    const cancellationsByCat = catRows
        .map(c => ({ cat: c.cat, total: Number(c.total), cancelled: Number(c.cancelled), rate: Math.round(Number(c.cancelled) / Number(c.total) * 100) }))
        .sort((a, b) => (b.rate - a.rate) || (b.total - a.total));
    return {
        pros: Number(prosRow.c),
        applicationsPending: Number(appsPendingRow.c),
        bookings: Number(bookingsRow.c),
        openJobs: Number(openJobsRow.c),
        disputesOpen: Number(disputesRow.c),
        cancellationsByCat,
        escrowHeld: Number(escrowHeldRow.s),
        gmv: Number(completedRow.gmv),
        commission: Number(completedRow.comm),
        revenue: Number(revenueRow.s),
        regFees: Number(regFeesRow.s),
        awaitingPayout: Number(awaitingRow.s),
        customers: (await adminCustomers()).length,
        payoutRequests: Number(payoutRow.c)
    };
}

async function adminAssign(bookingId, proId) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        const p = proId ? (await proRow(conn, proId)) : null;
        if (!b || !p) return { ok: false, error: 'Booking or pro not found.' };
        const ids = b.matched_pro_ids || [];
        if (!ids.includes(proId)) {
            await conn.query('UPDATE bookings SET matched_pro_ids = ? WHERE id = ?', [JSON.stringify(ids.concat([proId])), bookingId]);
        }
        await addQuoteInternal(conn, bookingId, proId, Number(p.price), 60000, p.name);
        await pushEvent(conn, bookingId, 'Admin manually assigned ' + p.name + '. Quote sent.');
        await notify(conn, 'pro', p.id, 'job', 'Admin assigned you to ' + bookingId + ' — quote sent to customer.');
        return { ok: true };
    });
}

async function allBookings() {
    const [rows] = await db.q('SELECT id FROM bookings ORDER BY created_at DESC, id DESC');
    const out = [];
    for (const r of rows) out.push(await refreshBooking(db.get(), r.id));
    return out;
}

/* Manual-match queue: every unbooked request with zero matched pros.
   Returned newest-first with the quoting pool the admin can pick from
   (verified pros in the category, cheapest first, with price + city
   so the assignment decision needs no second lookup). */
async function adminNoMatchQueue() {
    const [rows] = await db.q("SELECT * FROM bookings WHERE status IN ('matching','quoted') AND (matched_pro_ids IS NULL OR matched_pro_ids = '[]' OR JSON_LENGTH(matched_pro_ids) = 0) ORDER BY created_at DESC, id DESC");
    const out = [];
    for (const r of rows) {
        const [poolRows] = await db.q('SELECT * FROM pros WHERE verified = 1 AND cat = ? ORDER BY price ASC', [r.cat]);
        out.push({
            booking: await refreshBooking(db.get(), r.id),
            pool: poolRows.map(proOut).map(p => ({ id: p.id, name: p.name, price: p.price, city: p.city, rating: p.rating, bookings: p.bookings, gate: idGateSync(p).stage }))
        });
    }
    return out;
}

async function allQuotes() {
    const [rows] = await db.q('SELECT * FROM quotes ORDER BY created_at DESC, id DESC');
    return rows.map(quoteOut);
}

/* Admin reassignment: move a not-yet-released booking to a new pro.
   Allowed pre-escrow (matching/quoted/booked), or in_progress (escrow
   transfers). Released escrow = financial record, not reassignable. */
async function reassignBooking(bookingId, newProId) {
    return db.tx(async (conn) => reassignBookingInTx(conn, bookingId, newProId));
}

async function reassignBookingInTx(conn, bookingId, newProId) {
    const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
    const b = brows[0];
    const np = newProId ? (await proRow(conn, newProId)) : null;
    if (!b || !np) return { ok: false, error: 'Booking or professional not found.' };
    if (!['matching', 'quoted', 'booked', 'in_progress'].includes(b.status)) {
        return { ok: false, error: 'Job is ' + b.status.replace('_', ' ') + ' — payment already released, cannot reassign.' };
    }
    if (b.chosen_pro_id === newProId) return { ok: false, error: 'That professional is already assigned to this job.' };
    if ((np.blocked || []).includes(b.event_date || '')) {
        return { ok: false, error: np.name + ' is blocked on ' + (b.event_date || 'the chosen date') + '.' };   /* date conflict guard */
    }

    const oldPro = b.chosen_pro_id ? (await proRow(conn, b.chosen_pro_id)) : null;
    /* Prefer an already-sent quote (e.g. a rematch auto-invite) over the listed
       price so the customer sees the same number they were shown. */
    const [pendingQrows] = await conn.query("SELECT * FROM quotes WHERE booking_id = ? AND pro_id = ? AND status = 'sent' LIMIT 1", [b.id, newProId]);
    const pendingQ = pendingQrows[0] || null;
    const newQuotePrice = pendingQ ? Number(pendingQ.price) : Number(np.price);
    const wasInProgress = b.status === 'in_progress';

    /* 1. Decline all outstanding quotes on this booking */
    await conn.query("UPDATE quotes SET status = 'declined' WHERE booking_id = ? AND status = 'sent'", [b.id]);

    /* 2. Transfer or reset escrow (txn_ref gains /R<n> per reassignment) */
    const esc = await escrowFor(conn, b.id);
    if (esc && !esc.released) {
        await conn.query('UPDATE escrow SET pro_id = ?, txn_ref = ? WHERE booking_id = ?', [newProId, nextReassignRef(esc.txn_ref), b.id]);
    }

    /* 3. Re-point the booking and log the event */
    const newStatus = wasInProgress ? 'in_progress' : 'booked';
    await conn.query('UPDATE bookings SET chosen_pro_id = ?, amount = ?, status = ?, matched_pro_ids = ? WHERE id = ?',
        [newProId, newQuotePrice, newStatus, JSON.stringify([newProId]), b.id]);
    await pushEvent(conn, b.id, 'Reassigned to ' + np.name + ' by dispatch' + (oldPro ? ' (was ' + oldPro.name + ')' : '') + '. New price ' + cedi(newQuotePrice) + '.');

    /* 4. Fresh accepted quote so ledger history stays complete */
    const q = await addQuoteInternal(conn, b.id, newProId, newQuotePrice, 60000, np.name);
    if (q) await conn.query("UPDATE quotes SET status = 'accepted' WHERE id = ?", [q.id]);
    const [chk] = await conn.query('SELECT status FROM bookings WHERE id = ?', [b.id]);
    if (chk[0].status === 'matching') await conn.query("UPDATE bookings SET status = 'quoted' WHERE id = ?", [b.id]);

    /* 5. Notify everyone and leave a system chat note */
    const catLabel = await catLabelOf(conn, b.cat);
    const dateTxt = b.event_date ? await fmtDateOf(b.event_date) : 'flexible date';
    await notify(conn, 'pro', newProId, 'job', 'ASSIGNED: ' + b.id + ' — ' + catLabel + ' on ' + dateTxt + ' in ' + b.location + '. ' + cedi(newQuotePrice) + ' (escrow).');
    if (oldPro) await notify(conn, 'pro', oldPro.id, 'job', 'Job ' + b.id + ' was reassigned by dispatch.');
    await notify(conn, 'customer', b.id, 'booking', 'Your pro for ' + b.id + ' changed to ' + np.name + '. New agreed price: ' + cedi(newQuotePrice) + '.');
    await sendChatInTx(conn, b.id, 'system', 'Dispatch reassigned this job to ' + np.name + (oldPro ? ' (previously ' + oldPro.name + ')' : '') + '. New agreed price ' + cedi(newQuotePrice) + '.');

    return { ok: true, booking: await refreshBooking(conn, b.id), newPro: { id: np.id, name: np.name }, oldPro: oldPro ? { id: oldPro.id, name: oldPro.name } : null, newQuotePrice };
}

function nextReassignRef(ref) {
    const m = String(ref).match(/\/R(\d+)$/i);
    return String(ref).replace(/\/R\d+$/i, '') + '/R' + (m ? Number(m[1]) + 1 : 1);
}

/* ---------- transactions ledger (admin) ---------- */

async function getTransactions() {
    const [rows] = await db.q('SELECT * FROM transactions ORDER BY at DESC, id DESC');
    return rows.map(txnOut);
}

/* Admin marks a completed job as paid out to the worker (cash/bank/MoMo):
   decrements the wallet, writes the payout txn, notifies — identical flow. */
async function markProPaid(bookingId, method) {
    return db.tx(async (conn) => {
        const [brows] = await conn.query('SELECT * FROM bookings WHERE id = ? FOR UPDATE', [bookingId]);
        const b = brows[0];
        if (!b || b.status !== 'completed' || !Number(b.amount)) return { ok: false, error: 'Booking is not completed or has no amount.' };
        if (b.pro_paid) return { ok: false, error: 'Worker already marked as paid for this booking.' };
        const pro = b.chosen_pro_id ? (await proRow(conn, b.chosen_pro_id)) : null;
        if (!pro) return { ok: false, error: 'Professional not found.' };

        const now = Date.now();
        const m = method || 'momo';
        const payout = round2(Number(b.amount) - Number(b.commission || 0));
        await conn.query('UPDATE bookings SET pro_paid = 1, pro_paid_at = ?, pro_paid_method = ? WHERE id = ?', [now, m, bookingId]);
        await conn.query('UPDATE pros SET balance = GREATEST(0, balance - ?) WHERE id = ?', [payout, pro.id]);
        await addTxn(conn, 'payout', bookingId, pro.id, payout, m, 'Admin payout to worker for ' + bookingId + ' — ' + pro.name);
        await notify(conn, 'pro', pro.id, 'payment', cedi(payout) + ' paid out for ' + bookingId + ' via ' + m.toUpperCase() + '. Thank you!');
        return { ok: true, payout };
    });
}

/* ---------- registration fee ---------- */

/* markRegFeePaidInTx — THE registration-fee transition (flag + ledger +
   notifications), shared verbatim by the sandbox payRegFee and the gateway
   confirm handler. Caller owns the transaction and row locks. */
async function markRegFeePaidInTx(conn, appRef, method, payRef) {
    const [arows] = await conn.query('SELECT * FROM applications WHERE id = ? FOR UPDATE', [appRef]);
    const app = arows[0] || null;
    const [prows] = await conn.query('SELECT * FROM pros WHERE app_id = ? OR id = ? FOR UPDATE', [appRef, appRef]);
    const pro = prows[0] || null;
    if (!app && !pro) return { ok: false, error: 'Application not found.' };
    const target = pro || app;
    if (target.reg_fee_paid) return { ok: false, error: 'Registration fee already paid.' };

    const fee = await getRegFee();
    const now = Date.now();
    if (pro) await conn.query('UPDATE pros SET reg_fee_paid = 1, reg_fee_at = ? WHERE id = ?', [now, pro.id]);
    else await conn.query('UPDATE applications SET reg_fee_paid = 1, reg_fee_at = ? WHERE id = ?', [now, app.id]);
    const name = pro ? pro.name : app.name;
    const holderId = pro ? pro.id : app.id;
    const t = await addTxn(conn, 'registration_fee', null, pro ? pro.id : null, fee, method || 'momo',
        'Registration/verification fee — ' + name + (payRef ? ' (ref ' + payRef + ')' : ''));
    await notify(conn, 'admin', holderId, 'payment', 'Registration fee ' + cedi(fee) + ' received from ' + name + '.');
    await notify(conn, 'customer', holderId, 'payment', 'Registration fee received. Your verification is now prioritised.');
    return { ok: true, txnId: t.id, proId: pro ? pro.id : null, amount: fee };
}

async function payRegFee(appRef, method, payRef) {
    if (await config.activeGateway()) {
        return { ok: false, error: 'Sandbox payment is disabled — use the checkout flow (POST /api/payments/initiate).' };
    }
    return db.tx(async (conn) => markRegFeePaidInTx(conn, appRef, method, payRef));
}

/* ---------- notifications passthrough ---------- */

/* ---------- notification preference center (pro) ----------
   Muting is scoped to MUTABLE types only; the critical set is enforced in
   notify() and can never be stored. Missing pro / unknown proId → ok:false. */
async function notificationPrefsGet(proId) {
    const [rows] = await db.q('SELECT notify_muted_types FROM pros WHERE id = ?', [proId]);
    if (!rows.length) return { ok: false, error: 'Professional not found.' };
    const muted = normNotifyPrefs(rows[0].notify_muted_types);
    return {
        ok: true,
        muted,
        critical: NOTIFY_CRITICAL_TYPES.slice(),
        mutable: NOTIFY_MUTABLE_TYPES.slice()
    };
}

async function notificationPrefsSet(proId, mutedTypes) {
    const [rows] = await db.q('SELECT id FROM pros WHERE id = ?', [proId]);
    if (!rows.length) return { ok: false, error: 'Professional not found.' };
    const muted = normNotifyPrefs(mutedTypes);
    const rejected = (Array.isArray(mutedTypes) ? mutedTypes.map(String) : [])
        .filter(t => !NOTIFY_MUTABLE_TYPES.includes(t) && !muted.includes(t));
    await db.q('UPDATE pros SET notify_muted_types = ? WHERE id = ?', [JSON.stringify(muted), proId]);
    return { ok: true, muted, rejected };
}

async function notificationsFor(audience, refTo) {
    const [rows] = await db.q(
        'SELECT * FROM notifications WHERE audience = ? AND (? = \'\' OR ref_to = ? OR ref_to = \'*\') ORDER BY at DESC, id DESC',
        [audience, refTo || '', refTo || '']);
    return rows.map(n => ({ id: n.id, audience: n.audience, refTo: n.ref_to, type: n.type, text: n.text, at: Number(n.at), read: !!n.read }));
}

async function markNotificationsRead(audience, refTo) {
    await db.q(
        'UPDATE notifications SET `read` = 1 WHERE audience = ? AND (? = \'\' OR ref_to = ? OR ref_to = \'*\')',
        [audience, refTo || '', refTo || '']);
}

/* Housekeeping: keep each audience at its notification cap. Runs OUTSIDE
   business transactions on a timer — trims from the OLD end of the index
   while inserts append at the new end, so the two never contend. */
let capSweeperStarted = false;
function startNotificationCapSweeper() {
    if (capSweeperStarted) return;
    capSweeperStarted = true;
    const sweep = async () => {
        try {
            const cap = await config.num('notifications_cap', 400);
            for (const audience of ['customer', 'pro', 'admin']) {
                const [cnt] = await db.q('SELECT COUNT(*) AS c FROM notifications WHERE audience = ?', [audience]);
                if (Number(cnt[0].c) > cap) {
                    await db.tx(async (conn) => {
                        await conn.query('DELETE FROM notifications WHERE audience = ? AND id NOT IN (SELECT id FROM (SELECT id FROM notifications WHERE audience = ? ORDER BY at DESC, id DESC LIMIT ?) keep)',
                            [audience, audience, cap]);
                    });
                }
            }
        } catch (e) {
            console.error('[notif-cap]', e && e.message || e);
        }
    };
    setInterval(sweep, 60 * 1000).unref();
}

/* ============================================================
   EXPORT — the SC.* mirror. Same names, same signatures, same
   result shapes as data-store.js's public API (now all async).
   ============================================================ */

/* ============================================================
   SNAPSHOT + RESET — the sc_db_v1 JSON reassembly (mirror of the
   importer) powering the front-end adapter's sync bridge.
   Pages keep their synchronous SC.* calls: data-store.js loads a
   full snapshot, sends mutations to /api/mutate and re-hydrates
   from the authoritative response. /api/rev lets clients poll for
   changes cheaply.
   ============================================================ */

let _rev = '1-' + Date.now();
function revBump() { _rev = String(Number(_rev.split('-')[0]) + 1) + '-' + Date.now(); return _rev; }
function serverRev() { return _rev; }

async function snapshot() {
    const d = db.get();
    const [pros] = await d.query('SELECT * FROM pros ORDER BY id');
    const [bookings] = await d.query('SELECT * FROM bookings ORDER BY created_at DESC, id DESC');
    const [events] = await d.query('SELECT * FROM booking_events ORDER BY booking_id, seq');
    const [escrows] = await d.query('SELECT * FROM escrow');
    const [quotes] = await d.query('SELECT * FROM quotes ORDER BY created_at, id');
    const [applications] = await d.query('SELECT * FROM applications ORDER BY submitted_at DESC, id DESC');
    const [disputes] = await d.query('SELECT * FROM disputes ORDER BY opened_at DESC, id DESC');
    const [reviews] = await d.query('SELECT * FROM reviews ORDER BY at DESC, id DESC');
    const [txns] = await d.query('SELECT * FROM transactions ORDER BY at DESC, id DESC');
    const [payouts] = await d.query('SELECT * FROM payout_requests ORDER BY requested_at DESC');
    const [chat] = await d.query('SELECT * FROM chat_messages ORDER BY booking_id, seq');
    const [notifs] = await d.query('SELECT * FROM notifications ORDER BY at DESC, id DESC');
    const [support] = await d.query('SELECT * FROM support_messages ORDER BY at DESC, id DESC');
    const [cmsRows] = await d.query('SELECT * FROM cms WHERE id = 1');
    const [adminRows] = await d.query('SELECT * FROM admin_auth WHERE id = 1');
    const [counters] = await d.query('SELECT kind, value FROM counters');
    const [settingRows] = await d.query('SELECT setting_key, setting_value FROM settings');

    const eventsByBooking = {};
    for (const e of events) (eventsByBooking[e.booking_id] = eventsByBooking[e.booking_id] || []).push({ at: Number(e.at), text: e.text });
    const escByBooking = {};
    for (const e of escrows) escByBooking[e.booking_id] = e;

    const db0 = {
        pros: pros.map(proOut),
        bookings: bookings.map(b => bookingOut(b, eventsByBooking[b.id] || [], escByBooking[b.id] || null)),
        quotes: quotes.map(quoteOut),
        applications: applications.map(appOut),
        disputes: disputes.map(disputeOut),
        reviews: reviews.map(reviewOut),
        transactions: txns.map(txnOut),
        payoutRequests: payouts.map(r => ({ id: r.id, proId: r.pro_id, amount: Number(r.amount), method: r.method, status: r.status, requestedAt: Number(r.requested_at), processedAt: r.processed_at ? Number(r.processed_at) : undefined, processedBy: r.processed_by || undefined })),
        chat: {},
        notifications: notifs.map(n => ({ id: n.id, audience: n.audience, refTo: n.ref_to, type: n.type, text: n.text, at: Number(n.at), read: !!n.read })),
        supportMessages: support.map(supportOut),
        cms: cmsRows.length ? Object.assign(getCmsShape(cmsRows[0]), adminRows.length && adminRows[0].hash ? {
            adminAuth: { salt: adminRows[0].salt, hash: adminRows[0].hash, algo: adminRows[0].algo, updatedAt: Number(adminRows[0].updated_at) }
        } : {}) : {},
        counters: {},
        seededAt: Date.now()
    };
    for (const c of counters) db0.counters[c.kind] = Number(c.value);
    for (const m of chat) (db0.chat[m.booking_id] = db0.chat[m.booking_id] || []).push({ from: m.sender, text: m.text, at: Number(m.at) });
    /* Admin-editable tunables travel with the snapshot so the pages (and the
       sandbox-shape client store) read the same live values everywhere. */
    db0.settings = {};
    for (const s of settingRows) {
        try { db0.settings[s.setting_key] = JSON.parse(s.setting_value); } catch (e) { db0.settings[s.setting_key] = s.setting_value; }
    }
    return db0;
}

function getCmsShape(r) {
    return {
        heroTitle: r.hero_title, heroSub: r.hero_sub,
        announceOn: !!r.announce_on, announceText: r.announce_text,
        regFee: Number(r.reg_fee), updatedAt: Number(r.updated_at)
    };
}

/* Deliver a notification honouring the pro's channel preference
   (sms | whatsapp | both). In-app is always written (the dashboard
   bell), Web Push fires as for any pro notice, and the SMS/WhatsApp
   gateway leg is dispatched through notify-channels.js — AWAITED here
   so callers (and the smoke suite) can observe real delivery status.
   No opinion of the caller's transaction is needed: the gateway send
   is fire-and-forget inside notify() and audited either way. */
async function notifyProByChannel(conn, proId, type, text) {
    await notify(conn, 'pro', proId, type, text);
    const [rows] = await db.q('SELECT contact_channels FROM pros WHERE id = ?', [proId]);
    const ch = rows.length ? (rows[0].contact_channels || 'both') : 'both';
    const channels = ch === 'both' ? ['sms', 'whatsapp'] : [ch];
    /* Await the off-platform leg (also fired inside notify(); the
       audited upserts are idempotent-blind duplicates by design —
       the audit trail is per-dispatch, not per-channel-plan). */
    let gateway = null;
    try {
        const channelsMod = require('./notify-channels');
        gateway = await channelsMod.deliverProNotice(proId, type, text, true);
    } catch (e) { gateway = { ok: false, error: e && e.message || String(e), results: [] }; }
    return {
        channel: ch,
        delivered: channels,
        gateway: {
            configured: require('./notify-channels').enabled(),
            ok: !!(gateway && gateway.ok),
            results: (gateway && gateway.results) || []
        }
    };
}

/* Sandbox-parity reset (SC.reset()): wipe business data, restore seeds.
   Only allowed while sandbox_mode is on. */
async function resetAll() {
    if (!(await config.bool('sandbox_mode', true))) return { ok: false, error: 'Reset is disabled (sandbox_mode is off).' };
    return db.tx(async (conn) => {
        await conn.query('SET FOREIGN_KEY_CHECKS = 0');
        for (const t of ['payment_intents', 'payout_batches', 'match_events', 'channel_outbound', 'booking_events', 'escrow', 'quotes', 'reviews', 'disputes', 'transactions', 'payout_requests', 'chat_messages', 'notifications', 'support_messages', 'bookings', 'applications', 'pro_otp', 'sessions']) {
            await conn.query('DELETE FROM ' + t);
        }
        await conn.query('DELETE FROM pros');
        await conn.query('DELETE FROM admin_auth');
        await conn.query("UPDATE cms SET hero_title = 'GHANA''S #1 BOOKING PLATFORM FOR SKILLED SERVICE PROS!', announce_on = 1, reg_fee = 50, updated_at = ? WHERE id = 1", [Date.now()]);
        await conn.query('SET FOREIGN_KEY_CHECKS = 1');
        const seeds = { booking: 284000, quote: 51000, msg: 90000, app: 300, dispute: 40, review: 7000, txn: 500000, payout: 100, pbatch: 0 };
        for (const [kind, value] of Object.entries(seeds)) {
            await conn.query('INSERT INTO counters (kind, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)', [kind, value]);
        }
        await seedBaseline(conn);   /* pristine sandbox baseline: 12 pros + 30 reviews */
        revBump();
        return { ok: true };
    });
}

/* ============================================================
   SEED BASELINE — sandbox parity on a fresh database (and after
   SC.reset()): 12 verified pros P1001–P1012 + 30 seeded reviews,
   exactly seedData()/migrate() output. Idempotent.
   ============================================================ */

const SEED_SETTINGS = [
    ['commission_rate', 0.10], ['default_reg_fee', 50], ['otp_ttl_minutes', 10],
    ['session_ttl_hours', 8], ['default_pro_password', 'skillconnect'],
    ['default_admin_password', '4321'], ['currency', 'GHS'],
    ['notifications_cap', 400], ['support_cap', 200], ['max_matches', 3],
    ['site_url', 'https://skillconnectgh.com'], ['sandbox_mode', true],
    ['id_valid_years', 5], ['id_warn_days', 60], ['id_grace_days', 14], ['portfolio_url_max_len', 300000],
    /* Payment gateway (which provider is live is business config, not code;
       secrets stay in env — see config.infra). Empty ⇒ simulated payments. */
    ['payment_gateway', ''], ['payment_currency', 'GHS'],
    /* USSD shortcode advertised on the SMS/USSD page. Empty until the
       network provisions one — the page then says “coming soon”. */
    ['ussd_code', '']
];

const SEED_PROS = [
    ['Kwesi "The Voice" Amankwah', 'Kwesi', 'mc', 'Event MC', 'Accra', 4.9, 212, 800, 'event', 'Twi & English · Weddings, corporate'],
    ['Adjoa Breeze & Band', 'Adjoa', 'artist', 'Live Band / Artist', 'Tema', 4.8, 97, 2500, 'show', 'Afrobeats, highlife, gospel sets'],
    ['ShotsByNana Studios', 'Nana', 'photographer', 'Photographer', 'Kumasi', 5.0, 156, 600, 'day', 'Events, studio, drone'],
    ['FixIt Kwabena', 'Kwabena', 'handy', 'Electrician / Handyman', 'Accra', 4.7, 340, 150, 'visit', 'Wiring, repairs, installations'],
    ['DJ Vybez GH', 'DJ Vybez', 'dj', 'DJ / Sound & Lighting', 'Accra', 4.8, 275, 900, 'event', 'Full sound system & lighting packages'],
    ['Lens & Frames Media', 'Lens & Frames', 'videographer', 'Videographer / Editor', 'Takoradi', 4.9, 88, 1200, 'day', 'Live coverage, highlight reels, drone'],
    ['Auntie Akos Catering', 'Auntie Akos', 'caterer', 'Caterer / Baker', 'Kumasi', 4.9, 190, 1800, 'event', 'Local dishes, small chops, wedding cakes'],
    ['GrandDecor Events', 'GrandDecor', 'decorator', 'Decorator / Planner', 'Accra', 4.6, 120, 2000, 'event', 'Stage, canopy, floral & theme design'],
    ['MC Papa Sly', 'Papa Sly', 'mc', 'Event MC', 'Takoradi', 4.5, 64, 500, 'event', 'English & Fante · Parties, funerals'],
    ['Kumasi Wedding Cinema', 'KWC Team', 'videographer', 'Videographer / Editor', 'Kumasi', 4.7, 73, 2500, 'event', 'Cinematic wedding films & trailers'],
    ['HandyPro Maintenance', 'HandyPro', 'handy', 'Plumber / AC Technician', 'Tema', 4.8, 410, 200, 'visit', 'Leaks, AC servicing, fittings'],
    ['Overflow Music Ministry', 'Overflow', 'artist', 'Gospel Artist', 'Accra', 5.0, 45, 3000, 'show', 'Worship concerts, church events']
];

const SEED_REVIEW_TEXTS = [
    ['Ama Serwaa', 5, 'Very professional and punctual. Made our event stress-free — highly recommended!'],
    ['Kwame O.', 5, 'Delivered exactly what was promised. Communication was excellent from start to finish.'],
    ['Efua M.', 4, 'Great work overall. Slightly late arriving but more than made up for it on the day.'],
    ['Yaw Darko', 5, 'Fair price, quality service. Already booked him again for my sister\'s wedding.'],
    ['Akosua B.', 5, 'Would choose them again without thinking. Worth every cedi.'],
    ['Kofi A.', 4, 'Solid job and respectful team. Will use SkillConnect for our next event.']
];

const SEED_ID_AGES = [400, 1830, 1900, 300, 900, 1805, 550, 250, 1820, 800, 350, 1100];   /* days since ID check — P1002 grace-stage, P1003 delisted */

function isoDaysAgo(days) {
    const dt = new Date(Date.now() - days * 86400000);
    return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
}

async function ensureSettings(conn) {
    for (const [k, v] of SEED_SETTINGS) {
        await conn.query('INSERT IGNORE INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?)',
            [k, JSON.stringify(v), Date.now()]);
    }
}

async function seedBaseline(conn) {
    await ensureSettings(conn);
    const [cnt] = await conn.query('SELECT COUNT(*) AS c FROM pros');
    if (Number(cnt[0].c) > 0) return false;
    const now = Date.now();
    const DAY = 86400000;
    for (let i = 0; i < SEED_PROS.length; i++) {
        const p = SEED_PROS[i];
        const id = 'P' + String(1001 + i);
        /* availability seed mix (sandbox migrate/seed pattern) */
        let blocked = [];
        if (i % 4 === 1) blocked = [isoDaysAgo(-(1 + (i % 5)))];
        else if (i % 7 === 3) blocked = [0, 1, 2, 3].map(n => isoDaysAgo(-n));
        /* Contact-channel preference mix — SAME sequence as data-store.js's
           seed so sandbox and server agree on which pro prefers which channel
           (dispatch routing tests and UI copy both key on it). */
        const contactMix = ['both', 'whatsapp', 'sms', 'both', 'both', 'whatsapp', 'both', 'both', 'sms', 'both', 'whatsapp', 'both'];
        await conn.query(
            `INSERT INTO pros (id, name, short_name, cat, role, city, rating, rating_count, bookings_count,
                price, unit, note, phone, verified, emergency, response, years, languages, description,
                earnings, commission_paid, balance, blocked, joined_at, source, reg_fee_paid,
                contact_channels, id_type, id_docs_received, id_verified_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'seed', 1, ?, 'ghana_card', 1, ?)`,
            [id, p[0], p[1], p[2], p[3], p[4], p[5], Math.round(p[6] * 0.6), p[6],
             p[7], p[8], p[9], '02400000' + String(10 + i),
             i % 3 !== 2 ? 1 : 0, ['1hr', '3hr', 'sameday'][i % 3], ['3-5', '6-10', '10+'][i % 3],
             JSON.stringify(['English', 'Twi'].slice(0, (i % 2) + 1)),
             p[9] + ' — verified professional on SkillConnect.',
             round2(p[6] * p[7] * 0.85), round2(p[6] * p[7] * 0.15), Math.round(p[7] * 0.4),
             JSON.stringify(blocked), now - DAY * (200 - i * 7),
             contactMix[i] || 'both',
             now - SEED_ID_AGES[i] * DAY]);
        const n = 2 + (i % 2);   /* 2–3 reviews each (sandbox reviewsSeeded) */
        for (let r = 0; r < n; r++) {
            const t = SEED_REVIEW_TEXTS[(i + r * 2) % SEED_REVIEW_TEXTS.length];
            await conn.query(
                'INSERT INTO reviews (id, booking_id, pro_id, by_name, rating, text, at) VALUES (?, NULL, ?, ?, ?, ?, ?)',
                ['SC-RV-SEED-' + id + '-' + r, id, t[0], t[1], t[2], now - DAY * (30 + (i * 13 + r * 41) % 300)]);
        }
    }
    return true;
}

async function ensureSeeded() {
    return db.tx(async (conn) => seedBaseline(conn));
}

/* Scoped application status for the public tracker page (application.html).
   Returns ONE applicant's data — status, queue position, feed, live pro id —
   never the whole applications table (pre-go-live the page pulled all
   applications, which leaked every applicant's name/phone to anyone). */
async function applicationTrack(appRef) {
    const digits = s => String(s == null ? '' : s).replace(/\D/g, '');
    const want = digits(appRef);
    if (!want) return null;
    const [rows] = await db.q('SELECT * FROM applications');
    const app = rows.find(r => digits(r.id) === want);
    if (!app) return null;
    const [pendingRows] = await db.q(
        "SELECT COUNT(*) AS n FROM applications WHERE status = 'pending' AND submitted_at <= ?",
        [Number(app.submitted_at) || 0]);
    let livePro = null;
    if (app.status === 'verified') {
        const [prows] = await db.q('SELECT id, name, cat, city FROM pros WHERE app_id = ?', [app.id]);
        livePro = prows[0] || null;
    }
    const feed = (await notificationsFor('customer', app.id)).slice(0, 8);
    return { app: appOut(app), queueAhead: Number(pendingRows[0] ? pendingRows[0].n : 0), livePro, feed };
}

/* One-time schema widening for scrypt password hashes: pre-go-live rows
   stored CHAR(64) sha256 hex; scrypt strings are ~178 chars. MariaDB
   silently truncates over-wide VARCHARs, which would brick every login,
   so the correct width is enforced at every startup (idempotent). */
/* One-time schema for the staged ID-renewal enforcement: id_gate_until
   holds an admin time-override (0/NULL = none); id_gate_notified remembers
   which enforcement stage the pro was last notified about so the lazy
   sweep notifies on FIRST OBSERVATION of a stage (not only on the exact
   boundary day, which a downtime would miss). Idempotent. */
async function migrateIdGateColumn() {
    const [cols] = await db.q(
        "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pros' AND COLUMN_NAME IN ('id_gate_until','id_gate_notified')");
    const have = new Set(cols.map(c => c.COLUMN_NAME));
    if (!have.has('id_gate_until')) await db.q('ALTER TABLE pros ADD COLUMN id_gate_until BIGINT NULL AFTER id_submitted_at');
    if (!have.has('id_gate_notified')) await db.q("ALTER TABLE pros ADD COLUMN id_gate_notified VARCHAR(16) NULL AFTER id_gate_until");
}

/* contact_channels: how a pro accepts customer contact (sms | whatsapp |
   both). Idempotent — stamped on boot next to the other migrations. */
async function migrateContactChannels() {
    const [cols] = await db.q(
        "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pros' AND COLUMN_NAME = 'contact_channels'");
    if (!cols.length) {
        await db.q("ALTER TABLE pros ADD COLUMN contact_channels VARCHAR(16) NOT NULL DEFAULT 'both' AFTER response");
    }
}

async function migrateAuthColumns() {
    await db.q("ALTER TABLE pros MODIFY auth_hash VARCHAR(255) NULL, MODIFY auth_salt VARCHAR(255) NULL, MODIFY auth_algo VARCHAR(24) NULL");
    await db.q("ALTER TABLE admin_auth MODIFY hash VARCHAR(255) NULL, MODIFY salt VARCHAR(255) NULL, MODIFY algo VARCHAR(24) NULL");
    await db.q("ALTER TABLE pro_otp MODIFY hash VARCHAR(255) NOT NULL");
}

/* One-time schema for the controlled payout workflow (payout_batches +
   request columns). Idempotent: CREATE TABLE IF NOT EXISTS / checked
   ADD COLUMN — safe on both fresh and existing databases. */
async function migratePayoutTables() {
    await db.q(`CREATE TABLE IF NOT EXISTS payout_batches (
        id           VARCHAR(16) NOT NULL,
        item_count   INT          NOT NULL,
        total        DECIMAL(12,2) NOT NULL,
        status       ENUM('processing','completed') NOT NULL DEFAULT 'processing',
        note         VARCHAR(255) NULL,
        processed_by VARCHAR(40)  NULL,
        processed_at BIGINT       NOT NULL,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    const [cols] = await db.q(
        "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'payout_requests' AND COLUMN_NAME = 'batch_id'");
    if (!cols.length) {
        await db.q("ALTER TABLE payout_requests ADD COLUMN batch_id VARCHAR(16) NULL AFTER status, ADD KEY idx_payout_batch (batch_id)");
    }
    const [st] = await db.q(
        "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'payout_requests' AND COLUMN_NAME = 'status'");
    if (st.length && !/cancelled/.test(st[0].COLUMN_TYPE)) {
        await db.q("ALTER TABLE payout_requests MODIFY status ENUM('pending','approved','paid','rejected','cancelled') NOT NULL DEFAULT 'pending'");
    }
    await db.q("INSERT INTO counters (kind, value) VALUES ('pbatch', 0) ON DUPLICATE KEY UPDATE value = value");
}

module.exports = {
    /* constants the pages consume */
    PORTFOLIO_CAPTIONS,
    migrateAuthColumns, migratePayoutTables, migrateIdGateColumn, migrateContactChannels, migrateMatchEvents, migrateNotifyPrefs, notifyProByChannel, applicationTrack,
    /* applications */
    addApplication, getApplications, reviewApplication, verifiedNotices,
    /* bookings & matching */
    createBooking, getBooking, getBookingsFor, getQuotesFor, acceptQuote, setBookingStatus,
    updateBookingBudget,
    cancelBooking, rebookFrom, cancellationSummary, adminNoMatchQueue,
    priceStats, budgetOutcome,
    /* escrow & disputes */
    payIntoEscrow, releaseEscrow, openDispute, getDisputes, resolveDispute,
    fundEscrowInTx,
    customerRematchOptions, customerRematchPick,
    /* reviews & chat */
    addReview, getReviewsFor, chatMessages, sendChat, systemChat,
    /* pro dashboard */
    proBookings, proRespondQuote, toggleProDate, updateProProfile, payoutPro,
    requestPayout, cancelPayout, myPayouts,
    idStatus, requestIdDocs, submitReverify, approveReverify,
    idGate, idGateSync, gateKeep, idGateSweep, startIdGateSweeper, setIdGateOverride, idGateWindows,
    setAdminSettingAllowlist,
    proAvailability, setAvailabilityStatus, dateAvailability, AVAIL_META, getPortfolio, setPortfolio,
    /* credentials & sessions */
    normPhone, proLogin, requestProOtp, setProPassword, proUsesDefaultPassword,
    adminLogin, setAdminPassword, adminUsesDefaultPassword, adminAuthMeta,
    createSession, getSession, destroySession, COOKIE,
    /* admin */
    adminStats, adminAssign, reassignBooking, allBookings, allQuotes,
    payoutQueue, approvePayouts, rejectPayout, createPayoutBatch, processPayoutBatch,
    setSetting,
    adminCustomers, customerHistory,
    /* fees & ledger */
    payRegFee, markRegFeePaidInTx, getTransactions, markProPaid,
    notify, notificationsFor, markNotificationsRead, addTxn,
    notificationPrefsGet, notificationPrefsSet,
    /* reads, mappers & internal helpers */
    getPros, getPro, getCms, updateCms, getRegFee, getCatalog,
    submitSupportMessage, supportMessages, resolveSupportMessage,
    addReview, getReviewsFor, chatMessages, sendChat, systemChat,
    todayISO: db.todayISO,
    catMap, urgencyMap, proIconsMap, proRow, escrowFor, eventsFor, nextEventSeq, pushEvent,
    addQuoteInternal, bookingOut, quoteOut, txnOut, appOut, reviewOut, supportOut, disputeOut, proOut,
    cedi, round2,
    /* sync-bridge support */
    snapshot, resetAll, revBump, serverRev,
    /* background housekeeping */
    startNotificationCapSweeper,
    /* seeding (idempotent; boot + reset) */
    ensureSeeded, seedBaseline
};
