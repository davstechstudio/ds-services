/* ============================================================
   push.js — Web Push (VAPID) sender, zero dependencies.

   Implements the Web Push protocol (RFC 8291 encryption + RFC 8292
   VAPID auth) over the browser push services using only node:crypto
   and node:https:

     - keygen()              generate a P-256 VAPID pair (base64url)
     - publicKey()           the configured public key (or null)
     - subscribe/has/unsub   push_push_subscriptions table helpers
     - sendToAudience(...)   encrypt + POST to every matching endpoint
     - pushNotify(...)       called from sc-api notify(): fire-and-forget

   Delivery is strictly best-effort: a push failure NEVER fails the
   business mutation that caused it. Expired endpoints (404/410) are
   deleted automatically.
   ============================================================ */

'use strict';

const crypto = require('crypto');
const https = require('https');
const db = require('./db');
const config = require('./config');

/* ---------- base64url helpers ---------- */
function b64url(buf) { return Buffer.from(buf).toString('base64url'); }
function b64urlJson(j) { return b64url(JSON.stringify(j)); }

/* ---------- VAPID key management ---------- */

/* Generate a P-256 keypair for SC_VAPID_PUBLIC / SC_VAPID_PRIVATE.
   The PUBLIC key must be the raw 65-byte uncompressed EC point
   (0x04 || X || Y) — that exact form is what browsers require as
   applicationServerKey and what the VAPID 'k=' token carries. */
function keygen() {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
    const jwk = publicKey.export({ format: 'jwk' });
    const point = Buffer.concat([Buffer.from([0x04]), b64urlToBuf(jwk.x), b64urlToBuf(jwk.y)]);
    return {
        public: point.toString('base64url'),
        private: privateKey.export({ type: 'pkcs8', format: 'der' }).toString('base64url')
    };
}

let PUBLIC_KEY = null;
let PRIVATE_KEY = null;
function loadKeys() {
    if (PUBLIC_KEY !== null) return { public: PUBLIC_KEY, private: PRIVATE_KEY };
    const infra = config.infra || {};
    PUBLIC_KEY = infra.VAPID_PUBLIC || null;
    PRIVATE_KEY = infra.VAPID_PRIVATE || null;
    return { public: PUBLIC_KEY, private: PRIVATE_KEY };
}

function publicKey() { return loadKeys().public; }
function enabled() { const k = loadKeys(); return !!(k.public && k.private); }

/* ---------- subscription store (push_push_subscriptions) ---------- */

async function migratePushSubscriptions() {
    await db.q(`CREATE TABLE IF NOT EXISTS push_push_subscriptions (
        id          VARCHAR(24)  NOT NULL PRIMARY KEY,
        audience    VARCHAR(10)  NOT NULL,          -- 'pro' | 'customer'
        ref_to      VARCHAR(24)  NOT NULL,          -- pro id (P1001) or booking ref
        endpoint    VARCHAR(500) NOT NULL,
        p256dh      VARCHAR(200) NOT NULL,
        auth        VARCHAR(100) NOT NULL,
        created_at  BIGINT       NOT NULL,
        last_seen   BIGINT       NULL,
        UNIQUE KEY uniq_endpoint (endpoint(191)),
        KEY idx_audience (audience, ref_to)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
}

async function subscribe(audience, refTo, endpoint, keys) {
    if (!audience || !refTo || !endpoint || !keys || !keys.p256dh || !keys.auth) {
        return { ok: false, error: 'Missing subscription details.' };
    }
    const existing = await db.q('SELECT id FROM push_push_subscriptions WHERE endpoint = ?', [endpoint]);
    if (existing.length) {
        await db.q('UPDATE push_push_subscriptions SET audience = ?, ref_to = ?, p256dh = ?, auth = ?, last_seen = ? WHERE endpoint = ?',
            [String(audience), String(refTo), String(keys.p256dh), String(keys.auth), Date.now(), endpoint]);
        return { ok: true, updated: true };
    }
    const id = 'PS' + Date.now() + Math.floor(Math.random() * 1e6);
    await db.q('INSERT INTO push_push_subscriptions (id, audience, ref_to, endpoint, p256dh, auth, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [id, String(audience), String(refTo), String(endpoint), String(keys.p256dh), String(keys.auth), Date.now()]);
    return { ok: true, id };
}

async function unsubscribe(endpoint) {
    await db.q('DELETE FROM push_push_subscriptions WHERE endpoint = ?', [endpoint]);
    return { ok: true };
}

async function subsFor(audience, refTo) {
    const [rows] = await db.q('SELECT * FROM push_push_subscriptions WHERE audience = ? AND ref_to = ?', [audience, refTo || '']);
    return rows;
}

/* ---------- RFC 8291 encryption (aes128gcm) ---------- */

function hmacSha256(key, data) { return crypto.createHmac('sha256', key).update(data).digest(); }

/* HKDF per RFC 5869 with SHA-256. */
function hkdf(ikm, salt, info, length) {
    const prk = hmacSha256(salt, ikm);
    let t = Buffer.alloc(0), okm = Buffer.alloc(0), i = 1;
    while (okm.length < length) {
        t = hmacSha256(prk, Buffer.concat([t, info, Buffer.from([i])]));
        okm = Buffer.concat([okm, t]);
        i++;
    }
    return okm.slice(0, length);
}

function b64urlToBuf(s) { return Buffer.from(String(s), 'base64url'); }

/* Encrypt payload for one subscription (aes128gcm content coding). */
function encryptPayload(sub, payloadStr) {
    const uaPublic = b64urlToBuf(sub.p256dh);
    const authSecret = b64urlToBuf(sub.auth);
    const ecdh = crypto.createECDH('prime256v1');
    ecdh.generateKeys();
    const serverPublic = ecdh.getPublicKey();
    const shared = ecdh.computeSecret(uaPublic);

    const salt = crypto.randomBytes(16);
    const cekInfo = Buffer.concat([Buffer.from('WebPush: info\0', 'utf8'), uaPublic, serverPublic]);
    const cek = hkdf(shared, authSecret, cekInfo, 16);
    const nonce = hkdf(shared, salt, Buffer.from('Content-Encoding: nonce\0', 'utf8'), 12);

    const payload = Buffer.from(String(payloadStr), 'utf8');
    const padded = Buffer.concat([payload, Buffer.from([2])]);   // aes128gcm record: payload + 0x02 delimiter
    const cipher = crypto.createCipheriv('aes-128-gcm', cek, nonce);
    const ct = Buffer.concat([cipher.update(padded), cipher.final(), cipher.getAuthTag()]);

    /* aes128gcm header: salt(16) | rs(4) | idlen(1) | keyid */
    const header = Buffer.concat([salt, Buffer.from([0, 0, 16, 0]), Buffer.from([serverPublic.length]), serverPublic]);
    return Buffer.concat([header, ct]);
}

/* ---------- VAPID JWT (ES256) + delivery ---------- */

function vapidJwt(audienceOrigin) {
    const k = loadKeys();
    const header = { typ: 'JWT', alg: 'ES256' };
    const claims = {
        aud: audienceOrigin,
        exp: Math.floor(Date.now() / 1000) + 12 * 3600,
        sub: (config.infra || {}).VAPID_SUBJECT || 'mailto:dispatch@skillconnectgh.com'
    };
    const signingInput = b64urlJson(header) + '.' + b64urlJson(claims);
    const keyObj = crypto.createPrivateKey({ key: Buffer.from(k.private, 'base64url'), format: 'der', type: 'pkcs8' });
    const sig = crypto.sign('sha256', Buffer.from(signingInput), { key: keyObj, dsaEncoding: 'ieee-p1363' });
    return signingInput + '.' + b64url(sig);
}

/* POST the encrypted payload to the push endpoint. Resolves { ok, status }. */
function postToEndpoint(endpoint, body, headers) {
    return new Promise((resolve) => {
        try {
            const u = new URL(endpoint);
            const payload = JSON.stringify(body);
            const req = https.request({
                hostname: u.hostname, port: u.port || 443, path: u.pathname + u.search, method: 'POST',
                headers: Object.assign({ 'Content-Length': Buffer.byteLength(payload) }, headers),
                timeout: 10000
            }, (res) => {
                res.resume();
                resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode });
            });
            req.on('timeout', () => { req.destroy(); resolve({ ok: false, status: 0 }); });
            req.on('error', () => resolve({ ok: false, status: 0 }));
            req.write(payload);
            req.end();
        } catch (e) {
            resolve({ ok: false, status: 0 });
        }
    });
}

/* Send one payload string to one subscription row. Fire-and-forget safe. */
async function pushToSubscription(sub, payloadStr, ttlSeconds) {
    const u = new URL(sub.endpoint);
    const jwt = vapidJwt(u.origin);
    const encrypted = encryptPayload(sub, payloadStr);
    const res = await postToEndpoint(sub.endpoint, encrypted, {
        'Content-Type': 'application/octet-stream',
        'Content-Encoding': 'aes128gcm',
        'TTL': String(ttlSeconds || 86400),
        'Authorization': 'vapid t=' + jwt + ', k=' + publicKey(),
        'Urgency': 'normal'
    });
    if (res.status === 404 || res.status === 410) {
        await unsubscribe(sub.endpoint).catch(() => {});
    }
    return res;
}

/* Send to every subscription of an audience/ref. Never throws. */
async function sendToAudience(audience, refTo, payloadObj, ttlSeconds) {
    if (!enabled()) return { ok: false, disabled: true, sent: 0 };
    let subs = [];
    try { subs = await subsFor(audience, refTo); } catch (e) { return { ok: false, error: e.message, sent: 0 }; }
    let sent = 0;
    const payloadStr = JSON.stringify(payloadObj);
    for (const s of subs) {
        try {
            const r = await pushToSubscription(s, payloadStr, ttlSeconds);
            if (r.ok) sent++;
        } catch (e) { /* best-effort */ }
    }
    return { ok: true, sent: sent, total: subs.length };
}

/* Called by sc-api notify() after the in-app row is written. */
async function pushNotify(audience, refTo, type, text, title) {
    return sendToAudience(audience, refTo, {
        title: title || 'SkillConnect GH',
        body: String(text || '').slice(0, 300),
        type: type || 'booking',
        tag: (type || 'booking') + '-' + (refTo || '')
    }, 86400);
}

/* Sandbox test hook: send a push through the real pipeline. */
async function pushTest(audience, refTo, text) {
    return sendToAudience(String(audience || 'customer'), String(refTo || ''), {
        title: 'SkillConnect GH — test notice',
        body: String(text || 'Push notifications are working! You will now receive booking alerts even with SkillConnect closed.'),
        type: 'test',
        tag: 'test'
    }, 3600);
}

module.exports = {
    keygen, publicKey, enabled,
    migratePushSubscriptions, subscribe, unsubscribe, subsFor,
    sendToAudience, pushNotify, pushTest
};
