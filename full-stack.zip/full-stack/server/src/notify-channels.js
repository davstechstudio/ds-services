/* ============================================================
   notify-channels.js — SMS/WhatsApp gateway delivery (LTR-adjacent
   comms layer; zero dependencies).
   ------------------------------------------------------------
   Pro notifications already land in the in-app bell (notifications
   table) and on Web Push (push.js). This layer adds the OFF-PLATFORM
   leg: SMS and WhatsApp, honouring the pro's contact_channels
   preference ('sms' | 'whatsapp' | 'both') — so "BOOKED!" reaches a
   pro who never has the site open.

   ADAPTER SEAM (like payments.js):
     SC_MSG_WEBHOOK_URL  — POST {channel, to, text, type, proId, meta}
                           to this URL. Response JSON {ok:true} (or any
                           2xx) counts as accepted. Point it at
                           tools/mock-msg-gateway.js for tests; point it
                           at a provider bridge (Twilio, Africa's Talking,
                           WhatsApp Cloud API…) at go-live — that bridge
                           owns provider credentials, this layer never
                           sees them.
   Credentials stay in the bridge/env ON PURPOSE: settings rows are
   admin-visible and this file stays credential-free like push.js.

   Delivery is strictly best-effort and fire-and-forget from notify()
   (a gateway outage must never fail a booking), and AWAITABLE from
   notifyProByChannel() so callers/tests can observe the result.
   Every attempt is audited in channel_outbound.
   ============================================================ */

'use strict';

const https = require('https');
const http = require('http');
const db = require('./db');
const config = require('./config');

function webhookUrl() {
    return process.env.SC_MSG_WEBHOOK_URL || '';
}
function enabled() { return !!webhookUrl(); }

/* Webhook secret echoed back in the X-SC-Msg-Signature header of every
   POST so the bridge can reject forged requests. Optional. */
function webhookSecret() { return process.env.SC_MSG_WEBHOOK_SECRET || ''; }

/* ---------- outbound audit table (idempotent boot migration) ---------- */

async function migrateChannelOutbound() {
    await db.q(`CREATE TABLE IF NOT EXISTS channel_outbound (
        id         BIGINT       NOT NULL AUTO_INCREMENT,
        pro_id     VARCHAR(12)  NULL,
        channel    VARCHAR(10)  NOT NULL,            -- sms | whatsapp
        to_msisdn  VARCHAR(20)  NOT NULL,
        type       VARCHAR(20)  NOT NULL,
        text       VARCHAR(420) NOT NULL,
        status     ENUM('sent','failed','skipped_no_phone') NOT NULL DEFAULT 'sent',
        detail     VARCHAR(255) NULL,
        created_at BIGINT       NOT NULL,
        PRIMARY KEY (id),
        KEY idx_co_pro (pro_id, created_at),
        KEY idx_co_status (status, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
}

/* ---------- tiny POST (node:http/https only, like push.js) ---------- */

function postJson(url, headers, payloadObj, timeoutMs) {
    return new Promise((resolve) => {
        let u;
        try { u = new URL(url); } catch (e) { return resolve({ ok: false, status: 0, error: 'bad-url' }); }
        const mod = u.protocol === 'https:' ? https : http;
        const body = Buffer.from(JSON.stringify(payloadObj), 'utf8');
        let settled = false;
        const done = (r) => { if (!settled) { settled = true; resolve(r); } };
        const req = mod.request({
            hostname: u.hostname,
            port: u.port || (u.protocol === 'https:' ? 443 : 80),
            path: u.pathname + u.search,
            method: 'POST',
            headers: Object.assign({
                'Content-Type': 'application/json',
                'Content-Length': body.length
            }, headers)
        }, (res) => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => {
                let parsed = null;
                try { parsed = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { /* non-JSON is fine */ }
                done({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, body: parsed });
            });
        });
        req.setTimeout(timeoutMs || 8000, () => { req.destroy(new Error('timeout')); done({ ok: false, status: 0, error: 'timeout' }); });
        req.on('error', (e) => done({ ok: false, status: 0, error: e && e.message || 'error' }));
        req.end(body);
    });
}

/* ---------- recipient + preference resolution ---------- */

async function proRecipient(conn, proId) {
    const q = (sql, p) => (conn ? conn.query(sql, p) : db.q(sql, p));
    const [rows] = await q('SELECT phone, contact_channels FROM pros WHERE id = ?', [proId]);
    if (!rows.length) return null;
    const r = rows[0];
    return { phone: String(r.phone || ''), channels: r.contact_channels || 'both' };
}

/* Normalise a Ghana MSISDN for the gateway: keep digits, map the local
   0XXXXXXXXX form to international 233XXXXXXXXX (Ghana country code 233). */
function normMsisdn(phone) {
    let s = String(phone || '').replace(/[\s-]/g, '');
    if (/^0\d{9}$/.test(s)) s = '233' + s.slice(1);
    return s;
}

/* One audited gateway send. NEVER throws — every failure path returns
   a status and lands in channel_outbound. */
async function sendChannel(proId, channel, msisdn, type, text) {
    const to = normMsisdn(msisdn);
    const status = to ? 'sent' : 'skipped_no_phone';
    try {
        let detail = null;
        if (status === 'sent' && enabled()) {
            const headers = {};
            const sig = webhookSecret();
            if (sig) headers['X-SC-Msg-Signature'] = sig;
            const r = await postJson(webhookUrl(), headers,
                { channel, to, text: String(text || '').slice(0, 400), type, proId, brand: 'SkillConnect GH' });
            detail = 'HTTP ' + r.status + (r.body && r.body.error ? ': ' + String(r.body.error).slice(0, 120) : '');
            await db.q(
                'INSERT INTO channel_outbound (pro_id, channel, to_msisdn, type, text, status, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [proId || null, channel, to, type, String(text || '').slice(0, 400), r.ok ? 'sent' : 'failed', detail, Date.now()]);
            return { channel, ok: !!r.ok, status: r.status, detail };
        }
        /* No gateway configured, or the pro has no callable number: audit the
           skip so ops can see what WOULD have gone out (dry-run mode). */
        await db.q(
            'INSERT INTO channel_outbound (pro_id, channel, to_msisdn, type, text, status, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [proId || null, channel, to, type, String(text || '').slice(0, 400), status, enabled() ? null : 'gateway-not-configured', Date.now()]);
        return { channel, ok: false, skipped: true, reason: enabled() ? 'no-phone' : 'disabled' };
    } catch (e) {
        try {
            await db.q(
                'INSERT INTO channel_outbound (pro_id, channel, to_msisdn, type, text, status, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [proId || null, channel, to, type, String(text || '').slice(0, 400), 'failed', String(e && e.message || e).slice(0, 240), Date.now()]);
        } catch (e2) { /* audit is best-effort too */ }
        return { channel, ok: false, error: e && e.message || String(e) };
    }
}

/* Route one pro notice over the pro's preferred channel(s). Reads the
   preference itself (proId + text is all callers hold). Never throws.
   deliverNow: await the HTTP send (notifyProByChannel); otherwise the
   send races ahead fire-and-forget (notify() hot path). */
async function deliverProNotice(proId, type, text, deliverNow) {
    const run = async () => {
        try {
            const rec = await proRecipient(null, proId);
            if (!rec) return { ok: false, error: 'pro-not-found', results: [] };
            const wanted = rec.channels === 'both' ? ['sms', 'whatsapp'] : [rec.channels];
            const results = [];
            for (const ch of wanted) {
                if (ch !== 'sms' && ch !== 'whatsapp') continue;
                results.push(await sendChannel(proId, ch, rec.phone, type, text));
            }
            return { ok: results.some(r => r.ok), results };
        } catch (e) {
            return { ok: false, error: e && e.message || String(e), results: [] };
        }
    };
    return deliverNow ? run() : run().catch(() => {});
}

/* Recent outbound rows, newest first — the admin/ops view and the
   smoke suite's window into what the gateway actually received. */
async function channelOutboundRecent(limit) {
    const [rows] = await db.q('SELECT * FROM channel_outbound ORDER BY id DESC LIMIT ?', [Math.min(Math.max(Number(limit) || 50, 1), 500)]);
    return rows.map(r => ({
        id: Number(r.id), proId: r.pro_id || null, channel: r.channel,
        to: r.to_msisdn, type: r.type, text: r.text,
        status: r.status, detail: r.detail || null, createdAt: Number(r.created_at)
    }));
}

module.exports = {
    enabled, webhookUrl, normMsisdn,
    migrateChannelOutbound,
    deliverProNotice, sendChannel, channelOutboundRecent
};
