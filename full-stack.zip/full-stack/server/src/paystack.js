/* ============================================================
   paystack.js — minimal Paystack client (no SDK dependency).

   Endpoints used (https://paystack.com/docs/api):
     POST /transaction/initialize  → authorization_url for checkout
     GET  /transaction/verify/:ref → pull-verify fallback
   Webhook security: X-Paystack-Signature is the HMAC-SHA512 of the
   RAW request body, keyed with the secret key — verified against the
   untouched Buffer in index.js (never a re-serialized object).

   Secrets live in config.infra (env SC_PAYSTACK_SECRET), never here
   and never in the settings table.
   ============================================================ */

'use strict';

const crypto = require('crypto');

const API = 'https://api.paystack.co';

/* Create a checkout. Returns { ok, authorizationUrl, accessCode, reference }
   or { ok:false, error }. Uses the global fetch (Node ≥ 18). */
async function initialize(o) {
    try {
        const body = {
            reference: o.reference,
            amount: o.amountMinor,             /* kobo/pesewas — integer */
            email: o.email,
            currency: o.currency || 'GHS',
            callback_url: o.callbackUrl || undefined,
            /* momo/telecel selections land on mobile_money; card stays card */
            channels: o.channel === 'card' ? ['card'] : ['mobile_money', 'card'],
            phone: o.phone || undefined,
            metadata: {
                intent_id: o.meta && o.meta.intentId,
                purpose: o.meta && o.meta.purpose,
                booking_id: (o.meta && o.meta.bookingId) || null,
                app_ref: (o.meta && o.meta.appRef) || null
            }
        };
        const r = await fetch(API + '/transaction/initialize', {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + o.secret, 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const j = await r.json();
        if (!r.ok || !j.status) return { ok: false, error: 'Paystack: ' + (j.message || ('HTTP ' + r.status)) };
        return {
            ok: true,
            authorizationUrl: j.data.authorization_url,
            accessCode: j.data.access_code,
            reference: j.data.reference
        };
    } catch (e) {
        return { ok: false, error: 'Paystack unreachable: ' + e.message };
    }
}

/* Pull-verify fallback for networks that cannot reach the webhook.
   Returns { ok, status:'success'|'failed'|…, amountMinor, gatewayRef, raw }. */
async function verify(secret, reference) {
    try {
        const r = await fetch(API + '/transaction/verify/' + encodeURIComponent(reference), {
            headers: { 'Authorization': 'Bearer ' + secret }
        });
        const j = await r.json();
        if (!r.ok || !j.status) return { ok: false, error: 'Paystack: ' + (j.message || ('HTTP ' + r.status)) };
        return { ok: true, status: j.data.status, amountMinor: j.data.amount, gatewayRef: j.data.id, raw: j.data };
    } catch (e) {
        return { ok: false, error: 'Paystack unreachable: ' + e.message };
    }
}

/* Constant-time HMAC-SHA512 check of the RAW body. */
function verifySignature(secret, rawBody, signatureHeader) {
    if (!secret || !rawBody || !signatureHeader) return false;
    const expect = crypto.createHmac('sha512', secret).update(rawBody).digest('hex');
    const got = Buffer.from(String(signatureHeader), 'utf8');
    const want = Buffer.from(expect, 'utf8');
    return got.length === want.length && crypto.timingSafeEqual(got, want);
}

module.exports = { initialize, verify, verifySignature };
