/* ============================================================
   db.js — MySQL pool + tiny helpers
   - Rows come back with snake_case columns; mappers in sc-api.js
     shape them into the exact objects the SC API contract uses.
   - nextRef() replaces the sandbox counters object: business refs
     (SC-BK-284001 …) stay stable across the migration.
   ============================================================ */

'use strict';

const mysql = require('mysql2/promise');
const config = require('./config');

let pool = null;

async function init() {
    pool = mysql.createPool({
        host: config.infra.DB_HOST,
        port: config.infra.DB_PORT,
        user: config.infra.DB_USER,
        password: config.infra.DB_PASS,
        database: config.infra.DB_NAME,
        waitForConnections: true,
        /* Transactions that read settings inside their tx (config.get /
           getRegFee / notification caps) briefly borrow a second pool
           connection; headroom above the expected concurrent-mutation
           count keeps that from ever circular-waiting. */
        connectionLimit: 30,
        charset: 'utf8mb4',
        /* DATE columns come back as 'YYYY-MM-DD' strings (sandbox stored ISO
           strings); everything else stays epoch-ms BIGINT. */
        dateStrings: true
    });
    config.setPool(pool);
    await pool.query('SELECT 1');
    return pool;
}

function get() { return pool; }

/* Run fn(conn) inside a transaction; rolls back on throw.

   Concurrency: InnoDB deadlock / lock-wait-timeout is an EXPECTED
   outcome when parallel transactions touch overlapping ranges (e.g.
   notify()'s cap-DELETE gap-locks on notifications(audience)). The
   rolled-back tx left no partial state and every business guard
   re-runs on the retry, so a bounded jittered retry is safe and
   correct — callers keep the same db.tx(fn) signature. */
const RETRYABLE_CODES = new Set(['ER_LOCK_DEADLOCK', 'ER_LOCK_WAIT_TIMEOUT']);

async function tx(fn, opts) {
    const attempts = (opts && opts.retries !== undefined) ? Math.max(1, opts.retries + 1) : 5;
    let lastErr = null;
    for (let i = 0; i < attempts; i++) {
        const conn = await pool.getConnection();
        try {
            await conn.beginTransaction();
            const out = await fn(conn);
            await conn.commit();
            conn.release();
            return out;
        } catch (e) {
            try { await conn.rollback(); } catch (_) { /* already broken */ }
            conn.release();
            const code = e && (e.code || (e.cause && e.cause.code));
            if (RETRYABLE_CODES.has(code) && i < attempts - 1) {
                lastErr = e;
                await new Promise(r => setTimeout(r, 25 * (i + 1) + Math.floor(Math.random() * 40)));
                continue;
            }
            throw e;
        }
    }
    throw lastErr;
}

function q(sql, params) { return pool.query(sql, params || []); }

/* Increment a counter and return the formatted business ref with the
   same prefix map as the sandbox nextId(). */
const PREFIX = {
    booking: 'SC-BK-', quote: 'SC-Q-', msg: 'SC-MSG-', app: 'SC-APP-',
    dispute: 'SC-DS-', review: 'SC-RV-', txn: 'SC-', payout: 'SC-PO-', pbatch: 'SC-PB-'
};

async function nextRef(conn, kind) {
    const [rows] = await conn.query('SELECT value FROM counters WHERE kind = ? FOR UPDATE', [kind]);
    const value = (rows.length ? Number(rows[0].value) : 0) + 1;
    if (rows.length) await conn.query('UPDATE counters SET value = ? WHERE kind = ?', [value, kind]);
    else await conn.query('INSERT INTO counters (kind, value) VALUES (?, ?)', [kind, value]);
    return (PREFIX[kind] || 'SC-') + value;
}

/* Random helpers matching the sandbox's shapes. */
function randomHex(bytes) {
    const buf = Buffer.alloc(bytes);
    require('crypto').randomFillSync(buf);
    return buf.toString('hex');          // bytes*2 chars
}

function escTxnRef() {
    return 'ESC-' + Math.random().toString(36).slice(2, 8).toUpperCase();
}

function supportRef() {
    return 'MSG-' + Math.random().toString(36).slice(2, 7).toUpperCase();
}

function todayISO() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/* Salted SHA-256 — identical scheme to the sandbox so imported
   hashes verify as-is (crypto.digest of salt+secret, hex out). */
const crypto = require('crypto');
function sha256Hex(s) { return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex'); }
function hashEq(a, b) { return !!a && !!b && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b)); }

/* ---------- password hashing (scrypt, work-factor) ----------
   scryptHash returns "scrypt$N$r$p$salt$key" (hex salt+key, self-describing
   parameters); scryptVerify recomputes with the stored parameters and
   compares in constant time. Legacy sha256(salt+password) rows are
   verified in the auth layer (which holds the row's salt) and migrated
   to scrypt on the next successful login / password change. */
function scryptHash(password, saltHex) {
    const N = 16384, r = 8, p = 1, keyLen = 64;
    const saltBuf = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
    const key = crypto.scryptSync(String(password), saltBuf, keyLen, { N, r, p });
    return 'scrypt$' + N + '$' + r + '$' + p + '$' + saltBuf.toString('hex') + '$' + key.toString('hex');
}

function scryptVerify(password, stored) {
    const parts = String(stored || '').split('$');
    if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
    const N = Number(parts[1]), r = Number(parts[2]), p = Number(parts[3]);
    if (!N || !r || !p) return false;
    const saltBuf = Buffer.from(parts[4], 'hex');
    const expected = Buffer.from(parts[5], 'hex');
    if (!expected.length) return false;
    const key = crypto.scryptSync(String(password), saltBuf, expected.length, { N, r, p });
    return crypto.timingSafeEqual(key, expected);
}

module.exports = { init, get, tx, q, nextRef, randomHex, escTxnRef, supportRef, todayISO, sha256Hex, hashEq, scryptHash, scryptVerify };
