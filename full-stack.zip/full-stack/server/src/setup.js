/* ============================================================
   setup.js — browser-based first-run installer for SkillConnect
   ------------------------------------------------------------
   Point the browser at http://<host>:<port>/setup.html and fill
   the form. It:

     1. Reads the live database status: NO tables → "fresh install",
        SOME tables → "upgrade" (missing tables get created, missing
        catalog/settings rows get filled — existing data is NEVER
        touched). This is what makes future upgrades safe: drop the
        new code in, open /setup.html, press Run.
     2. Optionally SAVES the database credentials into server/.env
        so the beginner never hand-edits a file.
     3. Runs the schema (all CREATE TABLE IF NOT EXISTS + INSERT
        IGNORE seeds), then the API's idempotent boot migrations
        (payout tables, ID-gate columns, contact channels, push,
        match_events, channel_outbound, notify prefs) and seeding.

   SECURITY: every POST requires the one-time setup token printed
   at server start (SC_SETUP_TOKEN, or auto-generated and shown in
   the console log). The installer LOCKS ITSELF the moment the
   database is fully installed — a second visit says "already
   installed" and refuses to run anything.
   ============================================================ */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./db');
const config = require('./config');

const ENV_PATH = path.join(__dirname, '..', '.env');

function setupToken() {
    if (process.env.SC_SETUP_TOKEN) return process.env.SC_SETUP_TOKEN;
    if (!setupToken._generated) {
        setupToken._generated = crypto.randomBytes(9).toString('hex');
        console.log('');
        console.log('  ==========================================================');
        console.log('   FIRST-RUN SETUP: open http://localhost:' + config.infra.PORT + '/setup.html');
        console.log('   Setup token: ' + setupToken._generated);
        console.log('  ==========================================================');
        console.log('');
    }
    return setupToken._generated;
}

/* The full table list this version expects — parsed live from
   db/schema.sql so a new module's table is automatically part of the
   expected set after an upgrade (no list to maintain in two places). */
const REQUIRED_TABLES = ['settings', 'categories', 'urgency_levels', 'cms', 'counters', 'pros', 'bookings'];
function expectedTables() {
    try {
        const sql = fs.readFileSync(path.join(__dirname, '..', '..', 'db', 'schema.sql'), 'utf8');
        const names = [...sql.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?([a-z_]+)/gi)].map(m => m[1]);
        return [...new Set([...REQUIRED_TABLES, ...names])];
    } catch (e) { return REQUIRED_TABLES.slice(); }
}

/* Status: what does the connected database look like right now? */
async function dbStatus() {
    try {
        await db.q('SELECT 1');
    } catch (e) {
        return { connected: false, error: e.code || e.message, tables: 0, installed: false };
    }
    const [rows] = await db.q('SHOW TABLES');
    const tables = rows.length;
    const expected = expectedTables();
    const have = new Set(rows.map(r => Object.values(r)[0]));
    const missingCore = REQUIRED_TABLES.filter(t => !have.has(t));
    const missingAny = expected.filter(t => !have.has(t));
    return { connected: true, tables, missingCore, missingAny, complete: missingAny.length === 0, installed: tables > 0 && missingCore.length === 0 };
}

/* Token check for POSTs. GET status is open (harmless read). */
function authorized(body) {
    const tok = String((body && body.token) || '');
    const expected = setupToken();
    if (!tok || tok !== expected) return false;
    return true;
}

/* Run the schema + boot migrations. Idempotent end to end. The schema
   script is a multi-statement file (SET/CREATE/INSERT…) so the import
   opens its OWN connection with multipleStatements enabled — the pooled
   app connection keeps that hardened flag OFF for the API itself. */
async function runInstall() {
    const sql = fs.readFileSync(path.join(__dirname, '..', '..', 'db', 'schema.sql'), 'utf8');
    const mysql = require('mysql2/promise');
    const conn = await mysql.createConnection({
        host: config.infra.DB_HOST, port: config.infra.DB_PORT,
        user: config.infra.DB_USER, password: config.infra.DB_PASS,
        database: config.infra.DB_NAME, multipleStatements: true, charset: 'utf8mb4'
    });
    try { await conn.query(sql); } finally { await conn.end(); }

    /* The API's own boot migrations — same list index.js runs, called
       here so an UPGRADE (new code, old DB) completes in one click. */
    const api = require('./sc-api');
    const push = require('./push');
    const msgChannels = require('./notify-channels');
    await api.migrateAuthColumns();
    await api.migratePayoutTables();
    await api.migrateIdGateColumn();
    await api.migrateContactChannels();
    await api.migrateMatchEvents();
    await push.migratePushSubscriptions();
    await msgChannels.migrateChannelOutbound();
    await api.migrateNotifyPrefs();
    await api.ensureSeeded();
    return dbStatus();
}

/* Save DB credentials into server/.env (create or merge). Only the
   keys the form may set — never secrets like VAPID/gateway keys. */
async function saveEnv(fields) {
    const allowed = { SC_DB_HOST: 'dbHost', SC_DB_PORT: 'dbPort', SC_DB_USER: 'dbUser', SC_DB_PASS: 'dbPass', SC_DB_NAME: 'dbName', SC_PORT: 'port' };
    let lines = [];
    if (fs.existsSync(ENV_PATH)) {
        lines = fs.readFileSync(ENV_PATH, 'utf8').split(/\r?\n/).filter(l => !Object.keys(allowed).some(k => l.startsWith(k + '=')));
    }
    const out = [];
    for (const [k, f] of Object.entries(allowed)) {
        if (fields[f] !== undefined && fields[f] !== '') out.push(k + '=' + String(fields[f]).trim());
    }
    fs.writeFileSync(ENV_PATH, out.join('\n') + '\n' + lines.filter(Boolean).join('\n') + (lines.filter(Boolean).length ? '\n' : ''), { flag: 'w' });
    return ENV_PATH;
}

module.exports = { dbStatus, runInstall, saveEnv, authorized, setupToken, ENV_PATH };
