/*
 * server/ecosystem.config.cjs — PM2 process config for the SkillConnect API.
 *
 * Deploy on the VPS:
 *   npm install -g pm2
 *   cd /var/www/skillconnect/server
 *   pm2 start ecosystem.config.cjs && pm2 save && pm2 startup
 *
 * Secrets stay in server/.env (git-ignored) — never commit real keys.
 */
module.exports = {
    apps: [{
        name: 'skillconnect-api',
        script: 'src/index.js',
        cwd: __dirname,
        instances: 1,              /* single instance: refs + ledgers assume one writer */
        autorestart: true,
        max_memory_restart: '400M',
        env: {
            NODE_ENV: 'production',
            /* Go-live locks — flip NOTHING on without reading DEPLOYMENT.md */
            SC_ALLOW_RESET: 'false',
            SC_ALLOW_SANDBOX_HOOKS: 'false',
            SC_INSECURE_COOKIES: 'false'
        },
        out_file: '/var/log/skillconnect/out.log',
        error_file: '/var/log/skillconnect/error.log',
        merge_logs: true,
        time: true
    }]
};
